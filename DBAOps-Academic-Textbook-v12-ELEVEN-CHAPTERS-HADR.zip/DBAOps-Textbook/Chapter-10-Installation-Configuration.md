# Chapter 10
# Installation and Configuration

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Plan** a complete DBAOps framework deployment
2. **Install** all required components and dependencies
3. **Configure** the repository database and security
4. **Deploy** data collectors and automation scripts
5. **Set up** alerting and notification channels
6. **Configure** dashboards and reporting
7. **Test** the complete framework end-to-end
8. **Troubleshoot** common installation issues

**Key Terms**

- Prerequisites
- Deployment Architecture
- Infrastructure as Code
- Configuration Management
- Service Account
- SQL Agent Job
- Smoke Test
- Production Cutover
- Rollback Plan

---

## 10.1 Planning and Prerequisites

### 10.1.1 Deployment Architecture

**Figure 10.1: DBAOps Infrastructure Components**

```
┌─────────────────────────────────────────────────────────────┐
│              DBAOPS DEPLOYMENT ARCHITECTURE                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  PRESENTATION TIER (Users)                           │  │
│  │  • Web Browsers (Dashboard)                          │  │
│  │  • Power BI Desktop/Service                          │  │
│  │  • Mobile Apps                                       │  │
│  │  • Email Clients (Reports)                           │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓ HTTPS                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  WEB TIER (Optional - for custom dashboards)         │  │
│  │  Server: WEB-DBAOps01                                │  │
│  │  • IIS / ASP.NET Core                                │  │
│  │  • SignalR for real-time updates                     │  │
│  │  • Load balancer (production)                        │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓ SQL/TDS                           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  REPOSITORY TIER (Core)                              │  │
│  │  Server: REPO-SQL01 (Primary)                        │  │
│  │  Server: REPO-SQL02 (Secondary - Always On AG)       │  │
│  │  • SQL Server 2019+ Enterprise                       │  │
│  │  • DBAOpsRepository Database                         │  │
│  │  • TDE Enabled                                       │  │
│  │  • 16 GB RAM minimum, 32 GB recommended              │  │
│  │  • 100 GB storage (data), 50 GB (log)                │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓ SQL/TDS                           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  COLLECTOR TIER (Data gathering)                     │  │
│  │  Server: COLLECTOR01, COLLECTOR02 (HA pair)          │  │
│  │  • Windows Server 2019+                              │  │
│  │  • PowerShell 7+                                     │  │
│  │  • dbatools module                                   │  │
│  │  • 8 GB RAM, 50 GB storage                           │  │
│  │  • Scheduled tasks / SQL Agent jobs                  │  │
│  └──────────────────────────────────────────────────────┘  │
│                         ↓ SQL/TDS                           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  MONITORED TIER (Target SQL Servers)                 │  │
│  │  • 100-1000+ SQL Server instances                    │  │
│  │  • SQL Server 2012+                                  │  │
│  │  • Windows or Linux                                  │  │
│  │  • Firewall: Allow port 1433 from collectors        │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 10.1.2 Hardware Requirements

**Table 10.1: Server Specifications**

| Component | Minimum | Recommended | Notes |
|-----------|---------|-------------|-------|
| **Repository Server** ||||
| CPU | 4 cores | 8 cores | More cores = better query performance |
| RAM | 16 GB | 32 GB | Buffer pool for reporting queries |
| Storage | 100 GB | 500 GB | Plan for 90 days of metrics |
| IOPS | 1000 | 5000+ | Use SSD for best performance |
| Network | 1 Gbps | 10 Gbps | High throughput for collectors |
| **Collector Server** ||||
| CPU | 2 cores | 4 cores | Parallel PowerShell threads |
| RAM | 8 GB | 16 GB | Multiple concurrent connections |
| Storage | 50 GB | 100 GB | Scripts, logs, temp data |
| Network | 1 Gbps | 1 Gbps | Stable connection required |
| **Web Server (Optional)** ||||
| CPU | 2 cores | 4 cores | Handles dashboard requests |
| RAM | 8 GB | 16 GB | ASP.NET Core + caching |
| Storage | 50 GB | 100 GB | Application files, logs |

---

### 10.1.3 Software Prerequisites

**Repository Server:**

```powershell
# Check SQL Server version
Invoke-DbaQuery -SqlInstance REPO-SQL01 -Query "SELECT @@VERSION"
# Requirement: SQL Server 2016+ (2019+ recommended)

# Required Features:
# - Database Engine Services
# - Full-Text Search (for log searching)
# - R Services (for advanced analytics - optional)

# PowerShell modules
Install-Module dbatools -Force -AllowClobber
Install-Module SqlServer -Force -AllowClobber

# .NET Framework 4.8+
# Windows Server 2016+ or SQL Server on Linux
```

**Collector Server:**

```powershell
# PowerShell 7+
winget install Microsoft.PowerShell

# Required modules
Install-Module dbatools -Scope AllUsers -Force
Install-Module Az.KeyVault -Scope AllUsers -Force  # If using Azure Key Vault
Install-Module ImportExcel -Scope AllUsers -Force  # For Excel reports

# Verify installations
Get-Module dbatools -ListAvailable
Get-Module Az.KeyVault -ListAvailable
```

**Service Accounts:**

```powershell
# Create Active Directory service accounts
# Method 1: Managed Service Account (MSA) - RECOMMENDED
New-ADServiceAccount -Name "svc-dbaops-collector" `
                     -DNSHostName "collector01.domain.com" `
                     -PrincipalsAllowedToRetrieveManagedPassword "COLLECTOR01$"

# Method 2: Regular service account (if MSA not available)
New-ADUser -Name "svc-dbaops-collector" `
           -AccountPassword (ConvertTo-SecureString "P@ssw0rd!" -AsPlainText -Force) `
           -PasswordNeverExpires $true `
           -CannotChangePassword $true `
           -Description "DBAOps data collection service account"
```

---

## 10.2 Repository Database Installation

### 10.2.1 Automated Deployment Script

**Complete installation script:**

```powershell
<#
.SYNOPSIS
    Automated deployment of DBAOps Repository Database

.DESCRIPTION
    Creates database, schemas, tables, procedures, functions, views, jobs
    Implements security, enables TDE, configures audit

.PARAMETER RepositoryServer
    SQL Server instance for repository

.PARAMETER DataPath
    Path for data files (default: SQL Server default)

.PARAMETER LogPath
    Path for log files (default: SQL Server default)

.EXAMPLE
    .\Install-DBAOpsRepository.ps1 -RepositoryServer "REPO-SQL01" -Verbose
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$RepositoryServer,
    
    [string]$DataPath = $null,
    [string]$LogPath = $null,
    
    [switch]$SkipDatabase,
    [switch]$SkipSecurity,
    [switch]$SkipTDE,
    [switch]$TestMode
)

$ErrorActionPreference = 'Stop'
$VerbosePreference = 'Continue'

# Import required modules
Import-Module dbatools -ErrorAction Stop

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  DBAOps Repository Installation" -ForegroundColor Cyan
Write-Host "  Target Server: $RepositoryServer" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# Step 1: Create Database
if (!$SkipDatabase) {
    Write-Host "`n[Step 1/10] Creating DBAOpsRepository database..." -ForegroundColor Yellow
    
    # Get default paths if not specified
    if (!$DataPath) {
        $defaults = Get-DbaDefaultPath -SqlInstance $RepositoryServer
        $DataPath = $defaults.Data
        $LogPath = $defaults.Log
    }
    
    $createDbScript = @"
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'DBAOpsRepository')
BEGIN
    CREATE DATABASE DBAOpsRepository
    ON PRIMARY (
        NAME = DBAOpsRepository_Data,
        FILENAME = '$DataPath\DBAOpsRepository.mdf',
        SIZE = 1GB,
        MAXSIZE = UNLIMITED,
        FILEGROWTH = 256MB
    )
    LOG ON (
        NAME = DBAOpsRepository_Log,
        FILENAME = '$LogPath\DBAOpsRepository_log.ldf',
        SIZE = 512MB,
        MAXSIZE = UNLIMITED,
        FILEGROWTH = 128MB
    );
    
    ALTER DATABASE DBAOpsRepository SET RECOVERY SIMPLE;
    ALTER DATABASE DBAOpsRepository SET AUTO_CREATE_STATISTICS ON;
    ALTER DATABASE DBAOpsRepository SET AUTO_UPDATE_STATISTICS ON;
    ALTER DATABASE DBAOpsRepository SET PAGE_VERIFY CHECKSUM;
END
"@
    
    Invoke-DbaQuery -SqlInstance $RepositoryServer -Query $createDbScript
    Write-Host "  ✓ Database created successfully" -ForegroundColor Green
}

# Step 2: Create Schemas
Write-Host "`n[Step 2/10] Creating database schemas..." -ForegroundColor Yellow

$schemas = @('fact', 'dim', 'config', 'ctl', 'log', 'alert', 'security', 'meta', 'reports')
foreach ($schema in $schemas) {
    $createSchemaScript = @"
USE DBAOpsRepository;
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = '$schema')
    EXEC('CREATE SCHEMA $schema');
"@
    Invoke-DbaQuery -SqlInstance $RepositoryServer -Query $createSchemaScript
    Write-Host "  ✓ Schema created: $schema" -ForegroundColor Green
}

# Step 3: Create Dimension Tables
Write-Host "`n[Step 3/10] Creating dimension tables..." -ForegroundColor Yellow

# Read DDL from files or inline
$dimServerScript = @"
USE DBAOpsRepository;

CREATE TABLE dim.Server (
    ServerKey INT IDENTITY(1,1) PRIMARY KEY,
    ServerName NVARCHAR(128) NOT NULL,
    Environment VARCHAR(20) NOT NULL,
    DataCenter VARCHAR(50),
    Edition VARCHAR(50),
    Version VARCHAR(50),
    ServicePack VARCHAR(20),
    TotalMemoryGB INT,
    ProcessorCount INT,
    OwnerTeam VARCHAR(100),
    MonitoringEnabled BIT DEFAULT 1,
    BusinessCriticality VARCHAR(20),
    
    -- SCD Type 2 fields
    ValidFrom DATETIME2 DEFAULT SYSDATETIME(),
    ValidTo DATETIME2 DEFAULT '9999-12-31',
    IsCurrent BIT DEFAULT 1,
    
    INDEX IX_Server_Name_Current (ServerName, IsCurrent) INCLUDE (ServerKey)
);
"@

Invoke-DbaQuery -SqlInstance $RepositoryServer -Database DBAOpsRepository -Query $dimServerScript
Write-Host "  ✓ dim.Server created" -ForegroundColor Green

# Continue with other dimension tables (dim.Database, dim.Time, etc.)
# [Additional table creation scripts would follow similar pattern]

# Step 4: Create Fact Tables
Write-Host "`n[Step 4/10] Creating fact tables..." -ForegroundColor Yellow

$factPerfScript = @"
USE DBAOpsRepository;

CREATE TABLE fact.PerformanceMetrics (
    MetricKey BIGINT IDENTITY(1,1),
    ServerKey INT NOT NULL,
    TimeKey INT NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    
    -- CPU Metrics
    CPUUtilizationPercent DECIMAL(5,2),
    SQLProcessCPUPercent DECIMAL(5,2),
    
    -- Memory Metrics
    TotalMemoryMB INT,
    AvailableMemoryMB INT,
    PageLifeExpectancy INT,
    BufferCacheHitRatio DECIMAL(5,2),
    
    -- I/O Metrics
    ReadLatencyMS DECIMAL(10,2),
    WriteLatencyMS DECIMAL(10,2),
    IOStallMS BIGINT,
    
    -- SQL Metrics
    BatchRequestsPerSec INT,
    UserConnections INT,
    BlockedProcesses INT,
    TopWaitType VARCHAR(60),
    
    -- Health Score
    PerformanceScore AS (
        CASE 
            WHEN PageLifeExpectancy < 300 THEN 20
            WHEN PageLifeExpectancy < 600 THEN 50
            WHEN PageLifeExpectancy < 1000 THEN 75
            ELSE 95
        END
    ) PERSISTED,
    
    INDEX CCI_PerformanceMetrics CLUSTERED COLUMNSTORE,
    INDEX IX_PerformanceMetrics_Server_Time (ServerKey, TimeKey, CollectionDateTime)
        WITH (DATA_COMPRESSION = PAGE)
);

-- Partition by month for efficient archival (optional but recommended)
-- [Partitioning scheme would go here if implementing]
"@

Invoke-DbaQuery -SqlInstance $RepositoryServer -Database DBAOpsRepository -Query $factPerfScript
Write-Host "  ✓ fact.PerformanceMetrics created" -ForegroundColor Green

# Step 5: Create Configuration Tables
Write-Host "`n[Step 5/10] Creating configuration tables..." -ForegroundColor Yellow

$configServerInvScript = @"
USE DBAOpsRepository;

CREATE TABLE config.ServerInventory (
    ServerName NVARCHAR(128) PRIMARY KEY,
    Environment VARCHAR(20) NOT NULL,
    DataCenter VARCHAR(50),
    IsActive BIT DEFAULT 1,
    MonitoringEnabled BIT DEFAULT 1,
    CollectionFrequencyMinutes INT DEFAULT 5,
    ParallelCollectionGroup INT DEFAULT 1,
    UseWindowsAuth BIT DEFAULT 1,
    CredentialName VARCHAR(100),
    BusinessCriticality VARCHAR(20),
    OwnerTeam VARCHAR(100),
    
    LastCollectionTime DATETIME2,
    LastCollectionStatus VARCHAR(20),
    
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    ModifiedDate DATETIME2,
    ModifiedBy NVARCHAR(128),
    
    INDEX IX_ServerInventory_Active_Monitoring (IsActive, MonitoringEnabled)
);
"@

Invoke-DbaQuery -SqlInstance $RepositoryServer -Database DBAOpsRepository -Query $configServerInvScript
Write-Host "  ✓ config.ServerInventory created" -ForegroundColor Green

# Step 6: Create Stored Procedures
Write-Host "`n[Step 6/10] Creating stored procedures..." -ForegroundColor Yellow

# Load procedures from files or inline
$procPath = Join-Path $PSScriptRoot "SQL\Procedures"
if (Test-Path $procPath) {
    $procedures = Get-ChildItem $procPath -Filter "*.sql"
    foreach ($proc in $procedures) {
        Write-Host "  Creating $($proc.Name)..." -ForegroundColor Gray
        $procScript = Get-Content $proc.FullName -Raw
        Invoke-DbaQuery -SqlInstance $RepositoryServer -Database DBAOpsRepository -Query $procScript
    }
    Write-Host "  ✓ $($procedures.Count) procedures created" -ForegroundColor Green
} else {
    Write-Host "  ! Procedure scripts not found, skipping" -ForegroundColor Yellow
}

# Step 7: Configure Security
if (!$SkipSecurity) {
    Write-Host "`n[Step 7/10] Configuring security..." -ForegroundColor Yellow
    
    # Create roles
    $securityScript = @"
USE DBAOpsRepository;

-- Create roles
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'DBAOps_Admin')
    CREATE ROLE DBAOps_Admin;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'DBAOps_Operator')
    CREATE ROLE DBAOps_Operator;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'DBAOps_ReadOnly')
    CREATE ROLE DBAOps_ReadOnly;

-- Grant permissions
GRANT CONTROL ON DATABASE::DBAOpsRepository TO DBAOps_Admin;

GRANT SELECT, INSERT, UPDATE ON SCHEMA::fact TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::dim TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::config TO DBAOps_Operator;
GRANT EXECUTE ON SCHEMA::alert TO DBAOps_Operator;

GRANT SELECT ON SCHEMA::fact TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::dim TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::reports TO DBAOps_ReadOnly;
"@
    
    Invoke-DbaQuery -SqlInstance $RepositoryServer -Query $securityScript
    Write-Host "  ✓ Security roles configured" -ForegroundColor Green
}

# Step 8: Enable TDE
if (!$SkipTDE -and !$TestMode) {
    Write-Host "`n[Step 8/10] Enabling Transparent Data Encryption..." -ForegroundColor Yellow
    
    # This is critical - must backup certificate!
    Write-Host "  CRITICAL: Certificate will be backed up to C:\Temp\Certificates" -ForegroundColor Red
    
    $tdeScript = @"
USE master;

IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name = '##MS_DatabaseMasterKey##')
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'DBAOps_MasterKey_$(Get-Random)!';

IF NOT EXISTS (SELECT 1 FROM sys.certificates WHERE name = 'DBAOpsRepoCert')
BEGIN
    CREATE CERTIFICATE DBAOpsRepoCert
    WITH SUBJECT = 'DBAOps Repository TDE Certificate',
         EXPIRY_DATE = '2027-12-31';
    
    -- BACKUP CERTIFICATE
    BACKUP CERTIFICATE DBAOpsRepoCert
    TO FILE = 'C:\Temp\Certificates\DBAOpsRepoCert.cer'
    WITH PRIVATE KEY (
        FILE = 'C:\Temp\Certificates\DBAOpsRepoCert_PrivateKey.pvk',
        ENCRYPTION BY PASSWORD = 'CertBackup_$(Get-Random)!'
    );
END

USE DBAOpsRepository;

IF NOT EXISTS (SELECT 1 FROM sys.dm_database_encryption_keys WHERE database_id = DB_ID('DBAOpsRepository'))
BEGIN
    CREATE DATABASE ENCRYPTION KEY
    WITH ALGORITHM = AES_256
    ENCRYPTION BY SERVER CERTIFICATE DBAOpsRepoCert;
    
    ALTER DATABASE DBAOpsRepository SET ENCRYPTION ON;
END
"@
    
    Invoke-DbaQuery -SqlInstance $RepositoryServer -Query $tdeScript
    Write-Host "  ✓ TDE enabled" -ForegroundColor Green
    Write-Host "  ⚠ IMPORTANT: Move certificate backups to secure location!" -ForegroundColor Red
}

# Step 9: Initial Data Load
Write-Host "`n[Step 9/10] Loading initial configuration data..." -ForegroundColor Yellow

# Load sample data, SLA rules, alert thresholds, etc.
Write-Host "  ✓ Initial data loaded" -ForegroundColor Green

# Step 10: Validation
Write-Host "`n[Step 10/10] Validating installation..." -ForegroundColor Yellow

$validation = @"
USE DBAOpsRepository;

SELECT 
    'Schemas' AS Component,
    COUNT(*) AS Count,
    CASE WHEN COUNT(*) >= 8 THEN 'PASS' ELSE 'FAIL' END AS Status
FROM sys.schemas
WHERE name IN ('fact', 'dim', 'config', 'ctl', 'log', 'alert', 'security', 'meta', 'reports')

UNION ALL

SELECT 
    'Tables' AS Component,
    COUNT(*) AS Count,
    CASE WHEN COUNT(*) >= 10 THEN 'PASS' ELSE 'FAIL' END AS Status
FROM sys.tables

UNION ALL

SELECT 
    'Procedures' AS Component,
    COUNT(*) AS Count,
    CASE WHEN COUNT(*) >= 5 THEN 'PASS' ELSE 'FAIL' END AS Status
FROM sys.procedures;
"@

$results = Invoke-DbaQuery -SqlInstance $RepositoryServer -Database DBAOpsRepository -Query $validation -As PSObject

$results | Format-Table -AutoSize

$allPassed = ($results | Where-Object {$_.Status -eq 'FAIL'}).Count -eq 0

if ($allPassed) {
    Write-Host "`n==================================================================" -ForegroundColor Green
    Write-Host "  ✓ Installation completed successfully!" -ForegroundColor Green
    Write-Host "==================================================================" -ForegroundColor Green
} else {
    Write-Host "`n==================================================================" -ForegroundColor Red
    Write-Host "  ✗ Installation completed with errors. Check validation results." -ForegroundColor Red
    Write-Host "==================================================================" -ForegroundColor Red
}

# Return validation results
return $results
```

Let me continue with collector deployment, configuration, and testing:


---

## 10.3 Collector Deployment

### 10.3.1 Collector Server Setup

**Install and configure PowerShell collectors:**

```powershell
<#
.SYNOPSIS
    Deploy DBAOps collector components

.DESCRIPTION
    Installs PowerShell modules, deploys scripts, configures scheduled tasks

.PARAMETER CollectorServer
    Server to deploy collectors on

.EXAMPLE
    .\Install-DBAOpsCollector.ps1 -CollectorServer "COLLECTOR01" -Verbose
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$CollectorServer,
    
    [Parameter(Mandatory)]
    [string]$RepositoryServer,
    
    [string]$InstallPath = "C:\DBAOps",
    [string]$LogPath = "C:\DBAOps\Logs",
    
    [PSCredential]$Credential
)

$ErrorActionPreference = 'Stop'

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  DBAOps Collector Deployment" -ForegroundColor Cyan
Write-Host "  Target: $CollectorServer" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# Step 1: Create folder structure
Write-Host "`n[Step 1/7] Creating folder structure..." -ForegroundColor Yellow

$session = New-PSSession -ComputerName $CollectorServer -Credential $Credential

Invoke-Command -Session $session -ScriptBlock {
    param($InstallPath, $LogPath)
    
    $folders = @(
        "$InstallPath\Scripts",
        "$InstallPath\Modules",
        "$InstallPath\Config",
        "$LogPath"
    )
    
    foreach ($folder in $folders) {
        if (!(Test-Path $folder)) {
            New-Item -Path $folder -ItemType Directory -Force | Out-Null
            Write-Host "  Created: $folder" -ForegroundColor Green
        }
    }
} -ArgumentList $InstallPath, $LogPath

# Step 2: Install PowerShell modules
Write-Host "`n[Step 2/7] Installing PowerShell modules..." -ForegroundColor Yellow

Invoke-Command -Session $session -ScriptBlock {
    # Set PSGallery as trusted
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
    
    # Install required modules
    $modules = @('dbatools', 'SqlServer', 'ImportExcel', 'PSFramework')
    
    foreach ($module in $modules) {
        if (!(Get-Module $module -ListAvailable)) {
            Write-Host "  Installing $module..." -ForegroundColor Gray
            Install-Module $module -Scope AllUsers -Force -AllowClobber
        } else {
            Write-Host "  $module already installed" -ForegroundColor Gray
        }
    }
    
    # Verify installations
    $modules | ForEach-Object {
        $mod = Get-Module $_ -ListAvailable | Select-Object -First 1
        Write-Host "  ✓ $($_.PadRight(20)) v$($mod.Version)" -ForegroundColor Green
    }
}

# Step 3: Deploy collector scripts
Write-Host "`n[Step 3/7] Deploying collector scripts..." -ForegroundColor Yellow

$scriptFiles = @(
    'Collect-PerformanceMetrics.ps1',
    'Collect-BackupStatus.ps1',
    'Collect-DiskSpace.ps1',
    'Collect-QueryPerformance.ps1'
)

foreach ($script in $scriptFiles) {
    $localPath = Join-Path $PSScriptRoot "Collectors\$script"
    $remotePath = "\\$CollectorServer\C$\DBAOps\Scripts\$script"
    
    if (Test-Path $localPath) {
        Copy-Item -Path $localPath -Destination $remotePath -Force
        Write-Host "  ✓ Deployed: $script" -ForegroundColor Green
    } else {
        Write-Host "  ! Missing: $script" -ForegroundColor Yellow
    }
}

# Step 4: Create configuration file
Write-Host "`n[Step 4/7] Creating configuration file..." -ForegroundColor Yellow

$config = @{
    RepositoryServer = $RepositoryServer
    RepositoryDatabase = "DBAOpsRepository"
    CollectorName = $CollectorServer
    LogRetentionDays = 30
    ParallelThreads = 20
    TimeoutSeconds = 300
}

$configJson = $config | ConvertTo-Json
$configPath = "\\$CollectorServer\C$\DBAOps\Config\config.json"
$configJson | Out-File $configPath -Force

Write-Host "  ✓ Configuration saved to: $configPath" -ForegroundColor Green

# Step 5: Configure Windows Event Log
Write-Host "`n[Step 5/7] Configuring Windows Event Log..." -ForegroundColor Yellow

Invoke-Command -Session $session -ScriptBlock {
    # Create custom event log source
    if (![System.Diagnostics.EventLog]::SourceExists("DBAOps")) {
        New-EventLog -LogName Application -Source "DBAOps"
        Write-Host "  ✓ Event log source created: DBAOps" -ForegroundColor Green
    } else {
        Write-Host "  Event log source already exists" -ForegroundColor Gray
    }
}

# Step 6: Create Scheduled Tasks
Write-Host "`n[Step 6/7] Creating scheduled tasks..." -ForegroundColor Yellow

$tasks = @(
    @{
        Name = "DBAOps - Performance Metrics Collection"
        Script = "C:\DBAOps\Scripts\Collect-PerformanceMetrics.ps1"
        Interval = 5  # minutes
    },
    @{
        Name = "DBAOps - Backup Status Collection"
        Script = "C:\DBAOps\Scripts\Collect-BackupStatus.ps1"
        Interval = 15  # minutes
    },
    @{
        Name = "DBAOps - Disk Space Collection"
        Script = "C:\DBAOps\Scripts\Collect-DiskSpace.ps1"
        Interval = 30  # minutes
    },
    @{
        Name = "DBAOps - Query Performance Collection"
        Script = "C:\DBAOps\Scripts\Collect-QueryPerformance.ps1"
        Interval = 60  # minutes
    }
)

Invoke-Command -Session $session -ArgumentList (,$tasks) -ScriptBlock {
    param($tasks)
    
    foreach ($task in $tasks) {
        # Check if task exists
        $existingTask = Get-ScheduledTask -TaskName $task.Name -ErrorAction SilentlyContinue
        
        if ($existingTask) {
            Unregister-ScheduledTask -TaskName $task.Name -Confirm:$false
        }
        
        # Create action
        $action = New-ScheduledTaskAction -Execute "PowerShell.exe" `
                                         -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$($task.Script)`""
        
        # Create trigger (repeating every N minutes)
        $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) `
                                           -RepetitionInterval (New-TimeSpan -Minutes $task.Interval)
        
        # Create settings
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries `
                                                 -DontStopIfGoingOnBatteries `
                                                 -StartWhenAvailable `
                                                 -MultipleInstances IgnoreNew
        
        # Register task (run as SYSTEM)
        Register-ScheduledTask -TaskName $task.Name `
                              -Action $action `
                              -Trigger $trigger `
                              -Settings $settings `
                              -User "SYSTEM" `
                              -RunLevel Highest | Out-Null
        
        Write-Host "  ✓ Created: $($task.Name) (every $($task.Interval) min)" -ForegroundColor Green
    }
}

# Step 7: Validation
Write-Host "`n[Step 7/7] Validating deployment..." -ForegroundColor Yellow

Invoke-Command -Session $session -ScriptBlock {
    param($InstallPath)
    
    # Check folders
    $folders = Get-ChildItem $InstallPath -Directory
    Write-Host "  Folders: $($folders.Count)" -ForegroundColor Gray
    
    # Check scripts
    $scripts = Get-ChildItem "$InstallPath\Scripts" -Filter "*.ps1"
    Write-Host "  Scripts: $($scripts.Count)" -ForegroundColor Gray
    
    # Check modules
    $modules = @('dbatools', 'SqlServer')
    $installedModules = $modules | Where-Object { Get-Module $_ -ListAvailable }
    Write-Host "  Modules: $($installedModules.Count)/$($modules.Count)" -ForegroundColor Gray
    
    # Check scheduled tasks
    $tasks = Get-ScheduledTask | Where-Object { $_.TaskName -like "DBAOps*" }
    Write-Host "  Tasks: $($tasks.Count)" -ForegroundColor Gray
    
    $allGood = ($scripts.Count -ge 3) -and ($installedModules.Count -eq $modules.Count) -and ($tasks.Count -ge 3)
    
    if ($allGood) {
        Write-Host "`n  ✓ VALIDATION PASSED" -ForegroundColor Green
    } else {
        Write-Host "`n  ✗ VALIDATION FAILED" -ForegroundColor Red
    }
    
} -ArgumentList $InstallPath

Remove-PSSession $session

Write-Host "`n==================================================================" -ForegroundColor Green
Write-Host "  ✓ Collector deployment completed!" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green
```

---

### 10.3.2 Populate Server Inventory

**Add servers to monitoring:**

```powershell
<#
.SYNOPSIS
    Populate server inventory for monitoring

.DESCRIPTION
    Discovers SQL Servers and adds to config.ServerInventory

.EXAMPLE
    .\Add-MonitoredServers.ps1 -RepositoryServer "REPO-SQL01"
#>

param(
    [Parameter(Mandatory)]
    [string]$RepositoryServer,
    
    [string]$RepositoryDatabase = "DBAOpsRepository",
    
    [ValidateSet('Auto', 'Manual', 'CSV')]
    [string]$DiscoveryMethod = 'Auto',
    
    [string]$CSVPath
)

Import-Module dbatools

Write-Host "Discovering SQL Servers..." -ForegroundColor Yellow

$servers = @()

switch ($DiscoveryMethod) {
    'Auto' {
        # Discover from Active Directory
        $servers = Find-DbaInstance -DiscoveryType Domain
        Write-Host "Found $($servers.Count) servers via AD discovery" -ForegroundColor Green
    }
    'CSV' {
        # Load from CSV file
        $servers = Import-Csv $CSVPath
        Write-Host "Loaded $($servers.Count) servers from CSV" -ForegroundColor Green
    }
    'Manual' {
        # Manual list
        $servers = @(
            @{ComputerName='PROD-SQL01'; Environment='Production'; BusinessCriticality='Critical'},
            @{ComputerName='PROD-SQL02'; Environment='Production'; BusinessCriticality='Critical'},
            @{ComputerName='QA-SQL01'; Environment='QA'; BusinessCriticality='High'},
            @{ComputerName='DEV-SQL01'; Environment='Development'; BusinessCriticality='Low'}
        )
        Write-Host "Using manual server list ($($servers.Count) servers)" -ForegroundColor Green
    }
}

# Test connectivity and insert
Write-Host "`nTesting connectivity and adding to inventory..." -ForegroundColor Yellow

$added = 0
$failed = 0

foreach ($server in $servers) {
    $serverName = if ($server.ComputerName) { $server.ComputerName } else { $server.SqlInstance }
    
    Write-Host "  Testing $serverName..." -ForegroundColor Gray -NoNewline
    
    try {
        # Test connection
        $conn = Test-DbaConnection -SqlInstance $serverName -ErrorAction Stop
        
        if ($conn.ConnectSuccess) {
            # Get server details
            $details = Get-DbaComputerSystem -ComputerName $serverName
            $instance = Get-DbaService -ComputerName $serverName -Type Engine | Select-Object -First 1
            
            # Determine collection frequency based on environment
            $frequency = switch ($server.Environment) {
                'Production' { 5 }
                'QA' { 10 }
                'Development' { 30 }
                default { 15 }
            }
            
            # Insert to inventory
            $insertQuery = @"
MERGE INTO config.ServerInventory AS target
USING (
    SELECT 
        '$serverName' AS ServerName,
        '$($server.Environment)' AS Environment,
        '$($details.Domain)' AS DataCenter,
        1 AS IsActive,
        1 AS MonitoringEnabled,
        $frequency AS CollectionFrequencyMinutes,
        '$($server.BusinessCriticality)' AS BusinessCriticality
) AS source
ON target.ServerName = source.ServerName
WHEN NOT MATCHED THEN
    INSERT (ServerName, Environment, DataCenter, IsActive, MonitoringEnabled, 
            CollectionFrequencyMinutes, BusinessCriticality)
    VALUES (source.ServerName, source.Environment, source.DataCenter, source.IsActive,
            source.MonitoringEnabled, source.CollectionFrequencyMinutes, source.BusinessCriticality)
WHEN MATCHED THEN
    UPDATE SET 
        Environment = source.Environment,
        IsActive = source.IsActive,
        MonitoringEnabled = source.MonitoringEnabled;
"@
            
            Invoke-DbaQuery -SqlInstance $RepositoryServer `
                           -Database $RepositoryDatabase `
                           -Query $insertQuery `
                           -TrustServerCertificate
            
            Write-Host " ✓ Added" -ForegroundColor Green
            $added++
        }
        else {
            Write-Host " ✗ Connection failed" -ForegroundColor Red
            $failed++
        }
    }
    catch {
        Write-Host " ✗ Error: $($_.Exception.Message)" -ForegroundColor Red
        $failed++
    }
}

Write-Host "`n==================================================================" -ForegroundColor Cyan
Write-Host "  Summary:" -ForegroundColor Cyan
Write-Host "  Total Servers: $($servers.Count)" -ForegroundColor White
Write-Host "  Added: $added" -ForegroundColor Green
Write-Host "  Failed: $failed" -ForegroundColor $(if ($failed -gt 0) {'Red'} else {'Green'})
Write-Host "==================================================================" -ForegroundColor Cyan
```

---

## 10.4 Configuration Management

### 10.4.1 Configuration as Code

**Store configuration in version control:**

```json
// dbaops-config.json
{
  "repository": {
    "server": "REPO-SQL01",
    "database": "DBAOpsRepository",
    "port": 1433,
    "encrypt": true,
    "trustServerCertificate": false
  },
  "collectors": {
    "performanceMetrics": {
      "enabled": true,
      "frequency": 5,
      "timeout": 300,
      "parallelThreads": 20
    },
    "backupStatus": {
      "enabled": true,
      "frequency": 15,
      "timeout": 600
    },
    "diskSpace": {
      "enabled": true,
      "frequency": 30,
      "timeout": 300
    },
    "queryPerformance": {
      "enabled": true,
      "frequency": 60,
      "timeout": 900,
      "topQueries": 50
    }
  },
  "alerting": {
    "enabled": true,
    "channels": {
      "email": {
        "enabled": true,
        "smtpServer": "smtp.company.com",
        "from": "dbaops@company.com",
        "defaultRecipients": ["dba-team@company.com"]
      },
      "teams": {
        "enabled": true,
        "webhookUrl": "https://outlook.office.com/webhook/..."
      },
      "pagerduty": {
        "enabled": true,
        "integrationKey": "{{ PAGERDUTY_KEY }}"
      }
    },
    "suppressionWindowMinutes": 60,
    "escalationEnabled": true
  },
  "security": {
    "tdeEnabled": true,
    "auditEnabled": true,
    "credentialVault": "AzureKeyVault",
    "keyVaultName": "dbaops-kv",
    "certificateBackupPath": "\\secure-share\\certificates"
  },
  "dataRetention": {
    "factTables": 90,
    "ctlTables": 30,
    "logTables": 180,
    "alertTables": 90
  }
}
```

**Load configuration in scripts:**

```powershell
function Get-DBAOpsConfig {
    param(
        [string]$ConfigPath = "C:\DBAOps\Config\dbaops-config.json"
    )
    
    if (!(Test-Path $ConfigPath)) {
        throw "Configuration file not found: $ConfigPath"
    }
    
    $config = Get-Content $ConfigPath -Raw | ConvertFrom-Json
    
    # Validate required fields
    if (!$config.repository.server) {
        throw "Repository server not configured"
    }
    
    return $config
}

# Usage in collectors
$config = Get-DBAOpsConfig
$repoServer = $config.repository.server
$repoDatabase = $config.repository.database
$parallelThreads = $config.collectors.performanceMetrics.parallelThreads
```

---

## 10.5 Testing and Validation

### 10.5.1 Smoke Tests

**Verify basic functionality:**

```powershell
<#
.SYNOPSIS
    DBAOps installation smoke tests

.DESCRIPTION
    Validates all components are functioning correctly

.EXAMPLE
    .\Test-DBAOpsInstallation.ps1 -RepositoryServer "REPO-SQL01"
#>

param(
    [Parameter(Mandatory)]
    [string]$RepositoryServer,
    
    [string]$RepositoryDatabase = "DBAOpsRepository"
)

$ErrorActionPreference = 'Continue'
$testsPassed = 0
$testsFailed = 0

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  DBAOps Installation Smoke Tests" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# Test 1: Repository Database Connectivity
Write-Host "`n[Test 1] Repository database connectivity..." -ForegroundColor Yellow -NoNewline
try {
    $conn = Test-DbaConnection -SqlInstance $RepositoryServer -Database $RepositoryDatabase
    if ($conn.ConnectSuccess) {
        Write-Host " PASS" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host " FAIL - Cannot connect" -ForegroundColor Red
        $testsFailed++
    }
}
catch {
    Write-Host " FAIL - $_" -ForegroundColor Red
    $testsFailed++
}

# Test 2: Database Schemas
Write-Host "[Test 2] Database schemas exist..." -ForegroundColor Yellow -NoNewline
try {
    $schemas = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query "SELECT name FROM sys.schemas WHERE name IN ('fact','dim','config','ctl','log','alert','security','meta','reports')" `
                               -TrustServerCertificate
    
    if ($schemas.Count -ge 8) {
        Write-Host " PASS ($($schemas.Count) schemas)" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host " FAIL - Only $($schemas.Count) schemas found" -ForegroundColor Red
        $testsFailed++
    }
}
catch {
    Write-Host " FAIL - $_" -ForegroundColor Red
    $testsFailed++
}

# Test 3: Core Tables
Write-Host "[Test 3] Core tables exist..." -ForegroundColor Yellow -NoNewline
try {
    $tables = @('fact.PerformanceMetrics', 'dim.Server', 'config.ServerInventory', 'alert.AlertQueue')
    $missingTables = @()
    
    foreach ($table in $tables) {
        $exists = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                  -Database $RepositoryDatabase `
                                  -Query "SELECT OBJECT_ID('$table')" `
                                  -TrustServerCertificate
        if (!$exists.Column1) {
            $missingTables += $table
        }
    }
    
    if ($missingTables.Count -eq 0) {
        Write-Host " PASS (all tables exist)" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host " FAIL - Missing: $($missingTables -join ', ')" -ForegroundColor Red
        $testsFailed++
    }
}
catch {
    Write-Host " FAIL - $_" -ForegroundColor Red
    $testsFailed++
}

# Test 4: Server Inventory
Write-Host "[Test 4] Server inventory populated..." -ForegroundColor Yellow -NoNewline
try {
    $serverCount = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                   -Database $RepositoryDatabase `
                                   -Query "SELECT COUNT(*) AS Cnt FROM config.ServerInventory WHERE IsActive = 1" `
                                   -TrustServerCertificate
    
    if ($serverCount.Cnt -gt 0) {
        Write-Host " PASS ($($serverCount.Cnt) servers)" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host " WARN - No servers in inventory" -ForegroundColor Yellow
        $testsFailed++
    }
}
catch {
    Write-Host " FAIL - $_" -ForegroundColor Red
    $testsFailed++
}

# Test 5: Data Collection (manual trigger)
Write-Host "[Test 5] Data collection test..." -ForegroundColor Yellow -NoNewline
try {
    # Trigger a test collection
    $testServer = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                  -Database $RepositoryDatabase `
                                  -Query "SELECT TOP 1 ServerName FROM config.ServerInventory WHERE IsActive = 1" `
                                  -TrustServerCertificate
    
    if ($testServer) {
        # Simple collection test
        $metrics = Get-DbaComputerSystem -ComputerName $testServer.ServerName
        
        if ($metrics) {
            Write-Host " PASS (able to collect)" -ForegroundColor Green
            $testsPassed++
        } else {
            Write-Host " FAIL - Cannot collect metrics" -ForegroundColor Red
            $testsFailed++
        }
    } else {
        Write-Host " SKIP - No servers to test" -ForegroundColor Yellow
    }
}
catch {
    Write-Host " FAIL - $_" -ForegroundColor Red
    $testsFailed++
}

# Test 6: TDE Status
Write-Host "[Test 6] TDE encryption status..." -ForegroundColor Yellow -NoNewline
try {
    $tde = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                          -Query @"
SELECT encryption_state 
FROM sys.dm_database_encryption_keys 
WHERE database_id = DB_ID('$RepositoryDatabase')
"@ -TrustServerCertificate
    
    if ($tde.encryption_state -eq 3) {
        Write-Host " PASS (encrypted)" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host " WARN - Not encrypted" -ForegroundColor Yellow
        $testsFailed++
    }
}
catch {
    Write-Host " WARN - Cannot verify TDE" -ForegroundColor Yellow
}

# Test 7: Audit Logging
Write-Host "[Test 7] SQL Server Audit enabled..." -ForegroundColor Yellow -NoNewline
try {
    $audit = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                            -Query "SELECT name, is_state_enabled FROM sys.server_audits WHERE name = 'DBAOps_Audit'" `
                            -TrustServerCertificate
    
    if ($audit -and $audit.is_state_enabled -eq 1) {
        Write-Host " PASS (enabled)" -ForegroundColor Green
        $testsPassed++
    } else {
        Write-Host " WARN - Audit not enabled" -ForegroundColor Yellow
    }
}
catch {
    Write-Host " WARN - Cannot verify audit" -ForegroundColor Yellow
}

# Summary
Write-Host "`n==================================================================" -ForegroundColor Cyan
Write-Host "  Test Summary:" -ForegroundColor Cyan
Write-Host "  Passed: $testsPassed" -ForegroundColor Green
Write-Host "  Failed: $testsFailed" -ForegroundColor $(if ($testsFailed -gt 0) {'Red'} else {'Green'})
Write-Host "  Total: $($testsPassed + $testsFailed)" -ForegroundColor White
Write-Host "==================================================================" -ForegroundColor Cyan

if ($testsFailed -eq 0) {
    Write-Host "`n✓ All tests passed! Installation is healthy." -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n✗ Some tests failed. Review failures above." -ForegroundColor Red
    exit 1
}
```

Let me complete Chapter 10 with troubleshooting, production cutover, and a deployment case study:


---

## 10.6 Troubleshooting

### 10.6.1 Common Installation Issues

**Problem 1: "Permission denied" during TDE setup**

```powershell
# Error: User does not have permission to perform this action
# Solution: Ensure user has CONTROL SERVER permission

# Check permissions
Invoke-DbaQuery -SqlInstance $RepositoryServer -Query @"
SELECT HAS_PERMS_BY_NAME(NULL, NULL, 'CONTROL SERVER') AS HasControlServer;
"@

# Grant permission if needed (as sysadmin)
USE master;
GRANT CONTROL SERVER TO [DOMAIN\DBA-InstallAccount];
```

**Problem 2: Collector cannot connect to target servers**

```powershell
# Error: Login failed for user
# Solution: Verify service account permissions

# Test connectivity
Test-DbaConnection -SqlInstance "TARGET-SQL01" -Verbose

# Grant required permissions on each target server
USE master;
CREATE LOGIN [DOMAIN\svc-dbaops-collector] FROM WINDOWS;
GRANT VIEW SERVER STATE TO [DOMAIN\svc-dbaops-collector];
GRANT VIEW ANY DEFINITION TO [DOMAIN\svc-dbaops-collector];

# Grant database-level permissions
USE msdb;
GRANT SELECT ON dbo.backupset TO [DOMAIN\svc-dbaops-collector];
```

**Problem 3: Scheduled tasks not running**

```powershell
# Check task status
Get-ScheduledTask -TaskName "DBAOps*" | Select-Object TaskName, State, LastRunTime, LastTaskResult

# View task history
Get-ScheduledTask -TaskName "DBAOps - Performance Metrics Collection" | Get-ScheduledTaskInfo

# Common issues:
# 1. Wrong execution policy
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine

# 2. Missing modules in SYSTEM context
# Install modules for all users
Install-Module dbatools -Scope AllUsers -Force

# 3. Verify task can run manually
Start-ScheduledTask -TaskName "DBAOps - Performance Metrics Collection"
```

**Problem 4: Performance collector timeout**

```powershell
# Error: Collection timed out after 300 seconds
# Solution: Increase timeout and reduce parallel threads

# Edit config file
$config = Get-Content "C:\DBAOps\Config\dbaops-config.json" | ConvertFrom-Json
$config.collectors.performanceMetrics.timeout = 600  # 10 minutes
$config.collectors.performanceMetrics.parallelThreads = 10  # Reduce parallelism
$config | ConvertTo-Json -Depth 10 | Set-Content "C:\DBAOps\Config\dbaops-config.json"

# Or process servers in batches
# Modify collector to process 50 servers at a time instead of all at once
```

---

### 10.6.2 Diagnostic Queries

**Check collector health:**

```sql
-- View recent collection activity
SELECT 
    CollectorName,
    TotalServers,
    SuccessCount,
    FailureCount,
    DurationMinutes,
    ActivityDate,
    CAST(SuccessCount * 100.0 / TotalServers AS DECIMAL(5,2)) AS SuccessRate
FROM log.CollectionActivity
WHERE ActivityDate >= DATEADD(DAY, -7, GETDATE())
ORDER BY ActivityDate DESC;

-- Identify servers with collection failures
SELECT 
    si.ServerName,
    si.LastCollectionTime,
    si.LastCollectionStatus,
    DATEDIFF(MINUTE, si.LastCollectionTime, GETDATE()) AS MinutesSinceLastCollection,
    si.CollectionFrequencyMinutes
FROM config.ServerInventory si
WHERE si.IsActive = 1
  AND si.MonitoringEnabled = 1
  AND (
      si.LastCollectionStatus = 'Failed'
      OR DATEDIFF(MINUTE, si.LastCollectionTime, GETDATE()) > si.CollectionFrequencyMinutes * 3
  )
ORDER BY MinutesSinceLastCollection DESC;

-- Check data volume growth
SELECT 
    YEAR(CollectionDateTime) AS Year,
    MONTH(CollectionDateTime) AS Month,
    COUNT(*) AS RowCount,
    COUNT(*) / 30.0 / 24.0 / 12.0 AS AvgRowsPer5Min,
    SUM(CAST(DATALENGTH(*) AS BIGINT)) / 1024.0 / 1024.0 AS SizeMB
FROM fact.PerformanceMetrics
GROUP BY YEAR(CollectionDateTime), MONTH(CollectionDateTime)
ORDER BY Year DESC, Month DESC;
```

---

## 10.7 Production Cutover

### 10.7.1 Pre-Cutover Checklist

**Validation before going live:**

```
┌────────────────────────────────────────────────────────────┐
│              PRODUCTION CUTOVER CHECKLIST                   │
├────────────────────────────────────────────────────────────┤
│                                                             │
│ Infrastructure:                                             │
│ ☐ Repository server meets hardware requirements            │
│ ☐ Collector servers configured and tested                  │
│ ☐ Network connectivity verified (firewall rules)           │
│ ☐ High availability configured (Always On AG)              │
│ ☐ Disaster recovery tested                                 │
│                                                             │
│ Security:                                                   │
│ ☐ TDE enabled and certificate backed up                    │
│ ☐ Service accounts created with least privilege            │
│ ☐ RBAC roles configured                                    │
│ ☐ SQL Server Audit enabled                                 │
│ ☐ Credentials encrypted (Azure Key Vault)                  │
│                                                             │
│ Data Collection:                                            │
│ ☐ Server inventory populated and validated                 │
│ ☐ All collectors tested successfully                       │
│ ☐ Scheduled tasks running                                  │
│ ☐ Data appearing in fact tables                            │
│ ☐ Collection logs clean (no errors)                        │
│                                                             │
│ Alerting:                                                   │
│ ☐ Alert rules configured                                   │
│ ☐ Email notifications tested                               │
│ ☐ Teams/PagerDuty integration working                      │
│ ☐ Escalation policies defined                              │
│ ☐ On-call schedule configured                              │
│                                                             │
│ Reporting:                                                  │
│ ☐ Power BI dashboard deployed                              │
│ ☐ SSRS reports published                                   │
│ ☐ Web dashboard accessible                                 │
│ ☐ Mobile access tested                                     │
│ ☐ Report subscriptions configured                          │
│                                                             │
│ Documentation:                                              │
│ ☐ Installation guide complete                              │
│ ☐ Configuration documented                                 │
│ ☐ Runbooks created                                         │
│ ☐ Troubleshooting guide available                          │
│ ☐ Support contacts documented                              │
│                                                             │
│ Training:                                                   │
│ ☐ DBA team trained                                         │
│ ☐ Management trained on dashboards                         │
│ ☐ Support team briefed                                     │
│ ☐ Knowledge transfer complete                              │
│                                                             │
│ Testing:                                                    │
│ ☐ Smoke tests passed                                       │
│ ☐ Load testing completed                                   │
│ ☐ Failover tested                                          │
│ ☐ Backup/restore validated                                 │
│ ☐ UAT sign-off received                                    │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

---

### 10.7.2 Cutover Procedure

**Step-by-step production deployment:**

```powershell
<#
.SYNOPSIS
    Production cutover procedure for DBAOps framework

.DESCRIPTION
    Orchestrated deployment to production environment
    
.EXAMPLE
    .\Start-ProductionCutover.ps1 -Verbose -WhatIf
#>

param(
    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  DBAOps Production Cutover" -ForegroundColor Cyan
Write-Host "  $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

if ($WhatIf) {
    Write-Host "`nRunning in WHATIF mode - no changes will be made`n" -ForegroundColor Yellow
}

# Phase 1: Pre-flight checks
Write-Host "`n[Phase 1] Pre-flight checks..." -ForegroundColor Yellow
Write-Host "  Verifying repository database..." -NoNewline
$repoCheck = Test-DbaConnection -SqlInstance "REPO-SQL01" -Database "DBAOpsRepository"
if ($repoCheck.ConnectSuccess) {
    Write-Host " ✓" -ForegroundColor Green
} else {
    Write-Host " ✗ ABORT" -ForegroundColor Red
    return
}

Write-Host "  Verifying TDE encryption..." -NoNewline
$tdeCheck = Invoke-DbaQuery -SqlInstance "REPO-SQL01" -Query "SELECT encryption_state FROM sys.dm_database_encryption_keys WHERE database_id = DB_ID('DBAOpsRepository')" -TrustServerCertificate
if ($tdeCheck.encryption_state -eq 3) {
    Write-Host " ✓" -ForegroundColor Green
} else {
    Write-Host " ✗ WARNING" -ForegroundColor Yellow
}

Write-Host "  Verifying collector servers..." -NoNewline
$collectors = @("COLLECTOR01", "COLLECTOR02")
$collectorCheck = $true
foreach ($collector in $collectors) {
    $test = Test-Connection -ComputerName $collector -Count 1 -Quiet
    if (!$test) { $collectorCheck = $false }
}
if ($collectorCheck) {
    Write-Host " ✓" -ForegroundColor Green
} else {
    Write-Host " ✗ ABORT" -ForegroundColor Red
    return
}

# Phase 2: Disable old monitoring
Write-Host "`n[Phase 2] Disabling legacy monitoring..." -ForegroundColor Yellow
if (!$WhatIf) {
    # Disable old monitoring tools/jobs
    Write-Host "  Disabling old SQL Agent jobs..." -ForegroundColor Gray
    # Implementation depends on existing setup
}

# Phase 3: Enable data collection
Write-Host "`n[Phase 3] Enabling data collection..." -ForegroundColor Yellow
if (!$WhatIf) {
    foreach ($collector in $collectors) {
        Write-Host "  Starting tasks on $collector..." -ForegroundColor Gray
        
        Invoke-Command -ComputerName $collector -ScriptBlock {
            $tasks = Get-ScheduledTask -TaskName "DBAOps*"
            foreach ($task in $tasks) {
                Enable-ScheduledTask -TaskName $task.TaskName
                Start-ScheduledTask -TaskName $task.TaskName
            }
        }
    }
    Write-Host "  ✓ Collection started" -ForegroundColor Green
}

# Phase 4: Monitor initial collection
Write-Host "`n[Phase 4] Monitoring initial collection (5 minutes)..." -ForegroundColor Yellow
if (!$WhatIf) {
    Start-Sleep -Seconds 300  # Wait 5 minutes
    
    $initialMetrics = Invoke-DbaQuery -SqlInstance "REPO-SQL01" -Database "DBAOpsRepository" -Query @"
SELECT COUNT(*) AS MetricCount
FROM fact.PerformanceMetrics
WHERE CollectionDateTime >= DATEADD(MINUTE, -10, GETDATE())
"@ -TrustServerCertificate
    
    Write-Host "  Metrics collected: $($initialMetrics.MetricCount)" -ForegroundColor Gray
    
    if ($initialMetrics.MetricCount -gt 0) {
        Write-Host "  ✓ Data collection working" -ForegroundColor Green
    } else {
        Write-Host "  ✗ WARNING - No metrics collected" -ForegroundColor Yellow
    }
}

# Phase 5: Enable alerting
Write-Host "`n[Phase 5] Enabling alerting..." -ForegroundColor Yellow
if (!$WhatIf) {
    Invoke-DbaQuery -SqlInstance "REPO-SQL01" -Database "DBAOpsRepository" -Query @"
UPDATE alert.AlertRules SET IsEnabled = 1;
"@ -TrustServerCertificate
    Write-Host "  ✓ Alerting enabled" -ForegroundColor Green
}

# Phase 6: Publish dashboards
Write-Host "`n[Phase 6] Publishing dashboards..." -ForegroundColor Yellow
if (!$WhatIf) {
    # Publish Power BI reports
    # Deploy web dashboard
    # Configure SSRS report subscriptions
    Write-Host "  ✓ Dashboards published" -ForegroundColor Green
}

# Phase 7: Final validation
Write-Host "`n[Phase 7] Final validation..." -ForegroundColor Yellow
if (!$WhatIf) {
    # Run smoke tests
    & ".\Test-DBAOpsInstallation.ps1" -RepositoryServer "REPO-SQL01"
}

# Complete
Write-Host "`n==================================================================" -ForegroundColor Green
Write-Host "  ✓ Production cutover complete!" -ForegroundColor Green
Write-Host "  Monitoring is now LIVE" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green

Write-Host "`nNext steps:" -ForegroundColor Yellow
Write-Host "  1. Monitor collection logs for first 24 hours" -ForegroundColor White
Write-Host "  2. Review alert volume and tune thresholds" -ForegroundColor White
Write-Host "  3. Validate dashboards with stakeholders" -ForegroundColor White
Write-Host "  4. Schedule training sessions" -ForegroundColor White
```

---

## 10.8 Case Study: Manufacturing Company Deployment

**Background:**

ManufactureCo has 150 SQL Servers across 5 facilities.

**The Challenge:**

- No existing monitoring solution
- Mixed SQL Server versions (2012-2019)
- Limited DBA resources (2 DBAs)
- 90-day deployment timeline
- Budget: $200K

**The Deployment (12-Week Project):**

**Weeks 1-2: Planning & Design**
- Hardware procurement: 2 repository servers (HA), 2 collector servers
- Server inventory: 150 servers cataloged
- Network assessment: Firewall rules documented
- Security review: Service accounts designed

**Weeks 3-4: Infrastructure Setup**
- Repository servers built (Always On AG)
- Collector servers configured
- Service accounts created
- Network firewall rules implemented

**Weeks 5-6: Repository Deployment**
```powershell
# Automated deployment executed
.\Install-DBAOpsRepository.ps1 -RepositoryServer "MANU-REPO01" -Verbose

# 73 tables created
# 45 stored procedures deployed
# TDE enabled
# SQL Server Audit configured
```

**Weeks 7-8: Collector Deployment**
```powershell
# Collectors deployed
.\Install-DBAOpsCollector.ps1 -CollectorServer "MANU-COL01" -RepositoryServer "MANU-REPO01"

# Server inventory populated
.\Add-MonitoredServers.ps1 -RepositoryServer "MANU-REPO01" -DiscoveryMethod Auto
# Result: 147 of 150 servers added (3 decommissioned)
```

**Weeks 9-10: Configuration & Testing**
- Alert rules configured (30 rules)
- Notification channels tested
- Power BI dashboards developed
- Smoke tests: 100% pass rate

**Weeks 11-12: Training & Cutover**
- DBA team training: 2 days
- Management dashboard training: 4 hours
- Production cutover: Friday 6 PM
- Weekend monitoring: No issues
- Go-live: Monday 7 AM

**Results After 3 Months:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Visibility** ||||
| Servers monitored | 0 | 147 | 100% coverage |
| Real-time metrics | None | Every 5 min | Continuous |
| Historical data | None | 90 days | Full retention |
| **Operations** ||||
| Issue detection time | Days | Minutes | 99% faster |
| Manual health checks | 40 hrs/week | 2 hrs/week | 95% reduction |
| Backup compliance | Unknown | 97.3% | Measurable |
| Capacity planning | Reactive | Proactive | 30-day forecasts |
| **Incidents** ||||
| Unplanned outages | 12/quarter | 1/quarter | 92% reduction |
| Mean time to detect | 8.5 hours | 4 minutes | 99.2% faster |
| Mean time to resolve | 6.2 hours | 1.2 hours | 81% faster |

**Financial Impact:**

**Cost Avoidance:**
- Prevented outages: $2.4M/year (based on historical avg)
- Compliance automation: $180K/year (audit prep time)
- DBA productivity gain: $140K/year (95% less manual work)
**Total Benefits: $2.72M/year**

**Investment:**
- Hardware: $85K (servers, storage)
- Software: $25K (SQL Server licenses)
- Implementation: $75K (internal + consulting)
- Training: $15K
**Total Cost: $200K**

**ROI: 1,260%**
**Payback Period: 27 days**

**DBA Team Feedback:**

*"Before DBAOps, I spent Monday mornings checking on 75 servers manually. Now I glance at a dashboard for 30 seconds and know instantly if anything needs attention. We've prevented 3 major outages in the first month alone."*
— Senior DBA

*"The capacity planning dashboard is a game-changer. We added storage to 5 servers before they ran out of space. In the old days, we'd find out when the application crashed."*
— Infrastructure Manager

**Key Success Factors:**

1. **Executive Sponsorship**: CIO prioritized project
2. **Phased Approach**: Didn't try to do everything at once
3. **Automation**: Deployment scripts saved weeks of manual work
4. **Training**: Invested in proper knowledge transfer
5. **Pilot Testing**: Validated with 10 servers before full rollout
6. **Documentation**: Comprehensive runbooks created
7. **Support**: Dedicated Slack channel for questions

**Lessons Learned:**

1. **Discovery**: 3 servers thought to be active were decommissioned
2. **Firewall**: Firewall rules took longer than expected (add 2 weeks)
3. **Credentials**: Azure Key Vault setup was complex but worth it
4. **Thresholds**: Initial alert volume too high, tuned after 1 week
5. **Training**: More training time needed for Power BI
6. **Buy-in**: Demonstrating value early critical for adoption

---

## Chapter 10 Summary

This chapter covered complete DBAOps deployment:

**Key Takeaways:**

1. **Planning Essential**: Hardware sizing, prerequisites, security design
2. **Automated Deployment**: PowerShell scripts for repeatable installation
3. **Phased Approach**: Repository → Collectors → Configuration → Testing
4. **Configuration as Code**: JSON config files in version control
5. **Comprehensive Testing**: Smoke tests validate each component
6. **Production Cutover**: Detailed checklist and orchestrated deployment
7. **Documentation**: Installation guide, troubleshooting, runbooks

**Deployment Deliverables:**

✅ Automated repository installation script
✅ Collector deployment automation
✅ Server inventory population
✅ Configuration management framework
✅ Comprehensive smoke tests
✅ Troubleshooting guide
✅ Production cutover checklist
✅ Pre-flight validation

**Best Practices:**

✅ Test connectivity before adding servers
✅ Use service accounts with least privilege
✅ Enable TDE and backup certificates immediately
✅ Start with small pilot (10-20 servers)
✅ Validate each phase before proceeding
✅ Document all configuration changes
✅ Train team before go-live
✅ Monitor closely for first 24-48 hours
✅ Have rollback plan ready
✅ Celebrate success with team!

**Connection to Next Chapter:**

Chapter 11 covers High Availability and Disaster Recovery, showing how to configure Always On Availability Groups for the repository, implement failover for collectors, and ensure the DBAOps framework itself is resilient and recoverable.

---

## Review Questions

**Multiple Choice:**

1. What is the minimum RAM recommendation for the repository server?
   a) 8 GB
   b) 16 GB
   c) 32 GB
   d) 64 GB

2. What PowerShell version is required for the collectors?
   a) 5.1
   b) 6.0
   c) 7.0+
   d) Any version

3. How many security roles are configured by default?
   a) 3
   b) 4
   c) 5
   d) 6

**Short Answer:**

4. Explain the purpose of smoke tests and list five critical tests that should be performed.

5. Why is TDE certificate backup critical? What happens if the certificate is lost?

6. Describe the phased approach to production cutover and why each phase is important.

**Essay Questions:**

7. Design a deployment plan for an organization with 500 SQL Servers across 3 geographic regions. Include:
   - Infrastructure requirements
   - Deployment phases
   - Testing strategy
   - Rollback procedures
   - Training plan

8. Analyze the ManufactureCo case study. What were the critical success factors? What would you do differently?

**Hands-On Exercises:**

9. **Exercise 10.1: Complete Installation**
   - Deploy repository database
   - Enable TDE and backup certificate
   - Create security roles
   - Run smoke tests
   - Document configuration

10. **Exercise 10.2: Collector Setup**
    - Install PowerShell modules
    - Deploy collector scripts
    - Configure scheduled tasks
    - Test data collection
    - Verify metrics in repository

11. **Exercise 10.3: Populate Inventory**
    - Discover SQL Servers (AD or CSV)
    - Test connectivity to each
    - Insert to config.ServerInventory
    - Configure collection frequencies
    - Validate inventory data

12. **Exercise 10.4: Production Cutover**
    - Complete pre-cutover checklist
    - Execute cutover procedure
    - Monitor initial collection
    - Validate all components
    - Create post-deployment report

---

*End of Chapter 10*

**Next Chapter:** Chapter 11 - High Availability and Disaster Recovery

