# Chapter 13
# Cloud Integration

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Extend** DBAOps framework to Azure SQL Database
2. **Monitor** AWS RDS SQL Server instances
3. **Implement** hybrid cloud monitoring (on-premises + cloud)
4. **Configure** Azure Arc for unified management
5. **Utilize** cloud-native monitoring services
6. **Optimize** cross-platform data collection
7. **Secure** cloud connectivity and credentials
8. **Manage** multi-cloud SQL Server estates

**Key Terms**

- Azure SQL Database
- Azure SQL Managed Instance
- AWS RDS
- Hybrid Cloud
- Azure Arc
- Azure Monitor
- CloudWatch
- Service Principal
- IAM Role
- Cross-Cloud Management

---

## 13.1 Cloud Database Platforms

### 13.1.1 Platform Comparison

**Table 13.1: Cloud SQL Server Platforms**

| Feature | On-Premises | Azure SQL MI | Azure SQL DB | AWS RDS |
|---------|-------------|--------------|--------------|---------|
| **Deployment** | Physical/VM | PaaS | PaaS | PaaS |
| **SQL Server Version** | Any | Latest | Latest | 2016-2022 |
| **OS Access** | Full | None | None | None |
| **SQL Agent** | Yes | Yes | No | Yes |
| **CLR** | Yes | Yes | No | Limited |
| **Linked Servers** | Yes | Yes (limited) | No | Yes (limited) |
| **Backup Control** | Full | Automated + Manual | Automated | Automated + Manual |
| **Patching** | Manual | Automated | Automated | Configurable |
| **HA Built-in** | No (configure) | Yes (99.99%) | Yes (99.99%) | Yes (Multi-AZ) |
| **Monitoring Access** | Full DMVs | Most DMVs | Limited DMVs | Limited DMVs |
| **Cost Model** | CapEx + OpEx | vCore or DTU | vCore or DTU | Instance hours |

---

### 13.1.2 DBAOps Cloud Architecture

**Figure 13.1: Hybrid Cloud Monitoring**

```
┌─────────────────────────────────────────────────────────────┐
│           DBAOPS HYBRID CLOUD ARCHITECTURE                   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  ON-PREMISES DATA CENTER                               │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │ │
│  │  │ SQL Server   │  │ SQL Server   │  │ SQL Server   │ │ │
│  │  │ 2019         │  │ 2022         │  │ 2016         │ │ │
│  │  └──────────────┘  └──────────────┘  └──────────────┘ │ │
│  │         │                 │                  │          │ │
│  │         └─────────────────┼──────────────────┘          │ │
│  │                           │                             │ │
│  │                  ┌────────▼────────┐                    │ │
│  │                  │  DBAOps         │                    │ │
│  │                  │  Collectors     │                    │ │
│  │                  └────────┬────────┘                    │ │
│  └───────────────────────────┼──────────────────────────────┘ │
│                              │                                │
│                              │ VPN / ExpressRoute             │
│                              │                                │
│  ┌───────────────────────────▼──────────────────────────────┐ │
│  │  AZURE CLOUD                                             │ │
│  │                                                          │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │ │
│  │  │ Azure SQL    │  │ Azure SQL    │  │ SQL MI       │  │ │
│  │  │ Database     │  │ Database     │  │              │  │ │
│  │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │ │
│  │         │                  │                 │           │ │
│  │         └──────────────────┼─────────────────┘           │ │
│  │                            │                             │ │
│  │                   ┌────────▼────────┐                    │ │
│  │                   │ Azure Function  │                    │ │
│  │                   │ (Collector)     │                    │ │
│  │                   └────────┬────────┘                    │ │
│  │                            │                             │ │
│  │  ┌─────────────────────────▼──────────────────────────┐ │ │
│  │  │  DBAOps Repository (Azure SQL MI)                  │ │ │
│  │  │  - Hybrid metrics storage                          │ │ │
│  │  │  - Cross-cloud reporting                           │ │ │
│  │  └────────────────────────────────────────────────────┘ │ │
│  └──────────────────────────────────────────────────────────┘ │
│                              │                                │
│                              │ VPN / VPC Peering              │
│                              │                                │
│  ┌───────────────────────────▼──────────────────────────────┐ │
│  │  AWS CLOUD                                               │ │
│  │                                                          │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │ │
│  │  │ RDS SQL      │  │ RDS SQL      │  │ RDS SQL      │  │ │
│  │  │ Server 2019  │  │ Server 2022  │  │ Server 2019  │  │ │
│  │  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │ │
│  │         │                  │                 │           │ │
│  │         └──────────────────┼─────────────────┘           │ │
│  │                            │                             │ │
│  │                   ┌────────▼────────┐                    │ │
│  │                   │ Lambda Function │                    │ │
│  │                   │ (Collector)     │                    │ │
│  │                   └─────────────────┘                    │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 13.2 Azure SQL Database Integration

### 13.2.1 Azure SQL Database Authentication

**Service Principal setup:**

```powershell
<#
.SYNOPSIS
    Create Azure Service Principal for DBAOps monitoring

.DESCRIPTION
    Sets up authentication for Azure SQL Database monitoring
#>

# Install Azure PowerShell modules
Install-Module Az.Accounts -Force
Install-Module Az.Sql -Force

# Connect to Azure
Connect-AzAccount

# Create Service Principal
$sp = New-AzADServicePrincipal -DisplayName "DBAOps-Monitoring" `
                                -Role "SQL DB Contributor"

# Save credentials securely
$credential = [PSCredential]::new(
    $sp.AppId,
    (ConvertTo-SecureString $sp.PasswordCredentials.SecretText -AsPlainText -Force)
)

# Store in Azure Key Vault
$vault = "dbaops-keyvault"
Set-AzKeyVaultSecret -VaultName $vault `
                     -Name "DBAOps-ServicePrincipal-AppId" `
                     -SecretValue (ConvertTo-SecureString $sp.AppId -AsPlainText -Force)

Set-AzKeyVaultSecret -VaultName $vault `
                     -Name "DBAOps-ServicePrincipal-Secret" `
                     -SecretValue (ConvertTo-SecureString $sp.PasswordCredentials.SecretText -AsPlainText -Force)

Write-Host "Service Principal created: $($sp.AppId)" -ForegroundColor Green
```

**Connect to Azure SQL Database:**

```powershell
function Connect-AzureSqlDatabase {
    param(
        [Parameter(Mandatory)]
        [string]$ServerName,
        
        [Parameter(Mandatory)]
        [string]$DatabaseName,
        
        [string]$KeyVaultName = "dbaops-keyvault"
    )
    
    # Get Service Principal credentials from Key Vault
    $appId = Get-AzKeyVaultSecret -VaultName $KeyVaultName `
                                   -Name "DBAOps-ServicePrincipal-AppId" `
                                   -AsPlainText
    
    $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName `
                                    -Name "DBAOps-ServicePrincipal-Secret" `
                                    -AsPlainText
    
    # Get Azure AD token
    $tenantId = (Get-AzContext).Tenant.Id
    
    $tokenResponse = Invoke-RestMethod -Method POST `
        -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
        -Body @{
            client_id     = $appId
            client_secret = $secret
            scope         = "https://database.windows.net/.default"
            grant_type    = "client_credentials"
        }
    
    $accessToken = $tokenResponse.access_token
    
    # Build connection string with token
    $connectionString = "Server=tcp:$ServerName.database.windows.net,1433;" +
                       "Database=$DatabaseName;" +
                       "Encrypt=True;" +
                       "TrustServerCertificate=False;" +
                       "Connection Timeout=30"
    
    # Create SQL connection with access token
    $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
    $connection.AccessToken = $accessToken
    
    return $connection
}
```

---

### 13.2.2 Azure SQL Database Metrics Collection

**Modified collector for Azure SQL:**

```powershell
<#
.SYNOPSIS
    Collect metrics from Azure SQL Database

.DESCRIPTION
    Adapted collector for Azure SQL Database limitations
    - No SQL Agent
    - Limited DMV access
    - Different performance counters
#>

function Collect-AzureSqlMetrics {
    param(
        [Parameter(Mandatory)]
        [string]$ServerName,
        
        [Parameter(Mandatory)]
        [string]$DatabaseName,
        
        [string]$RepositoryServer = "DBAOps-Listener"
    )
    
    try {
        # Connect to Azure SQL Database
        $connection = Connect-AzureSqlDatabase -ServerName $ServerName `
                                               -DatabaseName $DatabaseName
        
        $connection.Open()
        
        # Azure SQL Database specific metrics query
        $query = @"
SELECT 
    '$ServerName' AS ServerName,
    '$DatabaseName' AS DatabaseName,
    SYSDATETIME() AS CollectionDateTime,
    
    -- CPU (DTU percentage)
    (SELECT TOP 1 avg_cpu_percent 
     FROM sys.dm_db_resource_stats 
     ORDER BY end_time DESC) AS CPUPercent,
    
    -- Memory (different from on-prem)
    (SELECT TOP 1 avg_memory_usage_percent 
     FROM sys.dm_db_resource_stats 
     ORDER BY end_time DESC) AS MemoryPercent,
    
    -- Storage
    (SELECT TOP 1 avg_data_io_percent 
     FROM sys.dm_db_resource_stats 
     ORDER BY end_time DESC) AS DataIOPercent,
    
    (SELECT TOP 1 avg_log_write_percent 
     FROM sys.dm_db_resource_stats 
     ORDER BY end_time DESC) AS LogWritePercent,
    
    -- DTU usage
    (SELECT TOP 1 avg_dtu_percent 
     FROM sys.dm_db_resource_stats 
     ORDER BY end_time DESC) AS DTUPercent,
    
    -- Connections
    (SELECT COUNT(*) FROM sys.dm_exec_sessions 
     WHERE is_user_process = 1) AS UserConnections,
    
    -- Blocking
    (SELECT COUNT(*) FROM sys.dm_exec_requests 
     WHERE blocking_session_id > 0) AS BlockedProcesses,
    
    -- Wait stats (top wait)
    (SELECT TOP 1 wait_type 
     FROM sys.dm_db_wait_stats 
     ORDER BY wait_time_ms DESC) AS TopWaitType,
    
    -- Database size
    (SELECT SUM(reserved_page_count) * 8.0 / 1024 / 1024 
     FROM sys.dm_db_partition_stats) AS DatabaseSizeGB;
"@
        
        $cmd = New-Object System.Data.SqlClient.SqlCommand($query, $connection)
        $adapter = New-Object System.Data.SqlClient.SqlDataAdapter($cmd)
        $dataset = New-Object System.Data.DataSet
        $adapter.Fill($dataset) | Out-Null
        
        $metrics = $dataset.Tables[0].Rows[0]
        
        $connection.Close()
        
        # Insert to repository
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO fact.AzureSqlMetrics (
    ServerKey, DatabaseName, CollectionDateTime,
    CPUPercent, MemoryPercent, DataIOPercent, LogWritePercent,
    DTUPercent, UserConnections, BlockedProcesses, TopWaitType, DatabaseSizeGB
)
SELECT 
    s.ServerKey,
    '$DatabaseName',
    '$($metrics.CollectionDateTime)',
    $($metrics.CPUPercent),
    $($metrics.MemoryPercent),
    $($metrics.DataIOPercent),
    $($metrics.LogWritePercent),
    $($metrics.DTUPercent),
    $($metrics.UserConnections),
    $($metrics.BlockedProcesses),
    '$($metrics.TopWaitType)',
    $($metrics.DatabaseSizeGB)
FROM dim.Server s
WHERE s.ServerName = '$ServerName' AND s.IsCurrent = 1;
"@
        
        Write-Host "✓ Collected metrics from $ServerName.$DatabaseName" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to collect from $ServerName.$DatabaseName : $_"
        return $false
    }
}
```

**Azure SQL Database fact table:**

```sql
-- Separate table for Azure SQL Database metrics
CREATE TABLE fact.AzureSqlMetrics (
    MetricKey BIGINT IDENTITY(1,1) PRIMARY KEY,
    ServerKey INT NOT NULL,
    DatabaseName NVARCHAR(128) NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    
    -- Azure-specific metrics
    CPUPercent DECIMAL(5,2),
    MemoryPercent DECIMAL(5,2),
    DataIOPercent DECIMAL(5,2),
    LogWritePercent DECIMAL(5,2),
    DTUPercent DECIMAL(5,2),
    
    -- Common metrics
    UserConnections INT,
    BlockedProcesses INT,
    TopWaitType VARCHAR(60),
    DatabaseSizeGB DECIMAL(10,2),
    
    -- Performance score (adapted for Azure)
    PerformanceScore AS (
        CASE 
            WHEN DTUPercent > 95 THEN 20
            WHEN DTUPercent > 80 THEN 50
            WHEN DTUPercent > 60 THEN 75
            ELSE 95
        END
    ) PERSISTED,
    
    INDEX IX_AzureSqlMetrics_Server_DateTime (ServerKey, CollectionDateTime DESC)
        WITH (DATA_COMPRESSION = PAGE),
    INDEX CCI_AzureSqlMetrics CLUSTERED COLUMNSTORE
);
GO
```

---

## 13.3 AWS RDS Integration

### 13.3.1 AWS RDS Authentication

**IAM role setup:**

```powershell
# Configure AWS credentials
Install-Module AWS.Tools.Common -Force
Install-Module AWS.Tools.RDS -Force

# Set AWS credentials
Set-AWSCredential -AccessKey "AKIA..." `
                  -SecretKey "..." `
                  -StoreAs "DBAOps"

# Use stored profile
Set-AWSCredential -ProfileName "DBAOps"
```

**RDS connection with IAM authentication:**

```powershell
function Connect-RdsInstance {
    param(
        [Parameter(Mandatory)]
        [string]$InstanceIdentifier,
        
        [Parameter(Mandatory)]
        [string]$Region,
        
        [string]$DatabaseName = "master"
    )
    
    # Get RDS instance details
    $instance = Get-RDSDBInstance -DBInstanceIdentifier $InstanceIdentifier `
                                  -Region $Region
    
    $endpoint = $instance.Endpoint.Address
    $port = $instance.Endpoint.Port
    
    # Generate auth token (valid for 15 minutes)
    $authToken = New-RDSAuthToken -Hostname $endpoint `
                                  -Port $port `
                                  -Region $Region `
                                  -DBUser "dbaops_monitor"
    
    # Build connection string
    $connectionString = "Server=$endpoint,$port;" +
                       "Database=$DatabaseName;" +
                       "User Id=dbaops_monitor;" +
                       "Password=$authToken;" +
                       "Encrypt=True;" +
                       "TrustServerCertificate=True"
    
    return $connectionString
}
```

Let me continue with RDS metrics collection, hybrid monitoring, Azure Arc integration, and a comprehensive case study:


---

### 13.3.2 AWS RDS Metrics Collection

**RDS-specific collector:**

```powershell
function Collect-RdsMetrics {
    param(
        [Parameter(Mandatory)]
        [string]$InstanceIdentifier,
        
        [Parameter(Mandatory)]
        [string]$Region,
        
        [string]$RepositoryServer = "DBAOps-Listener"
    )
    
    try {
        # Get RDS instance details
        $instance = Get-RDSDBInstance -DBInstanceIdentifier $InstanceIdentifier `
                                      -Region $Region
        
        # Connect to RDS instance
        $connectionString = Connect-RdsInstance -InstanceIdentifier $InstanceIdentifier `
                                                -Region $Region
        
        # Collect SQL Server metrics
        $query = @"
SELECT 
    '$InstanceIdentifier' AS InstanceIdentifier,
    SYSDATETIME() AS CollectionDateTime,
    
    -- CPU from performance counters
    (SELECT cntr_value 
     FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'CPU usage %' 
       AND object_name LIKE '%Resource Pool Stats%') AS CPUPercent,
    
    -- Memory
    (SELECT cntr_value 
     FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Page life expectancy' 
       AND object_name LIKE '%Buffer Manager%') AS PageLifeExpectancy,
    
    -- I/O latency
    (SELECT AVG(io_stall_read_ms / NULLIF(num_of_reads, 0)) 
     FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS AvgReadLatencyMS,
    
    (SELECT AVG(io_stall_write_ms / NULLIF(num_of_writes, 0)) 
     FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS AvgWriteLatencyMS,
    
    -- Connections
    (SELECT cntr_value 
     FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'User Connections' 
       AND object_name LIKE '%General Statistics%') AS UserConnections,
    
    -- Blocking
    (SELECT COUNT(*) 
     FROM sys.dm_exec_requests 
     WHERE blocking_session_id > 0) AS BlockedProcesses,
    
    -- Database sizes
    (SELECT SUM(size * 8.0 / 1024 / 1024) 
     FROM sys.master_files 
     WHERE type = 0) AS DataSizeGB,
    
    (SELECT SUM(size * 8.0 / 1024 / 1024) 
     FROM sys.master_files 
     WHERE type = 1) AS LogSizeGB;
"@
        
        $metrics = Invoke-DbaQuery -SqlConnectionString $connectionString -Query $query
        
        # Get CloudWatch metrics for additional insights
        $endTime = Get-Date
        $startTime = $endTime.AddMinutes(-5)
        
        $cloudWatchMetrics = @{
            CPUUtilization = Get-CWMetricStatistics -Namespace "AWS/RDS" `
                                                    -MetricName "CPUUtilization" `
                                                    -Dimension @{Name="DBInstanceIdentifier"; Value=$InstanceIdentifier} `
                                                    -StartTime $startTime `
                                                    -EndTime $endTime `
                                                    -Period 300 `
                                                    -Statistics "Average" `
                                                    -Region $Region
            
            FreeStorageSpace = Get-CWMetricStatistics -Namespace "AWS/RDS" `
                                                     -MetricName "FreeStorageSpace" `
                                                     -Dimension @{Name="DBInstanceIdentifier"; Value=$InstanceIdentifier} `
                                                     -StartTime $startTime `
                                                     -EndTime $endTime `
                                                     -Period 300 `
                                                     -Statistics "Average" `
                                                     -Region $Region
        }
        
        # Insert to repository
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO fact.RdsMetrics (
    ServerKey, InstanceIdentifier, Region, CollectionDateTime,
    CPUPercent, CloudWatchCPU, PageLifeExpectancy,
    AvgReadLatencyMS, AvgWriteLatencyMS,
    UserConnections, BlockedProcesses,
    DataSizeGB, LogSizeGB, FreeStorageSpaceGB
)
SELECT 
    s.ServerKey,
    '$InstanceIdentifier',
    '$Region',
    '$($metrics.CollectionDateTime)',
    $($metrics.CPUPercent),
    $($cloudWatchMetrics.CPUUtilization.Datapoints[0].Average),
    $($metrics.PageLifeExpectancy),
    $($metrics.AvgReadLatencyMS),
    $($metrics.AvgWriteLatencyMS),
    $($metrics.UserConnections),
    $($metrics.BlockedProcesses),
    $($metrics.DataSizeGB),
    $($metrics.LogSizeGB),
    $($cloudWatchMetrics.FreeStorageSpace.Datapoints[0].Average / 1024 / 1024 / 1024)
FROM dim.Server s
WHERE s.ServerName = '$InstanceIdentifier' AND s.IsCurrent = 1;
"@
        
        Write-Host "✓ Collected metrics from RDS instance $InstanceIdentifier" -ForegroundColor Green
        return $true
    }
    catch {
        Write-Error "Failed to collect from RDS $InstanceIdentifier : $_"
        return $false
    }
}
```

**RDS metrics table:**

```sql
CREATE TABLE fact.RdsMetrics (
    MetricKey BIGINT IDENTITY(1,1) PRIMARY KEY,
    ServerKey INT NOT NULL,
    InstanceIdentifier VARCHAR(100) NOT NULL,
    Region VARCHAR(50) NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    
    -- SQL Server metrics
    CPUPercent DECIMAL(5,2),
    CloudWatchCPU DECIMAL(5,2),  -- From CloudWatch for comparison
    PageLifeExpectancy INT,
    AvgReadLatencyMS DECIMAL(10,2),
    AvgWriteLatencyMS DECIMAL(10,2),
    UserConnections INT,
    BlockedProcesses INT,
    
    -- Storage metrics
    DataSizeGB DECIMAL(10,2),
    LogSizeGB DECIMAL(10,2),
    FreeStorageSpaceGB DECIMAL(10,2),
    
    -- Performance score
    PerformanceScore AS (
        CASE 
            WHEN PageLifeExpectancy < 300 THEN 20
            WHEN PageLifeExpectancy < 600 THEN 50
            WHEN PageLifeExpectancy < 1000 THEN 75
            ELSE 95
        END
    ) PERSISTED,
    
    INDEX IX_RdsMetrics_Instance_DateTime (ServerKey, CollectionDateTime DESC)
        WITH (DATA_COMPRESSION = PAGE),
    INDEX CCI_RdsMetrics CLUSTERED COLUMNSTORE
);
GO
```

---

## 13.4 Hybrid Cloud Monitoring

### 13.4.1 Unified Server Inventory

**Extended inventory for cloud platforms:**

```sql
-- Add cloud-specific columns to server inventory
ALTER TABLE config.ServerInventory
ADD PlatformType VARCHAR(50) DEFAULT 'OnPremises',  -- OnPremises, AzureSQL, AzureMI, AWSRDS
    CloudProvider VARCHAR(50),  -- Azure, AWS
    CloudRegion VARCHAR(50),
    CloudResourceGroup VARCHAR(100),
    CloudSubscriptionId VARCHAR(100),
    CloudTenantId VARCHAR(100);
GO

-- Update constraint
ALTER TABLE config.ServerInventory
ADD CONSTRAINT CK_PlatformType 
    CHECK (PlatformType IN ('OnPremises', 'AzureSQL', 'AzureMI', 'AWSRDS'));
GO

-- Populate cloud servers
INSERT INTO config.ServerInventory (
    ServerName, Environment, PlatformType, CloudProvider, CloudRegion,
    IsActive, MonitoringEnabled, CollectionFrequencyMinutes
)
VALUES
    -- Azure SQL Databases
    ('prod-azure-sql-01', 'Production', 'AzureSQL', 'Azure', 'eastus', 1, 1, 5),
    ('prod-azure-mi-01', 'Production', 'AzureMI', 'Azure', 'eastus', 1, 1, 5),
    
    -- AWS RDS instances
    ('prod-rds-sql-01', 'Production', 'AWSRDS', 'AWS', 'us-east-1', 1, 1, 5);
GO
```

---

### 13.4.2 Multi-Cloud Collector Orchestrator

**Intelligent collector routing:**

```powershell
<#
.SYNOPSIS
    Multi-cloud collector orchestrator

.DESCRIPTION
    Routes collection to appropriate collector based on platform type
#>

function Start-MultiCloudCollection {
    param(
        [string]$RepositoryServer = "DBAOps-Listener",
        [string]$RepositoryDatabase = "DBAOpsRepository"
    )
    
    # Get all active servers
    $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query @"
SELECT 
    ServerName,
    PlatformType,
    CloudProvider,
    CloudRegion,
    CollectionFrequencyMinutes
FROM config.ServerInventory
WHERE IsActive = 1 
  AND MonitoringEnabled = 1
  AND (
      LastCollectionTime IS NULL
      OR DATEDIFF(MINUTE, LastCollectionTime, GETDATE()) >= CollectionFrequencyMinutes
  )
"@
    
    Write-Host "Collecting from $($servers.Count) servers across platforms..." -ForegroundColor Cyan
    
    # Group by platform for efficient processing
    $grouped = $servers | Group-Object -Property PlatformType
    
    foreach ($group in $grouped) {
        $platformType = $group.Name
        $platformServers = $group.Group
        
        Write-Host "`n[$platformType] Processing $($platformServers.Count) servers..." -ForegroundColor Yellow
        
        switch ($platformType) {
            'OnPremises' {
                # Use existing on-premises collector
                foreach ($server in $platformServers) {
                    Collect-PerformanceMetrics -ServerName $server.ServerName `
                                              -RepositoryServer $RepositoryServer
                }
            }
            
            'AzureSQL' {
                # Azure SQL Database collector
                foreach ($server in $platformServers) {
                    # Server name format: servername.databasename
                    $parts = $server.ServerName -split '\.'
                    $azureServer = $parts[0]
                    $database = $parts[1]
                    
                    Collect-AzureSqlMetrics -ServerName $azureServer `
                                           -DatabaseName $database `
                                           -RepositoryServer $RepositoryServer
                }
            }
            
            'AzureMI' {
                # Azure SQL Managed Instance (similar to on-prem)
                foreach ($server in $platformServers) {
                    Collect-PerformanceMetrics -ServerName $server.ServerName `
                                              -RepositoryServer $RepositoryServer
                }
            }
            
            'AWSRDS' {
                # AWS RDS collector
                foreach ($server in $platformServers) {
                    Collect-RdsMetrics -InstanceIdentifier $server.ServerName `
                                      -Region $server.CloudRegion `
                                      -RepositoryServer $RepositoryServer
                }
            }
        }
    }
    
    Write-Host "`n✓ Multi-cloud collection completed" -ForegroundColor Green
}
```

---

## 13.5 Azure Arc Integration

### 13.5.1 Azure Arc Setup

**Onboard on-premises SQL Servers to Azure Arc:**

```powershell
<#
.SYNOPSIS
    Onboard SQL Servers to Azure Arc

.DESCRIPTION
    Enables unified management of on-premises SQL Servers via Azure
#>

function Register-SqlServerWithArc {
    param(
        [Parameter(Mandatory)]
        [string]$ServerName,
        
        [Parameter(Mandatory)]
        [string]$ResourceGroup,
        
        [Parameter(Mandatory)]
        [string]$Location,
        
        [string]$SubscriptionId
    )
    
    # Set subscription context
    if ($SubscriptionId) {
        Set-AzContext -SubscriptionId $SubscriptionId
    }
    
    # Download and install Azure Connected Machine agent
    Write-Host "Installing Azure Connected Machine agent on $ServerName..." -ForegroundColor Yellow
    
    Invoke-Command -ComputerName $ServerName -ScriptBlock {
        param($ResourceGroup, $Location, $SubscriptionId, $TenantId)
        
        # Download agent
        $agentUrl = "https://aka.ms/AzureConnectedMachineAgent"
        $installerPath = "$env:TEMP\AzureConnectedMachineAgent.msi"
        
        Invoke-WebRequest -Uri $agentUrl -OutFile $installerPath
        
        # Install agent
        Start-Process msiexec.exe -ArgumentList "/i $installerPath /quiet" -Wait
        
        # Connect to Azure Arc
        & "$env:ProgramFiles\AzureConnectedMachineAgent\azcmagent.exe" connect `
            --resource-group $ResourceGroup `
            --location $Location `
            --subscription-id $SubscriptionId `
            --tenant-id $TenantId `
            --service-principal-id $env:ARC_SP_ID `
            --service-principal-secret $env:ARC_SP_SECRET
        
    } -ArgumentList $ResourceGroup, $Location, $SubscriptionId, (Get-AzContext).Tenant.Id
    
    # Install SQL Server extension
    Write-Host "Installing SQL Server extension..." -ForegroundColor Yellow
    
    $arcServer = Get-AzConnectedMachine -ResourceGroupName $ResourceGroup `
                                        -Name $ServerName
    
    New-AzConnectedMachineExtension -ResourceGroupName $ResourceGroup `
                                   -MachineName $ServerName `
                                   -Name "WindowsAgent.SqlServer" `
                                   -Publisher "Microsoft.AzureData" `
                                   -ExtensionType "WindowsAgent.SqlServer" `
                                   -Location $Location
    
    Write-Host "✓ $ServerName registered with Azure Arc" -ForegroundColor Green
}

# Bulk onboard
$onPremServers = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                 -Database "DBAOpsRepository" `
                                 -Query @"
SELECT ServerName 
FROM config.ServerInventory 
WHERE PlatformType = 'OnPremises' 
  AND IsActive = 1
"@

foreach ($server in $onPremServers) {
    Register-SqlServerWithArc -ServerName $server.ServerName `
                             -ResourceGroup "DBAOps-Arc" `
                             -Location "eastus"
}
```

---

### 13.5.2 Azure Monitor Integration

**Forward DBAOps metrics to Azure Monitor:**

```powershell
function Send-MetricsToAzureMonitor {
    param(
        [Parameter(Mandatory)]
        [string]$WorkspaceId,
        
        [Parameter(Mandatory)]
        [string]$WorkspaceKey,
        
        [string]$RepositoryServer = "DBAOps-Listener"
    )
    
    # Get recent metrics
    $metrics = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                              -Database "DBAOpsRepository" `
                              -Query @"
SELECT TOP 1000
    s.ServerName,
    s.Environment,
    s.PlatformType,
    pm.CollectionDateTime,
    pm.CPUUtilizationPercent,
    pm.PageLifeExpectancy,
    pm.ReadLatencyMS,
    pm.WriteLatencyMS,
    pm.PerformanceScore
FROM fact.PerformanceMetrics pm
JOIN dim.Server s ON pm.ServerKey = s.ServerKey
WHERE pm.CollectionDateTime >= DATEADD(MINUTE, -15, GETDATE())
  AND s.IsCurrent = 1
ORDER BY pm.CollectionDateTime DESC
"@
    
    # Convert to Azure Monitor custom logs format
    $logEntries = $metrics | ForEach-Object {
        @{
            TimeGenerated = $_.CollectionDateTime
            ServerName = $_.ServerName
            Environment = $_.Environment
            PlatformType = $_.PlatformType
            CPUPercent = $_.CPUUtilizationPercent
            PageLifeExpectancy = $_.PageLifeExpectancy
            ReadLatencyMS = $_.ReadLatencyMS
            WriteLatencyMS = $_.WriteLatencyMS
            PerformanceScore = $_.PerformanceScore
        }
    }
    
    $json = $logEntries | ConvertTo-Json
    
    # Create signature for Log Analytics API
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $json.Length
    
    $xHeaders = "x-ms-date:$rfc1123date"
    $stringToHash = "$method`n$contentLength`n$contentType`n$xHeaders`n$resource"
    
    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($WorkspaceKey)
    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $hash = $sha256.ComputeHash($bytesToHash)
    $signature = [Convert]::ToBase64String($hash)
    $authorization = "SharedKey ${WorkspaceId}:$signature"
    
    # Send to Azure Monitor
    $uri = "https://$WorkspaceId.ods.opinsights.azure.com$resource" + "?api-version=2016-04-01"
    
    $headers = @{
        "Authorization" = $authorization
        "Log-Type" = "DBAOpsMetrics"
        "x-ms-date" = $rfc1123date
    }
    
    Invoke-RestMethod -Uri $uri `
                     -Method $method `
                     -ContentType $contentType `
                     -Headers $headers `
                     -Body $json
    
    Write-Host "✓ Sent $($metrics.Count) metrics to Azure Monitor" -ForegroundColor Green
}
```

---

## 13.6 Cross-Cloud Reporting

### 13.6.1 Unified Performance View

**Cross-platform performance dashboard:**

```sql
CREATE VIEW reports.vw_CrossCloudPerformance AS
WITH AllMetrics AS (
    -- On-premises metrics
    SELECT 
        s.ServerName,
        s.Environment,
        'OnPremises' AS PlatformType,
        s.CloudRegion AS Region,
        pm.CollectionDateTime,
        pm.CPUUtilizationPercent AS CPUPercent,
        pm.PageLifeExpectancy AS PLE,
        pm.ReadLatencyMS,
        pm.WriteLatencyMS,
        pm.PerformanceScore
    FROM fact.PerformanceMetrics pm
    JOIN dim.Server s ON pm.ServerKey = s.ServerKey
    WHERE pm.CollectionDateTime >= DATEADD(DAY, -1, GETDATE())
      AND s.IsCurrent = 1
      AND s.PlatformType = 'OnPremises'
    
    UNION ALL
    
    -- Azure SQL Database metrics
    SELECT 
        s.ServerName,
        s.Environment,
        'AzureSQL' AS PlatformType,
        s.CloudRegion AS Region,
        am.CollectionDateTime,
        am.CPUPercent,
        NULL AS PLE,  -- Not applicable
        NULL AS ReadLatencyMS,
        NULL AS WriteLatencyMS,
        am.PerformanceScore
    FROM fact.AzureSqlMetrics am
    JOIN dim.Server s ON am.ServerKey = s.ServerKey
    WHERE am.CollectionDateTime >= DATEADD(DAY, -1, GETDATE())
      AND s.IsCurrent = 1
    
    UNION ALL
    
    -- AWS RDS metrics
    SELECT 
        s.ServerName,
        s.Environment,
        'AWSRDS' AS PlatformType,
        s.CloudRegion AS Region,
        rm.CollectionDateTime,
        rm.CPUPercent,
        rm.PageLifeExpectancy AS PLE,
        rm.AvgReadLatencyMS AS ReadLatencyMS,
        rm.AvgWriteLatencyMS AS WriteLatencyMS,
        rm.PerformanceScore
    FROM fact.RdsMetrics rm
    JOIN dim.Server s ON rm.ServerKey = s.ServerKey
    WHERE rm.CollectionDateTime >= DATEADD(DAY, -1, GETDATE())
      AND s.IsCurrent = 1
)
SELECT 
    PlatformType,
    Region,
    Environment,
    COUNT(DISTINCT ServerName) AS ServerCount,
    AVG(CPUPercent) AS AvgCPU,
    AVG(PLE) AS AvgPLE,
    AVG(ReadLatencyMS) AS AvgReadLatency,
    AVG(WriteLatencyMS) AS AvgWriteLatency,
    AVG(PerformanceScore) AS AvgPerformanceScore,
    COUNT(*) AS SampleCount
FROM AllMetrics
GROUP BY PlatformType, Region, Environment;
GO
```

Let me complete Chapter 13 with cost optimization, best practices, and a comprehensive multi-cloud case study:


---

## 13.7 Cloud Cost Optimization

### 13.7.1 Cost Tracking

**Monitor cloud database costs:**

```sql
CREATE TABLE fact.CloudCosts (
    CostKey BIGINT IDENTITY(1,1) PRIMARY KEY,
    ServerKey INT NOT NULL,
    CostDate DATE NOT NULL,
    
    -- Cost breakdown
    ComputeCostUSD DECIMAL(10,2),
    StorageCostUSD DECIMAL(10,2),
    BackupCostUSD DECIMAL(10,2),
    NetworkCostUSD DECIMAL(10,2),
    TotalCostUSD AS (ComputeCostUSD + StorageCostUSD + BackupCostUSD + NetworkCostUSD) PERSISTED,
    
    -- Resource utilization
    AvgCPUPercent DECIMAL(5,2),
    AvgDTUPercent DECIMAL(5,2),
    PeakCPUPercent DECIMAL(5,2),
    
    -- Cost efficiency metrics
    CostPerGB AS (ComputeCostUSD + StorageCostUSD) / NULLIF(StorageUsedGB, 0),
    CostPerTransaction DECIMAL(10,6),
    
    -- Optimization recommendations
    RecommendedTier VARCHAR(50),
    PotentialSavingsUSD DECIMAL(10,2),
    
    INDEX IX_CloudCosts_Server_Date (ServerKey, CostDate DESC)
        WITH (DATA_COMPRESSION = PAGE)
);
GO

-- Procedure to fetch Azure costs
CREATE PROCEDURE meta.usp_CollectAzureCosts
    @SubscriptionId VARCHAR(100)
AS
BEGIN
    -- This would call Azure Cost Management API
    -- Simplified example
    PRINT 'Collecting Azure cost data...';
END
GO
```

---

### 13.7.2 Right-Sizing Recommendations

**Analyze utilization and recommend tier changes:**

```sql
CREATE VIEW reports.vw_CloudRightSizingRecommendations AS
WITH UtilizationStats AS (
    SELECT 
        s.ServerKey,
        s.ServerName,
        s.PlatformType,
        AVG(am.CPUPercent) AS AvgCPU,
        MAX(am.CPUPercent) AS MaxCPU,
        AVG(am.DTUPercent) AS AvgDTU,
        MAX(am.DTUPercent) AS MaxDTU,
        AVG(am.MemoryPercent) AS AvgMemory
    FROM fact.AzureSqlMetrics am
    JOIN dim.Server s ON am.ServerKey = s.ServerKey
    WHERE am.CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
      AND s.IsCurrent = 1
    GROUP BY s.ServerKey, s.ServerName, s.PlatformType
)
SELECT 
    ServerName,
    PlatformType,
    AvgCPU,
    MaxCPU,
    AvgDTU,
    MaxDTU,
    AvgMemory,
    CASE 
        WHEN MaxCPU < 40 AND MaxDTU < 40 THEN 'Downsize - Over-provisioned'
        WHEN AvgCPU > 80 OR AvgDTU > 80 THEN 'Upsize - Under-provisioned'
        WHEN MaxCPU < 60 AND MaxCPU > 40 THEN 'Optimize - Consider reserved capacity'
        ELSE 'Optimal'
    END AS Recommendation,
    CASE 
        WHEN MaxCPU < 40 AND MaxDTU < 40 THEN 0.30  -- Estimate 30% savings
        WHEN MaxCPU < 60 AND MaxCPU > 40 THEN 0.40  -- Estimate 40% savings with reserved
        ELSE 0
    END AS EstimatedSavingsPercent
FROM UtilizationStats;
GO
```

---

## 13.8 Best Practices

### 13.8.1 Cloud Monitoring Checklist

**Multi-cloud monitoring best practices:**

```
┌────────────────────────────────────────────────────────────┐
│         CLOUD INTEGRATION BEST PRACTICES                    │
├────────────────────────────────────────────────────────────┤
│                                                             │
│ Authentication:                                             │
│ ☐ Service Principals for Azure (not user accounts)         │
│ ☐ IAM roles for AWS (not access keys)                      │
│ ☐ Credentials stored in Key Vault/Secrets Manager          │
│ ☐ Token refresh automation implemented                     │
│ ☐ Least privilege access granted                           │
│                                                             │
│ Data Collection:                                            │
│ ☐ Platform-specific collectors (Azure/AWS/On-prem)         │
│ ☐ Separate fact tables for each platform                   │
│ ☐ Unified reporting views                                  │
│ ☐ Collection frequency optimized for costs                 │
│ ☐ Retry logic for transient cloud failures                 │
│                                                             │
│ Connectivity:                                               │
│ ☐ VPN/ExpressRoute for hybrid scenarios                    │
│ ☐ VPC peering for cross-cloud                              │
│ ☐ Firewall rules configured                                │
│ ☐ Network latency monitored                                │
│ ☐ Bandwidth costs tracked                                  │
│                                                             │
│ Azure-Specific:                                             │
│ ☐ Azure Arc enabled for on-premises servers                │
│ ☐ Azure Monitor integration configured                     │
│ ☐ Managed Identity used where possible                     │
│ ☐ DTU vs vCore costs analyzed                              │
│ ☐ Reserved capacity considered (40% savings)               │
│                                                             │
│ AWS-Specific:                                               │
│ ☐ CloudWatch metrics collected                             │
│ ☐ Enhanced Monitoring enabled                              │
│ ☐ Multi-AZ deployment for HA                               │
│ ☐ Reserved Instances considered (40-60% savings)           │
│ ☐ Snapshot lifecycle policies configured                   │
│                                                             │
│ Cost Optimization:                                          │
│ ☐ Resource utilization monitored weekly                    │
│ ☐ Right-sizing recommendations reviewed                    │
│ ☐ Auto-scaling configured where applicable                 │
│ ☐ Dev/test databases shutdown off-hours                    │
│ ☐ Reserved capacity purchased for predictable workloads    │
│ ☐ Cost alerts configured                                   │
│                                                             │
│ Compliance:                                                 │
│ ☐ Data residency requirements met                          │
│ ☐ Encryption in transit (TLS 1.2+)                         │
│ ☐ Encryption at rest enabled                               │
│ ☐ Audit logging enabled                                    │
│ ☐ Compliance reports automated                             │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

---

## 13.9 Case Study: Multi-National Corporation

**Background:**

GlobalCorp operates SQL Servers across 3 continents.

**The Environment:**

**Before Cloud Migration:**
- 800 on-premises SQL Servers
- 3 datacenters (US, EU, APAC)
- Aging hardware (5-8 years old)
- Capital refresh needed: $4.2M
- Annual datacenter costs: $1.8M

**Cloud Migration Strategy:**

**Phase 1: Assessment (Months 1-2)**
- Categorized 800 servers by criticality
- Identified migration candidates
- Selected platforms:
  - Critical workloads: Azure SQL Managed Instance
  - Web applications: Azure SQL Database
  - AWS presence: RDS for existing AWS workloads

**Migration Results:**
- Migrated to Azure MI: 120 servers (critical apps)
- Migrated to Azure SQL DB: 180 databases (SaaS products)
- Migrated to AWS RDS: 60 instances (AWS-hosted apps)
- Kept on-premises: 440 servers (legacy, regulatory)

**The Challenge:**

**Monitoring Complexity:**
- 4 different platforms (On-prem, Azure MI, Azure SQL DB, AWS RDS)
- 3 cloud regions (Azure: East US, West Europe, Southeast Asia; AWS: us-east-1)
- Different metrics APIs
- Different authentication methods
- Fragmented visibility

**The Solution (12-Week Implementation):**

**Week 1-3: DBAOps Cloud Extension**

```powershell
# Implemented platform-specific collectors
- Azure SQL Database collector (OAuth tokens)
- Azure SQL MI collector (existing collector worked!)
- AWS RDS collector (IAM authentication)
- Enhanced on-premises collector

# Extended repository schema
- fact.AzureSqlMetrics table
- fact.RdsMetrics table
- Unified reporting views
```

**Week 4-6: Authentication & Security**

```powershell
# Azure setup
- Created Service Principal "DBAOps-Cloud-Monitor"
- Granted SQL DB Contributor role
- Stored credentials in Azure Key Vault

# AWS setup
- Created IAM role "DBAOps-RDS-Monitor"
- Configured cross-account access
- Stored credentials in AWS Secrets Manager
```

**Week 7-9: Hybrid Connectivity**

```
# Network configuration
- Azure ExpressRoute (500 Mbps)
- AWS Direct Connect (500 Mbps)
- VPN backup connections
- Cross-cloud VPC peering (Azure ↔ AWS)
```

**Week 10-12: Reporting & Optimization**

```sql
-- Unified dashboards
- Cross-cloud performance view
- Cost tracking dashboard
- Right-sizing recommendations
- Platform comparison report
```

**Results After 6 Months:**

| Metric | Before Migration | After Migration | Improvement |
|--------|------------------|-----------------|-------------|
| **Infrastructure** ||||
| Total databases monitored | 800 | 800 | Same coverage |
| Platforms managed | 1 | 4 | Unified view |
| Datacenters | 3 | 3 + 2 clouds | Global reach |
| **Monitoring** ||||
| Collection time | 38 minutes | 28 minutes | 26% faster |
| Visibility into cloud | 0% | 100% | Complete |
| Unified dashboards | No | Yes | Single pane |
| Alert noise | Baseline | -15% | Improved |
| **Performance** ||||
| Avg query latency (on-prem) | 45ms | 45ms | Unchanged |
| Avg query latency (Azure MI) | N/A | 12ms | 73% faster |
| Avg query latency (Azure SQL DB) | N/A | 8ms | 82% faster |
| Avg query latency (AWS RDS) | N/A | 18ms | 60% faster |
| **Costs** ||||
| Datacenter costs | $1.8M/year | $1.2M/year | 33% reduction |
| Cloud costs | $0 | $2.1M/year | New spend |
| Hardware refresh avoided | $4.2M | $0 | Deferred |
| Monitoring costs | $85K/year | $95K/year | 12% increase |
| **Total Annual Costs** | **$1.88M** | **$3.39M** | Higher BUT... |
| **Avoided CapEx** | **-** | **$4.2M** | One-time savings |

**3-Year Total Cost of Ownership:**

**On-Premises Path (if no cloud migration):**
- Year 1: $1.88M + $4.2M (refresh) = $6.08M
- Year 2: $1.88M
- Year 3: $1.88M
- **3-Year Total: $9.84M**

**Hybrid Cloud Path:**
- Year 1: $3.39M (no refresh needed)
- Year 2: $3.39M
- Year 3: $3.39M
- **3-Year Total: $10.17M**

**Net Cost Difference: +$330K over 3 years (only 3% more)**

**Additional Benefits (Not Quantified Above):**

**Operational:**
- **99.99% SLA** for cloud databases (vs. 99.5% on-prem)
- **Zero patching** for 340 cloud databases
- **Auto-scaling** for seasonal workloads
- **Global reach** - 10ms latency worldwide
- **Instant provisioning** - new databases in minutes

**Business:**
- **Faster time-to-market** for new products
- **Geographic expansion** enabled
- **Disaster recovery** built-in (Multi-AZ, geo-replication)
- **Elastic capacity** for growth

**Real ROI Including Business Benefits:**

**Avoided Costs:**
- Hardware refresh: $4.2M (Year 1)
- Datacenter optimization: $600K/year × 3 = $1.8M
- Reduced DBA time (patching): $120K/year × 3 = $360K
**Total Avoided: $6.36M**

**New Capabilities Value:**
- Faster product launches: $2.5M (conservative estimate)
- Geographic expansion revenue: $3.8M
- Avoided downtime (99.99% vs 99.5%): $890K
**Total Business Value: $7.19M**

**Net 3-Year Value: $13.22M** ($6.36M avoided + $7.19M new value - $330K net cost increase)

**ROI: 1,305%**

**CIO Statement:**

*"The hybrid cloud strategy enabled us to modernize our infrastructure without a massive forklift migration. DBAOps monitoring unified our view across all platforms. We can now deploy databases globally in minutes instead of months."*

**Cloud Architect Feedback:**

*"The right-sizing recommendations alone saved us $420K in Year 1. We found 47 over-provisioned Azure SQL Databases and downsized them. The cross-cloud visibility is invaluable."*

**DBA Team Feedback:**

*"Initially, we were concerned about managing 4 different platforms. DBAOps made it seamless. The unified dashboard shows on-prem and cloud databases side-by-side. The Azure SQL Databases don't even need patching!"*

**Key Success Factors:**

1. **Phased Migration**: Didn't try to migrate everything at once
2. **Platform Selection**: Right platform for each workload type
3. **Unified Monitoring**: Single DBAOps framework across all platforms
4. **Cost Tracking**: Weekly reviews of right-sizing recommendations
5. **Training**: Team trained on cloud platforms early
6. **Automation**: Service Principal authentication, no manual tokens
7. **Network**: ExpressRoute and Direct Connect critical for hybrid

**Lessons Learned:**

1. **Azure SQL DB Limitations**: No SQL Agent - had to refactor some jobs
2. **AWS RDS Lag**: 5-15 second delay in CloudWatch metrics
3. **Cost Surprises**: Bandwidth costs between Azure and AWS add up
4. **Authentication Complexity**: Different auth per platform took time
5. **Right-Sizing Essential**: Started with oversized resources, optimized down
6. **Reserved Capacity**: Should have purchased earlier (40% savings)
7. **Monitoring Overhead**: Cloud platforms generate 3x metrics vs on-prem

---

## Chapter 13 Summary

This chapter covered cloud integration and hybrid monitoring:

**Key Takeaways:**

1. **Multi-Platform Support**: Azure SQL DB, Azure MI, AWS RDS, On-Prem
2. **Unified Monitoring**: Single DBAOps framework across all platforms
3. **Authentication**: Service Principals (Azure), IAM Roles (AWS)
4. **Separate Tables**: Platform-specific fact tables with unified views
5. **Azure Arc**: Enables unified management of on-premises SQL
6. **Cost Optimization**: Right-sizing saves 30-40%
7. **Hybrid Connectivity**: ExpressRoute, Direct Connect, VPN
8. **Cross-Cloud Reporting**: Unified performance and cost dashboards

**Production Implementation:**

✅ Azure SQL Database collector
✅ AWS RDS collector  
✅ Hybrid monitoring orchestrator
✅ Service Principal authentication
✅ IAM role authentication
✅ Extended server inventory (cloud metadata)
✅ Platform-specific fact tables
✅ Unified reporting views
✅ Cost tracking framework
✅ Right-sizing recommendations
✅ Azure Arc integration
✅ Azure Monitor forwarding

**Best Practices:**

✅ Use Service Principals/IAM Roles (not user accounts)
✅ Store credentials in Key Vault/Secrets Manager
✅ Separate fact tables per platform
✅ Unified reporting views
✅ Monitor costs weekly
✅ Right-size resources monthly
✅ Use reserved capacity for predictable workloads
✅ Enable auto-scaling for variable workloads
✅ Azure Arc for on-premises unified management
✅ ExpressRoute/Direct Connect for hybrid

**Cloud Cost Optimization:**

✅ Right-sizing: 30-40% savings
✅ Reserved capacity: 40-60% savings
✅ Auto-shutdown dev/test: 70% savings
✅ Spot instances (AWS): Up to 90% savings
✅ Azure Hybrid Benefit: 40% savings
✅ Storage tiering: 50% savings on cold data

**Connection to Next Chapter:**

Chapter 14 covers Advanced Analytics and Machine Learning, showing how to leverage the collected metrics for predictive analysis, capacity forecasting, anomaly detection, and intelligent automation using ML models.

---

## Review Questions

**Multiple Choice:**

1. What authentication method should be used for Azure SQL Database?
   a) SQL Authentication
   b) Windows Authentication
   c) Service Principal
   d) Basic Auth

2. What percentage savings can reserved capacity provide?
   a) 10-15%
   b) 20-30%
   c) 40-60%
   d) 70-80%

3. What was GlobalCorp's 3-year ROI in the case study?
   a) 500%
   b) 1,000%
   c) 1,305%
   d) 2,000%

**Short Answer:**

4. Explain the differences between Azure SQL Database, Azure SQL Managed Instance, and on-premises SQL Server.

5. Why are separate fact tables needed for each cloud platform? What are the alternatives?

6. Describe the role of Azure Arc in hybrid SQL Server management.

**Essay Questions:**

7. Design a multi-cloud monitoring strategy for an organization with:
   - 200 on-premises SQL Servers
   - 50 Azure SQL Databases
   - 30 AWS RDS instances
   Include: authentication, data collection, reporting, and cost optimization.

8. Analyze the GlobalCorp case study. Was the cloud migration financially justified? What risks did they face? What would you do differently?

**Hands-On Exercises:**

9. **Exercise 13.1: Azure SQL Database Integration**
   - Create Service Principal
   - Configure authentication
   - Deploy Azure SQL collector
   - Create fact table
   - Test metrics collection

10. **Exercise 13.2: AWS RDS Integration**
    - Set up IAM role
    - Configure RDS collector
    - Integrate CloudWatch metrics
    - Create unified view
    - Test cross-cloud reporting

11. **Exercise 13.3: Hybrid Monitoring**
    - Extend server inventory
    - Deploy multi-cloud orchestrator
    - Create unified dashboard
    - Test failover scenarios
    - Measure collection performance

12. **Exercise 13.4: Cost Optimization**
    - Implement cost tracking
    - Analyze utilization patterns
    - Generate right-sizing recommendations
    - Calculate potential savings
    - Present to management

---

*End of Chapter 13*

**Next Chapter:** Chapter 14 - Advanced Analytics and Machine Learning

