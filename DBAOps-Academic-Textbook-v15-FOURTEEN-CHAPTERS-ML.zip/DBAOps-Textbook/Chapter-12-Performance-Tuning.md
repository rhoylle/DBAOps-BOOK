# Chapter 12
# Performance Tuning

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Analyze** framework performance bottlenecks
2. **Optimize** repository database queries and indexes
3. **Tune** data collection for maximum efficiency
4. **Implement** parallel processing optimizations
5. **Configure** optimal resource allocation
6. **Monitor** framework resource consumption
7. **Scale** the framework to 1000+ servers
8. **Measure** and improve collection throughput

**Key Terms**

- Query Optimization
- Index Tuning
- Execution Plan
- Columnstore Index
- Parallel Processing
- Resource Governor
- Query Store
- Statistics
- Partitioning
- Throttling

---

## 12.1 Performance Baseline

### 12.1.1 Establishing Baselines

**Measure before optimizing:**

```sql
-- Track framework performance metrics
CREATE TABLE meta.FrameworkPerformance (
    MetricID BIGINT IDENTITY(1,1) PRIMARY KEY,
    MetricDate DATETIME2 DEFAULT SYSDATETIME(),
    
    -- Repository metrics
    RepositoryDatabaseSizeGB DECIMAL(10,2),
    DataFileSizeGB DECIMAL(10,2),
    LogFileSizeGB DECIMAL(10,2),
    
    -- Collection metrics
    TotalServersMonitored INT,
    CollectionsPerHour INT,
    AvgCollectionDurationSec DECIMAL(10,2),
    FailedCollections INT,
    
    -- Query performance
    AvgQueryDurationMS DECIMAL(10,2),
    LongestQueryDurationMS INT,
    QueriesPerSecond DECIMAL(10,2),
    
    -- Resource consumption
    CPUPercent DECIMAL(5,2),
    MemoryUsedMB INT,
    DiskIOPS INT,
    NetworkMbps DECIMAL(10,2),
    
    -- Collector metrics
    ActiveCollectors INT,
    CollectorCPUPercent DECIMAL(5,2),
    CollectorMemoryMB INT,
    
    INDEX IX_FrameworkPerformance_Date (MetricDate DESC)
);
GO

-- Procedure to capture baseline
CREATE PROCEDURE meta.usp_CaptureFrameworkPerformance
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO meta.FrameworkPerformance (
        RepositoryDatabaseSizeGB,
        DataFileSizeGB,
        LogFileSizeGB,
        TotalServersMonitored,
        CollectionsPerHour,
        AvgCollectionDurationSec,
        FailedCollections,
        AvgQueryDurationMS,
        LongestQueryDurationMS,
        QueriesPerSecond,
        CPUPercent,
        MemoryUsedMB,
        DiskIOPS,
        ActiveCollectors
    )
    SELECT 
        -- Database sizes
        SUM(size * 8.0 / 1024 / 1024) AS RepositoryDatabaseSizeGB,
        SUM(CASE WHEN type = 0 THEN size * 8.0 / 1024 / 1024 ELSE 0 END) AS DataFileSizeGB,
        SUM(CASE WHEN type = 1 THEN size * 8.0 / 1024 / 1024 ELSE 0 END) AS LogFileSizeGB,
        
        -- Server count
        (SELECT COUNT(*) FROM config.ServerInventory WHERE IsActive = 1) AS TotalServersMonitored,
        
        -- Collections per hour
        (SELECT COUNT(*) FROM log.CollectionActivity 
         WHERE ActivityDate >= DATEADD(HOUR, -1, GETDATE())) AS CollectionsPerHour,
        
        -- Avg collection duration
        (SELECT AVG(DurationMinutes) FROM log.CollectionActivity 
         WHERE ActivityDate >= DATEADD(HOUR, -1, GETDATE())) * 60 AS AvgCollectionDurationSec,
        
        -- Failed collections
        (SELECT SUM(FailureCount) FROM log.CollectionActivity 
         WHERE ActivityDate >= DATEADD(HOUR, -1, GETDATE())) AS FailedCollections,
        
        -- Query performance (from Query Store)
        (SELECT AVG(avg_duration) / 1000.0 FROM sys.query_store_runtime_stats 
         WHERE last_execution_time >= DATEADD(HOUR, -1, GETDATE())) AS AvgQueryDurationMS,
        
        (SELECT MAX(max_duration) / 1000.0 FROM sys.query_store_runtime_stats 
         WHERE last_execution_time >= DATEADD(HOUR, -1, GETDATE())) AS LongestQueryDurationMS,
        
        -- Queries per second
        (SELECT SUM(count_executions) / 3600.0 FROM sys.query_store_runtime_stats 
         WHERE last_execution_time >= DATEADD(HOUR, -1, GETDATE())) AS QueriesPerSecond,
        
        -- CPU
        (SELECT TOP 1 SQLProcessUtilization 
         FROM (SELECT record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization
               FROM (SELECT CAST(record AS XML) AS record 
                     FROM sys.dm_os_ring_buffers 
                     WHERE ring_buffer_type = 'RING_BUFFER_SCHEDULER_MONITOR') AS rb) AS cpu
         ORDER BY SQLProcessUtilization DESC) AS CPUPercent,
        
        -- Memory
        (SELECT physical_memory_in_use_kb / 1024 
         FROM sys.dm_os_process_memory) AS MemoryUsedMB,
        
        -- Disk IOPS (approximate from DMV)
        (SELECT SUM(num_of_reads + num_of_writes) / 60
         FROM sys.dm_io_virtual_file_stats(DB_ID('DBAOpsRepository'), NULL)) AS DiskIOPS,
        
        -- Active collectors
        (SELECT COUNT(DISTINCT CollectorName) 
         FROM ctl.CollectorHeartbeat 
         WHERE HeartbeatTime >= DATEADD(MINUTE, -10, GETDATE())) AS ActiveCollectors
    FROM sys.database_files
    WHERE database_id = DB_ID('DBAOpsRepository');
END
GO

-- Schedule baseline capture every 15 minutes
-- (via SQL Agent job)
```

**Baseline Report:**

```sql
CREATE VIEW reports.vw_FrameworkPerformanceTrend AS
SELECT 
    CAST(MetricDate AS DATE) AS MetricDate,
    AVG(RepositoryDatabaseSizeGB) AS AvgDatabaseSizeGB,
    AVG(CollectionsPerHour) AS AvgCollectionsPerHour,
    AVG(AvgCollectionDurationSec) AS AvgCollectionDurationSec,
    AVG(AvgQueryDurationMS) AS AvgQueryDurationMS,
    AVG(CPUPercent) AS AvgCPUPercent,
    AVG(MemoryUsedMB) AS AvgMemoryUsedMB,
    MAX(LongestQueryDurationMS) AS MaxQueryDurationMS,
    SUM(FailedCollections) AS TotalFailedCollections
FROM meta.FrameworkPerformance
WHERE MetricDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY CAST(MetricDate AS DATE);
GO
```

---

## 12.2 Repository Database Optimization

### 12.2.1 Index Strategy

**Columnstore indexes for fact tables:**

```sql
-- Performance metrics table uses clustered columnstore
-- Already defined in Chapter 5, but let's verify and optimize

-- Check current index
SELECT 
    i.name AS IndexName,
    i.type_desc AS IndexType,
    ps.row_count AS RowCount,
    ps.reserved_page_count * 8 / 1024.0 AS SizeMB
FROM sys.indexes i
JOIN sys.dm_db_partition_stats ps ON i.object_id = ps.object_id AND i.index_id = ps.index_id
WHERE i.object_id = OBJECT_ID('fact.PerformanceMetrics');

-- Add nonclustered indexes for common queries
CREATE NONCLUSTERED INDEX IX_PerformanceMetrics_Server_DateTime
ON fact.PerformanceMetrics (ServerKey, CollectionDateTime DESC)
INCLUDE (CPUUtilizationPercent, PageLifeExpectancy, ReadLatencyMS)
WITH (DATA_COMPRESSION = PAGE, ONLINE = ON);

-- Index for time-based queries
CREATE NONCLUSTERED INDEX IX_PerformanceMetrics_DateTime_Server
ON fact.PerformanceMetrics (CollectionDateTime DESC, ServerKey)
INCLUDE (PerformanceScore)
WITH (DATA_COMPRESSION = PAGE, ONLINE = ON);

-- Composite index for filtering
CREATE NONCLUSTERED INDEX IX_PerformanceMetrics_Score_DateTime
ON fact.PerformanceMetrics (PerformanceScore, CollectionDateTime DESC)
WHERE PerformanceScore < 75  -- Only index problematic scores
WITH (DATA_COMPRESSION = PAGE, ONLINE = ON);
GO
```

**Optimize dimension tables:**

```sql
-- Server dimension - add covering index
CREATE NONCLUSTERED INDEX IX_Server_Name_Active_Monitoring
ON dim.Server (ServerName)
INCLUDE (ServerKey, Environment, BusinessCriticality, MonitoringEnabled)
WHERE IsCurrent = 1  -- Filtered index for current records only
WITH (DATA_COMPRESSION = PAGE, ONLINE = ON);

-- Add index for environment-based queries
CREATE NONCLUSTERED INDEX IX_Server_Environment_Current
ON dim.Server (Environment, IsCurrent)
INCLUDE (ServerKey, ServerName, BusinessCriticality)
WITH (DATA_COMPRESSION = PAGE, ONLINE = ON);
GO
```

---

### 12.2.2 Statistics Management

**Automated statistics updates:**

```sql
-- Enable auto-update statistics with async
ALTER DATABASE DBAOpsRepository 
SET AUTO_UPDATE_STATISTICS_ASYNC ON;

-- Create procedure to update statistics on schedule
CREATE PROCEDURE meta.usp_UpdateStatistics
    @SamplePercent INT = 30
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @sql NVARCHAR(MAX);
    DECLARE @TableName NVARCHAR(256);
    
    -- Update statistics on fact tables
    DECLARE stats_cursor CURSOR FOR
    SELECT QUOTENAME(s.name) + '.' + QUOTENAME(t.name)
    FROM sys.tables t
    JOIN sys.schemas s ON t.schema_id = s.schema_id
    WHERE s.name IN ('fact', 'ctl')
      AND t.is_ms_shipped = 0;
    
    OPEN stats_cursor;
    FETCH NEXT FROM stats_cursor INTO @TableName;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @sql = 'UPDATE STATISTICS ' + @TableName + 
                   ' WITH SAMPLE ' + CAST(@SamplePercent AS VARCHAR) + ' PERCENT;';
        
        PRINT 'Updating statistics: ' + @TableName;
        EXEC sp_executesql @sql;
        
        FETCH NEXT FROM stats_cursor INTO @TableName;
    END
    
    CLOSE stats_cursor;
    DEALLOCATE stats_cursor;
    
    PRINT 'Statistics update completed.';
END
GO

-- Schedule weekly (Sunday 3 AM)
```

---

### 12.2.3 Query Optimization

**Identify slow queries using Query Store:**

```sql
-- Find top resource-consuming queries
SELECT TOP 20
    q.query_id,
    qt.query_sql_text,
    rs.count_executions,
    rs.avg_duration / 1000.0 AS avg_duration_ms,
    rs.max_duration / 1000.0 AS max_duration_ms,
    rs.avg_cpu_time / 1000.0 AS avg_cpu_ms,
    rs.avg_logical_io_reads AS avg_reads,
    rs.last_execution_time
FROM sys.query_store_query q
JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
JOIN sys.query_store_plan p ON q.query_id = p.query_id
JOIN sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time >= DATEADD(DAY, -7, GETDATE())
ORDER BY rs.avg_duration DESC;

-- Find queries with high variation (potential parameter sniffing)
SELECT TOP 20
    q.query_id,
    qt.query_sql_text,
    rs.count_executions,
    rs.avg_duration / 1000.0 AS avg_duration_ms,
    rs.stdev_duration / 1000.0 AS stdev_duration_ms,
    rs.stdev_duration / NULLIF(rs.avg_duration, 0) AS coefficient_of_variation
FROM sys.query_store_query q
JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
JOIN sys.query_store_plan p ON q.query_id = p.query_id
JOIN sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time >= DATEADD(DAY, -7, GETDATE())
  AND rs.count_executions > 10
ORDER BY rs.stdev_duration / NULLIF(rs.avg_duration, 0) DESC;
```

**Optimize critical reporting queries:**

```sql
-- BEFORE: Slow server health query
-- This query scans entire fact table
SELECT 
    s.ServerName,
    AVG(pm.CPUUtilizationPercent) AS AvgCPU,
    AVG(pm.PageLifeExpectancy) AS AvgPLE
FROM fact.PerformanceMetrics pm
JOIN dim.Server s ON pm.ServerKey = s.ServerKey
WHERE pm.CollectionDateTime >= DATEADD(DAY, -1, GETDATE())
GROUP BY s.ServerName;

-- AFTER: Optimized with proper index usage
-- Add OPTION (RECOMPILE) for parameter sniffing issues
SELECT 
    s.ServerName,
    AVG(pm.CPUUtilizationPercent) AS AvgCPU,
    AVG(pm.PageLifeExpectancy) AS AvgPLE
FROM fact.PerformanceMetrics pm WITH (INDEX(IX_PerformanceMetrics_DateTime_Server))
JOIN dim.Server s WITH (INDEX(IX_Server_Name_Active_Monitoring))
    ON pm.ServerKey = s.ServerKey
WHERE pm.CollectionDateTime >= DATEADD(DAY, -1, GETDATE())
  AND s.IsCurrent = 1
GROUP BY s.ServerName
OPTION (MAXDOP 4);  -- Limit parallelism for consistency

-- Create indexed view for common aggregations
CREATE VIEW reports.vw_DailyServerPerformance
WITH SCHEMABINDING
AS
SELECT 
    pm.ServerKey,
    CAST(pm.CollectionDateTime AS DATE) AS CollectionDate,
    COUNT_BIG(*) AS SampleCount,
    AVG(pm.CPUUtilizationPercent) AS AvgCPU,
    AVG(pm.PageLifeExpectancy) AS AvgPLE,
    AVG(pm.ReadLatencyMS) AS AvgReadLatency,
    AVG(pm.WriteLatencyMS) AS AvgWriteLatency,
    AVG(pm.PerformanceScore) AS AvgScore
FROM fact.PerformanceMetrics pm
GROUP BY pm.ServerKey, CAST(pm.CollectionDateTime AS DATE);
GO

-- Create clustered index on view (makes it materialized)
CREATE UNIQUE CLUSTERED INDEX IX_DailyServerPerformance
ON reports.vw_DailyServerPerformance (ServerKey, CollectionDate);
GO

-- Now queries against this view are MUCH faster
SELECT 
    s.ServerName,
    dsp.CollectionDate,
    dsp.AvgCPU,
    dsp.AvgPLE
FROM reports.vw_DailyServerPerformance dsp
JOIN dim.Server s ON dsp.ServerKey = s.ServerKey
WHERE dsp.CollectionDate >= DATEADD(DAY, -30, GETDATE())
  AND s.IsCurrent = 1;
```

Let me continue with collector optimization, parallel processing tuning, and resource management:


---

## 12.3 Collector Performance Optimization

### 12.3.1 Parallel Collection Tuning

**Optimize parallel processing:**

```powershell
<#
.SYNOPSIS
    Optimized performance metrics collector

.DESCRIPTION
    Tuned for maximum throughput with minimal resource consumption
#>

param(
    [int]$ThrottleLimit = 20,  # Default: 20 parallel threads
    [int]$BatchSize = 100,     # Process servers in batches
    [int]$TimeoutSeconds = 60  # Per-server timeout
)

Import-Module dbatools

$config = Get-Content "C:\DBAOps\Config\dbaops-config.json" | ConvertFrom-Json
$repoServer = $config.repository.server
$repoDatabase = $config.repository.database

# Get servers to collect from
$servers = Invoke-DbaQuery -SqlInstance $repoServer `
                           -Database $repoDatabase `
                           -Query @"
SELECT ServerName, CollectionFrequencyMinutes
FROM config.ServerInventory
WHERE IsActive = 1
  AND MonitoringEnabled = 1
  AND (
      LastCollectionTime IS NULL
      OR DATEDIFF(MINUTE, LastCollectionTime, GETDATE()) >= CollectionFrequencyMinutes
  )
"@

Write-Host "Collecting from $($servers.Count) servers..." -ForegroundColor Cyan

# Determine optimal throttle limit based on server count and resources
$optimalThrottle = [Math]::Min(
    $ThrottleLimit,
    [Math]::Max(5, [Math]::Floor($servers.Count / 10))
)

Write-Host "Using throttle limit: $optimalThrottle" -ForegroundColor Gray

# Performance tracking
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$successCount = 0
$failureCount = 0

# Process in batches to manage memory
for ($i = 0; $i -lt $servers.Count; $i += $BatchSize) {
    $batch = $servers | Select-Object -Skip $i -First $BatchSize
    
    Write-Host "`nProcessing batch $([Math]::Floor($i / $BatchSize) + 1) of $([Math]::Ceiling($servers.Count / $BatchSize))..." -ForegroundColor Yellow
    
    # Parallel collection with optimization
    $results = $batch | ForEach-Object -ThrottleLimit $optimalThrottle -Parallel {
        $server = $_.ServerName
        $repoServer = $using:repoServer
        $repoDatabase = $using:repoDatabase
        $timeoutSeconds = $using:TimeoutSeconds
        
        try {
            # Use connection pooling and timeout
            $query = @"
SELECT 
    @@SERVERNAME AS ServerName,
    SYSDATETIME() AS CollectionDateTime,
    
    -- CPU (optimized single query)
    (SELECT TOP 1 SQLProcessUtilization 
     FROM (SELECT record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization
           FROM (SELECT CAST(record AS XML) AS record 
                 FROM sys.dm_os_ring_buffers 
                 WHERE ring_buffer_type = 'RING_BUFFER_SCHEDULER_MONITOR'
                   AND record LIKE '%<SystemHealth>%') AS rb) AS cpu
     ORDER BY SQLProcessUtilization DESC) AS CPUUtilizationPercent,
    
    -- Memory (single query)
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Page life expectancy' AND object_name LIKE '%Buffer Manager%') AS PageLifeExpectancy,
    
    -- I/O (aggregated)
    AVG(io_stall_read_ms / NULLIF(num_of_reads, 0)) AS ReadLatencyMS,
    AVG(io_stall_write_ms / NULLIF(num_of_writes, 0)) AS WriteLatencyMS,
    
    -- Batch requests
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Batch Requests/sec' AND object_name LIKE '%SQL Statistics%') AS BatchRequestsPerSec,
    
    -- User connections
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'User Connections' AND object_name LIKE '%General Statistics%') AS UserConnections,
    
    -- Blocked processes
    (SELECT COUNT(*) FROM sys.dm_exec_requests WHERE blocking_session_id > 0) AS BlockedProcesses
FROM sys.dm_io_virtual_file_stats(NULL, NULL);
"@
            
            # Execute with timeout
            $metrics = Invoke-DbaQuery -SqlInstance $server `
                                      -Query $query `
                                      -QueryTimeout $timeoutSeconds `
                                      -EnableException
            
            if ($metrics) {
                # Insert to repository (batched - will be committed later)
                # Return for batch insert
                return @{
                    Status = 'Success'
                    Server = $server
                    Metrics = $metrics
                }
            }
        }
        catch {
            return @{
                Status = 'Failed'
                Server = $server
                Error = $_.Exception.Message
            }
        }
    }
    
    # Batch insert results to repository
    $successResults = $results | Where-Object {$_.Status -eq 'Success'}
    
    if ($successResults.Count -gt 0) {
        # Build bulk insert
        $insertValues = $successResults | ForEach-Object {
            $m = $_.Metrics
            "('$($m.ServerName)', '$($m.CollectionDateTime)', $($m.CPUUtilizationPercent), " +
            "$($m.PageLifeExpectancy), $($m.ReadLatencyMS), $($m.WriteLatencyMS), " +
            "$($m.BatchRequestsPerSec), $($m.UserConnections), $($m.BlockedProcesses))"
        }
        
        $bulkInsert = @"
INSERT INTO fact.PerformanceMetrics (
    ServerKey, CollectionDateTime,
    CPUUtilizationPercent, PageLifeExpectancy,
    ReadLatencyMS, WriteLatencyMS,
    BatchRequestsPerSec, UserConnections, BlockedProcesses
)
SELECT 
    s.ServerKey,
    v.CollectionDateTime,
    v.CPUUtilizationPercent,
    v.PageLifeExpectancy,
    v.ReadLatencyMS,
    v.WriteLatencyMS,
    v.BatchRequestsPerSec,
    v.UserConnections,
    v.BlockedProcesses
FROM (VALUES
    $($insertValues -join ",`n    ")
) AS v(ServerName, CollectionDateTime, CPUUtilizationPercent, PageLifeExpectancy,
       ReadLatencyMS, WriteLatencyMS, BatchRequestsPerSec, UserConnections, BlockedProcesses)
JOIN dim.Server s ON v.ServerName = s.ServerName AND s.IsCurrent = 1;
"@
        
        Invoke-DbaQuery -SqlInstance $repoServer `
                       -Database $repoDatabase `
                       -Query $bulkInsert
        
        $successCount += $successResults.Count
    }
    
    $failureCount += ($results | Where-Object {$_.Status -eq 'Failed'}).Count
    
    # Memory management - force garbage collection between batches
    [System.GC]::Collect()
    [System.GC]::WaitForPendingFinalizers()
    [System.GC]::Collect()
}

$stopwatch.Stop()

# Log collection activity
Invoke-DbaQuery -SqlInstance $repoServer `
               -Database $repoDatabase `
               -Query @"
INSERT INTO log.CollectionActivity (
    CollectorName, ActivityDate, TotalServers, SuccessCount, FailureCount, DurationMinutes
)
VALUES (
    '$env:COMPUTERNAME',
    SYSDATETIME(),
    $($servers.Count),
    $successCount,
    $failureCount,
    $($stopwatch.Elapsed.TotalMinutes)
)
"@

# Performance summary
Write-Host "`n==================================================================" -ForegroundColor Green
Write-Host "Collection Summary:" -ForegroundColor Green
Write-Host "  Total Servers:    $($servers.Count)" -ForegroundColor White
Write-Host "  Success:          $successCount" -ForegroundColor Green
Write-Host "  Failed:           $failureCount" -ForegroundColor $(if($failureCount -gt 0){'Red'}else{'Gray'})
Write-Host "  Duration:         $($stopwatch.Elapsed.TotalSeconds) seconds" -ForegroundColor White
Write-Host "  Throughput:       $([Math]::Round($servers.Count / $stopwatch.Elapsed.TotalMinutes, 2)) servers/minute" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Green
```

---

### 12.3.2 Connection Pooling

**Optimize database connections:**

```powershell
# Configure connection pooling in collectors
function Get-OptimizedConnection {
    param(
        [string]$ServerInstance,
        [int]$PoolSize = 100,
        [int]$ConnectionTimeout = 15
    )
    
    $connectionString = "Server=$ServerInstance;" +
                       "Database=master;" +
                       "Integrated Security=True;" +
                       "Application Name=DBAOps-Collector;" +
                       "Max Pool Size=$PoolSize;" +
                       "Min Pool Size=5;" +
                       "Connection Timeout=$ConnectionTimeout;" +
                       "Pooling=True"
    
    return $connectionString
}

# Reuse connections across collections
$script:connectionCache = @{}

function Invoke-CachedQuery {
    param(
        [string]$ServerInstance,
        [string]$Query
    )
    
    if (!$script:connectionCache.ContainsKey($ServerInstance)) {
        $script:connectionCache[$ServerInstance] = Get-OptimizedConnection -ServerInstance $ServerInstance
    }
    
    $connectionString = $script:connectionCache[$ServerInstance]
    
    # Execute query using pooled connection
    Invoke-DbaQuery -SqlConnectionString $connectionString -Query $Query
}
```

---

## 12.4 Resource Management

### 12.4.1 Resource Governor

**Control resource consumption:**

```sql
-- Create resource pool for DBAOps operations
CREATE RESOURCE POOL DBAOps_Pool
WITH (
    MIN_CPU_PERCENT = 10,      -- Minimum 10% CPU guaranteed
    MAX_CPU_PERCENT = 40,      -- Maximum 40% CPU (don't overwhelm server)
    MIN_MEMORY_PERCENT = 10,   -- Minimum 10% memory guaranteed
    MAX_MEMORY_PERCENT = 30    -- Maximum 30% memory
);
GO

-- Create workload group
CREATE WORKLOAD GROUP DBAOps_Workload
WITH (
    IMPORTANCE = MEDIUM,
    REQUEST_MAX_MEMORY_GRANT_PERCENT = 10,  -- Limit individual query memory
    REQUEST_MAX_CPU_TIME_SEC = 300,         -- 5 minute timeout
    REQUEST_MEMORY_GRANT_TIMEOUT_SEC = 60,  -- 1 minute timeout for memory grant
    MAX_DOP = 4                             -- Limit parallelism
)
USING DBAOps_Pool;
GO

-- Classifier function to route DBAOps queries
CREATE FUNCTION dbo.fn_DBAOpsClassifier()
RETURNS SYSNAME
WITH SCHEMABINDING
AS
BEGIN
    DECLARE @WorkloadGroup SYSNAME = 'default';
    
    IF APP_NAME() LIKE 'DBAOps%'
        SET @WorkloadGroup = 'DBAOps_Workload';
    
    RETURN @WorkloadGroup;
END
GO

-- Enable Resource Governor
ALTER RESOURCE GOVERNOR WITH (CLASSIFIER_FUNCTION = dbo.fn_DBAOpsClassifier);
ALTER RESOURCE GOVERNOR RECONFIGURE;
GO

-- Monitor resource usage
SELECT 
    g.name AS WorkloadGroup,
    r.name AS ResourcePool,
    s.session_id,
    s.login_name,
    s.program_name,
    s.cpu_time AS CPUTimeMS,
    s.memory_usage * 8 AS MemoryKB,
    r.total_cpu_usage_ms,
    r.total_cpu_delayed_ms
FROM sys.dm_exec_sessions s
JOIN sys.dm_resource_governor_workload_groups g ON s.group_id = g.group_id
JOIN sys.dm_resource_governor_resource_pools r ON g.pool_id = r.pool_id
WHERE g.name = 'DBAOps_Workload';
```

---

### 12.4.2 Data Retention and Archival

**Automatic data archival:**

```sql
-- Create archive tables
CREATE TABLE fact.PerformanceMetrics_Archive (
    MetricKey BIGINT,
    ServerKey INT,
    CollectionDateTime DATETIME2,
    CPUUtilizationPercent DECIMAL(5,2),
    PageLifeExpectancy INT,
    ReadLatencyMS DECIMAL(10,2),
    WriteLatencyMS DECIMAL(10,2),
    PerformanceScore AS (
        CASE 
            WHEN PageLifeExpectancy < 300 THEN 20
            WHEN PageLifeExpectancy < 600 THEN 50
            WHEN PageLifeExpectancy < 1000 THEN 75
            ELSE 95
        END
    ) PERSISTED,
    
    INDEX CCI_PerformanceMetrics_Archive CLUSTERED COLUMNSTORE
) ON [PRIMARY];
GO

-- Procedure to archive old data
CREATE PROCEDURE meta.usp_ArchiveOldData
    @RetentionDays INT = 90,
    @BatchSize INT = 100000
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @CutoffDate DATETIME2 = DATEADD(DAY, -@RetentionDays, GETDATE());
    DECLARE @RowsArchived INT = 0;
    DECLARE @TotalArchived INT = 0;
    
    PRINT 'Archiving data older than ' + CONVERT(VARCHAR, @CutoffDate, 120);
    
    WHILE 1 = 1
    BEGIN
        -- Move data to archive in batches
        BEGIN TRANSACTION;
        
        WITH DataToArchive AS (
            SELECT TOP (@BatchSize) *
            FROM fact.PerformanceMetrics
            WHERE CollectionDateTime < @CutoffDate
        )
        INSERT INTO fact.PerformanceMetrics_Archive (
            MetricKey, ServerKey, CollectionDateTime,
            CPUUtilizationPercent, PageLifeExpectancy,
            ReadLatencyMS, WriteLatencyMS
        )
        SELECT 
            MetricKey, ServerKey, CollectionDateTime,
            CPUUtilizationPercent, PageLifeExpectancy,
            ReadLatencyMS, WriteLatencyMS
        FROM DataToArchive;
        
        SET @RowsArchived = @@ROWCOUNT;
        
        -- Delete archived data
        DELETE TOP (@BatchSize) FROM fact.PerformanceMetrics
        WHERE CollectionDateTime < @CutoffDate;
        
        COMMIT TRANSACTION;
        
        SET @TotalArchived += @RowsArchived;
        
        PRINT 'Archived ' + CAST(@RowsArchived AS VARCHAR) + ' rows (Total: ' + CAST(@TotalArchived AS VARCHAR) + ')';
        
        -- Exit if no more rows
        IF @RowsArchived < @BatchSize
            BREAK;
        
        -- Small delay to avoid overwhelming system
        WAITFOR DELAY '00:00:01';
    END
    
    PRINT 'Archive complete. Total rows archived: ' + CAST(@TotalArchived AS VARCHAR);
    
    -- Update statistics after large delete
    UPDATE STATISTICS fact.PerformanceMetrics WITH SAMPLE 30 PERCENT;
END
GO

-- Schedule monthly archival (first Sunday at 2 AM)
```

---

## 12.5 Scaling to 1000+ Servers

### 12.5.1 Partitioning Strategy

**Partition fact tables by date:**

```sql
-- Create partition function (monthly partitions)
CREATE PARTITION FUNCTION PF_MonthlyPartition (DATETIME2)
AS RANGE RIGHT FOR VALUES (
    '2024-01-01', '2024-02-01', '2024-03-01', '2024-04-01',
    '2024-05-01', '2024-06-01', '2024-07-01', '2024-08-01',
    '2024-09-01', '2024-10-01', '2024-11-01', '2024-12-01',
    '2025-01-01', '2025-02-01', '2025-03-01', '2025-04-01',
    '2025-05-01', '2025-06-01', '2025-07-01', '2025-08-01',
    '2025-09-01', '2025-10-01', '2025-11-01', '2025-12-01'
);
GO

-- Create partition scheme
CREATE PARTITION SCHEME PS_MonthlyPartition
AS PARTITION PF_MonthlyPartition
ALL TO ([PRIMARY]);  -- In production, use multiple filegroups
GO

-- Create partitioned table (new design for large scale)
CREATE TABLE fact.PerformanceMetrics_Partitioned (
    MetricKey BIGINT IDENTITY(1,1),
    ServerKey INT NOT NULL,
    TimeKey INT NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    
    CPUUtilizationPercent DECIMAL(5,2),
    PageLifeExpectancy INT,
    ReadLatencyMS DECIMAL(10,2),
    WriteLatencyMS DECIMAL(10,2),
    BatchRequestsPerSec INT,
    UserConnections INT,
    BlockedProcesses INT,
    
    PerformanceScore AS (
        CASE 
            WHEN PageLifeExpectancy < 300 THEN 20
            WHEN PageLifeExpectancy < 600 THEN 50
            WHEN PageLifeExpectancy < 1000 THEN 75
            ELSE 95
        END
    ) PERSISTED,
    
    CONSTRAINT PK_PerformanceMetrics_Partitioned 
        PRIMARY KEY CLUSTERED (CollectionDateTime, MetricKey)
        ON PS_MonthlyPartition(CollectionDateTime)
) ON PS_MonthlyPartition(CollectionDateTime);
GO

-- Create nonclustered columnstore index for analytics
CREATE NONCLUSTERED COLUMNSTORE INDEX NCCI_PerformanceMetrics_Partitioned
ON fact.PerformanceMetrics_Partitioned (
    ServerKey, TimeKey, CollectionDateTime,
    CPUUtilizationPercent, PageLifeExpectancy,
    ReadLatencyMS, WriteLatencyMS, PerformanceScore
)
ON PS_MonthlyPartition(CollectionDateTime);
GO

-- Procedure to manage partitions
CREATE PROCEDURE meta.usp_ManagePartitions
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Add new partition for next month
    DECLARE @NextMonth DATETIME2 = DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1));
    
    -- Check if partition already exists
    IF NOT EXISTS (
        SELECT 1 FROM sys.partition_range_values prv
        JOIN sys.partition_functions pf ON prv.function_id = pf.function_id
        WHERE pf.name = 'PF_MonthlyPartition'
          AND CAST(prv.value AS DATETIME2) = @NextMonth
    )
    BEGIN
        ALTER PARTITION SCHEME PS_MonthlyPartition
        NEXT USED [PRIMARY];
        
        ALTER PARTITION FUNCTION PF_MonthlyPartition()
        SPLIT RANGE (@NextMonth);
        
        PRINT 'Added partition for: ' + CONVERT(VARCHAR, @NextMonth, 120);
    END
    
    -- Archive old partitions (older than 90 days)
    DECLARE @ArchiveDate DATETIME2 = DATEADD(DAY, -90, GETDATE());
    
    -- Switch old partition to archive table
    -- (Implementation would go here)
    
END
GO
```

Let me complete Chapter 12 with monitoring, best practices, and a comprehensive case study:


---

### 12.5.2 Load Balancing Collectors

**Distribute load across multiple collectors:**

```powershell
<#
.SYNOPSIS
    Intelligent server assignment for load balancing

.DESCRIPTION
    Assigns servers to collectors based on current load and capacity
#>

function Update-CollectorAssignments {
    param(
        [string]$RepositoryServer = "DBAOps-Listener"
    )
    
    # Get current collector load
    $collectorLoad = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                     -Database "DBAOpsRepository" `
                                     -Query @"
SELECT 
    AssignedCollector AS CollectorName,
    COUNT(*) AS ServerCount,
    AVG(CollectionFrequencyMinutes) AS AvgFrequency
FROM config.ServerInventory
WHERE IsActive = 1 AND MonitoringEnabled = 1
GROUP BY AssignedCollector
"@
    
    # Get total servers
    $totalServers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                    -Database "DBAOpsRepository" `
                                    -Query @"
SELECT COUNT(*) AS Total 
FROM config.ServerInventory 
WHERE IsActive = 1 AND MonitoringEnabled = 1
"@
    
    $collectors = @("COLLECTOR01", "COLLECTOR02", "COLLECTOR03")
    $targetPerCollector = [Math]::Ceiling($totalServers.Total / $collectors.Count)
    
    Write-Host "Total servers: $($totalServers.Total)" -ForegroundColor Cyan
    Write-Host "Target per collector: $targetPerCollector" -ForegroundColor Cyan
    Write-Host "`nCurrent distribution:" -ForegroundColor Yellow
    $collectorLoad | Format-Table -AutoSize
    
    # Rebalance if needed
    $maxLoad = ($collectorLoad | Measure-Object -Property ServerCount -Maximum).Maximum
    $minLoad = ($collectorLoad | Measure-Object -Property ServerCount -Minimum).Minimum
    
    if (($maxLoad - $minLoad) > ($targetPerCollector * 0.2)) {
        Write-Host "`nRebalancing needed (variance: $($maxLoad - $minLoad))" -ForegroundColor Yellow
        
        # Reassign using round-robin
        $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                   -Database "DBAOpsRepository" `
                                   -Query "SELECT ServerName FROM config.ServerInventory WHERE IsActive = 1 AND MonitoringEnabled = 1 ORDER BY ServerName"
        
        $collectorIndex = 0
        foreach ($server in $servers) {
            $assignedCollector = $collectors[$collectorIndex]
            
            Invoke-DbaQuery -SqlInstance $RepositoryServer `
                           -Database "DBAOpsRepository" `
                           -Query @"
UPDATE config.ServerInventory 
SET AssignedCollector = '$assignedCollector'
WHERE ServerName = '$($server.ServerName)'
"@
            
            $collectorIndex = ($collectorIndex + 1) % $collectors.Count
        }
        
        Write-Host "✓ Rebalancing complete" -ForegroundColor Green
    } else {
        Write-Host "`n✓ Load is balanced (variance: $($maxLoad - $minLoad))" -ForegroundColor Green
    }
}
```

---

## 12.6 Performance Monitoring

### 12.6.1 Framework Performance Dashboard

**Real-time performance metrics:**

```sql
CREATE VIEW reports.vw_FrameworkPerformanceDashboard AS
WITH CurrentMetrics AS (
    SELECT TOP 1 *
    FROM meta.FrameworkPerformance
    ORDER BY MetricDate DESC
),
HistoricalAvg AS (
    SELECT 
        AVG(AvgCollectionDurationSec) AS AvgDuration,
        AVG(AvgQueryDurationMS) AS AvgQueryTime,
        AVG(CPUPercent) AS AvgCPU,
        AVG(MemoryUsedMB) AS AvgMemory
    FROM meta.FrameworkPerformance
    WHERE MetricDate >= DATEADD(DAY, -7, GETDATE())
)
SELECT 
    -- Current state
    cm.TotalServersMonitored,
    cm.CollectionsPerHour,
    cm.AvgCollectionDurationSec,
    cm.AvgQueryDurationMS,
    cm.CPUPercent,
    cm.MemoryUsedMB,
    cm.ActiveCollectors,
    
    -- Comparison to 7-day average
    cm.AvgCollectionDurationSec - ha.AvgDuration AS DurationVsAvg,
    cm.AvgQueryDurationMS - ha.AvgQueryTime AS QueryTimeVsAvg,
    cm.CPUPercent - ha.AvgCPU AS CPUVsAvg,
    cm.MemoryUsedMB - ha.AvgMemory AS MemoryVsAvg,
    
    -- Performance status
    CASE 
        WHEN cm.AvgCollectionDurationSec > ha.AvgDuration * 1.5 THEN 'Degraded'
        WHEN cm.AvgCollectionDurationSec > ha.AvgDuration * 1.2 THEN 'Warning'
        ELSE 'Normal'
    END AS PerformanceStatus,
    
    -- Throughput
    CAST(cm.TotalServersMonitored * 60.0 / NULLIF(cm.AvgCollectionDurationSec, 0) AS DECIMAL(10,2)) AS TheoreticalMaxThroughput
FROM CurrentMetrics cm
CROSS JOIN HistoricalAvg ha;
GO

-- Alert on performance degradation
CREATE PROCEDURE alert.usp_CheckFrameworkPerformance
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        700 AS AlertRuleID,
        CASE PerformanceStatus
            WHEN 'Degraded' THEN 'Critical'
            WHEN 'Warning' THEN 'High'
            ELSE 'Medium'
        END AS Severity,
        'Framework Performance ' + PerformanceStatus AS AlertTitle,
        'Collection duration: ' + CAST(CAST(AvgCollectionDurationSec AS INT) AS VARCHAR) + 's ' +
        '(avg: ' + CAST(CAST(AvgCollectionDurationSec - DurationVsAvg AS INT) AS VARCHAR) + 's). ' +
        'Repository CPU: ' + CAST(CAST(CPUPercent AS INT) AS VARCHAR) + '%. ' +
        'Active collectors: ' + CAST(ActiveCollectors AS VARCHAR) AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM reports.vw_FrameworkPerformanceDashboard
    WHERE PerformanceStatus IN ('Warning', 'Degraded');
END
GO
```

---

## 12.7 Best Practices

### 12.7.1 Performance Tuning Checklist

**Optimization checklist:**

```
┌────────────────────────────────────────────────────────────┐
│         PERFORMANCE TUNING CHECKLIST                        │
├────────────────────────────────────────────────────────────┤
│                                                             │
│ Database Optimization:                                      │
│ ☐ Columnstore indexes on fact tables                       │
│ ☐ Nonclustered indexes for common queries                  │
│ ☐ Statistics updated weekly (30% sample)                   │
│ ☐ Indexed views for common aggregations                    │
│ ☐ Query Store enabled and monitored                        │
│ ☐ Resource Governor configured                             │
│ ☐ Auto-update statistics async enabled                     │
│ ☐ Data compression enabled (PAGE)                          │
│                                                             │
│ Collector Optimization:                                     │
│ ☐ Parallel processing tuned (optimal throttle)             │
│ ☐ Connection pooling enabled                               │
│ ☐ Batch size optimized (100-200 servers)                   │
│ ☐ Per-server timeout configured (60 seconds)               │
│ ☐ Memory management (GC between batches)                   │
│ ☐ Load balanced across collectors                          │
│ ☐ Retry logic implemented                                  │
│ ☐ Heartbeat monitoring active                              │
│                                                             │
│ Data Management:                                            │
│ ☐ Retention policy defined (90 days recommended)           │
│ ☐ Archival process automated                               │
│ ☐ Partitioning implemented (monthly)                       │
│ ☐ Old partitions switched to archive                       │
│ ☐ Partition management automated                           │
│                                                             │
│ Resource Management:                                        │
│ ☐ CPU limit configured (40% max)                           │
│ ☐ Memory limit configured (30% max)                        │
│ ☐ MAXDOP set appropriately (4 recommended)                 │
│ ☐ Query timeout configured                                 │
│ ☐ Resource usage monitored                                 │
│                                                             │
│ Monitoring:                                                 │
│ ☐ Framework performance captured every 15 min              │
│ ☐ Performance dashboard reviewed daily                     │
│ ☐ Slow queries identified weekly                           │
│ ☐ Index fragmentation checked monthly                      │
│ ☐ Baseline metrics established                             │
│ ☐ Performance alerts configured                            │
│                                                             │
│ Scaling:                                                    │
│ ☐ Multiple collectors for 500+ servers                     │
│ ☐ Always On AG for repository HA                           │
│ ☐ Separate filegroups for partitions                       │
│ ☐ SSD storage for repository data files                    │
│ ☐ Network bandwidth adequate (1 Gbps min)                  │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

---

## 12.8 Case Study: Global Enterprise Scaling

**Background:**

GlobalTech operates 1,200 SQL Servers across 15 countries.

**The Challenge:**

**Initial Implementation (250 servers):**
- Single collector
- Collection time: 45 minutes for 250 servers
- Repository growing 50 GB/month
- Queries slowing down
- No partitioning strategy

**Scaling Problem:**
- Need to monitor 1,200 servers (4.8x growth)
- Cannot add 4.8x collection time (would be 3.6 hours!)
- Repository would grow 240 GB/month
- Queries would be unusable

**Target:**
- Collect from 1,200 servers in under 30 minutes
- Keep repository queries under 5 seconds
- Maintain 90-day retention
- Stay within 500 GB total database size

**The Solution (8-Week Optimization Project):**

**Week 1-2: Performance Analysis**

```sql
-- Identified slow queries
-- Before optimization: 45 seconds average
SELECT s.ServerName, AVG(pm.CPUUtilizationPercent)
FROM fact.PerformanceMetrics pm
JOIN dim.Server s ON pm.ServerKey = s.ServerKey
WHERE pm.CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
GROUP BY s.ServerName;
-- Execution time: 45,238 ms

-- After adding indexed view: <1 second
SELECT s.ServerName, dsp.AvgCPU
FROM reports.vw_DailyServerPerformance dsp
JOIN dim.Server s ON dsp.ServerKey = s.ServerKey
WHERE dsp.CollectionDate >= DATEADD(DAY, -30, GETDATE());
-- Execution time: 847 ms (98.1% improvement)
```

**Week 3-4: Index Optimization**
- Added 12 nonclustered indexes on fact tables
- Created 5 indexed views for common reports
- Implemented columnstore compression
- Result: Average query time 45s → 3.2s (93% faster)

**Week 5-6: Collector Scaling**
- Deployed 5 collectors (was 1)
- Implemented dynamic load balancing
- Optimized parallel processing (ThrottleLimit: 30)
- Added connection pooling
- Result: Collection time 45min → 12min for 1,200 servers

**Week 7-8: Data Management**
- Implemented monthly partitioning
- Created automated archival (>90 days)
- Configured Resource Governor (40% CPU limit)
- Set up partition rotation automation

**Results After Optimization:**

| Metric | Before (250 servers) | After (1,200 servers) | Improvement |
|--------|---------------------|----------------------|-------------|
| **Collection** ||||
| Total servers | 250 | 1,200 | 4.8x scale |
| Collection time | 45 minutes | 22 minutes | 51% faster (despite 4.8x servers!) |
| Throughput | 5.6 servers/min | 54.5 servers/min | **873% faster** |
| Collection failures | 8% | 1.2% | 85% fewer failures |
| **Repository Performance** ||||
| Avg query time | 45 seconds | 3.2 seconds | **93% faster** |
| Dashboard load time | 30 seconds | 4 seconds | 87% faster |
| Database size | 180 GB | 485 GB | Controlled growth |
| Index fragmentation | 45% | 8% | 82% improvement |
| **Resource Consumption** ||||
| Repository CPU | 75% | 38% | 49% reduction |
| Repository memory | 28 GB | 31 GB | Only 11% increase |
| Collector CPU | 85% | 42% (avg across 5) | 51% reduction |
| Network bandwidth | 95 Mbps | 180 Mbps | 89% increase (acceptable) |

**Cost Analysis:**

**Additional Infrastructure:**
- 4 additional collectors: $20K (servers)
- SSD storage upgrade: $15K
- Network upgrade (1 Gbps → 10 Gbps): $8K
**Total Infrastructure: $43K**

**Implementation:**
- Consulting/optimization: $35K
- Internal DBA time: $12K
**Total Cost: $90K**

**Value Delivered:**

**Operational Benefits:**
- Monitoring 1,200 servers (vs. 250): Coverage of entire estate
- 93% faster queries: Improved decision making
- 51% faster collection: More frequent metrics
- 85% fewer failures: Better reliability
**Estimated Annual Value: $380K** (improved uptime, faster issue resolution)

**ROI: 322%**
**Payback Period: 112 days**

**DBA Team Feedback:**

*"Before optimization, our dashboards were unusable. Queries took 30-45 seconds. Users complained constantly. Now everything is instant. The indexed views were a game-changer."*
— Senior DBA

*"We went from monitoring 250 servers to 1,200 servers while actually reducing collection time. The parallel processing optimization and multiple collectors made this possible."*
— Infrastructure Manager

**CTO Statement:**

*"The optimization project allowed us to scale monitoring to our entire global SQL Server estate without proportionally scaling infrastructure costs. The team's focus on partitioning and archival ensures we won't hit these limits again."*

**Key Success Factors:**

1. **Measured Before Optimizing**: Baseline metrics critical
2. **Indexed Views**: Biggest query performance win (98% improvement)
3. **Horizontal Scaling**: 5 collectors vs. 1 super-powerful collector
4. **Partitioning**: Keeps queries fast as data grows
5. **Resource Governor**: Prevents runaway queries
6. **Automated Archival**: Keeps database size manageable
7. **Load Balancing**: Even distribution across collectors

**Lessons Learned:**

1. **Index Maintenance**: Weekly statistics update critical at scale
2. **Parallel Tuning**: Sweet spot was ThrottleLimit=30 (not max)
3. **Connection Pooling**: Reduced connection overhead 60%
4. **Query Store**: Invaluable for identifying regressions
5. **Partitioning Setup**: Should have done from day 1
6. **Network**: 10 Gbps necessary for 1,000+ servers
7. **Monitoring the Monitor**: Framework performance dashboard essential

---

## Chapter 12 Summary

This chapter covered performance tuning and scaling:

**Key Takeaways:**

1. **Measure First**: Establish baselines before optimizing
2. **Index Strategy**: Columnstore + nonclustered + indexed views
3. **Query Optimization**: Use Query Store to find slow queries
4. **Collector Tuning**: Optimize parallelism, connection pooling, batching
5. **Resource Management**: Resource Governor prevents runaway queries
6. **Data Management**: Archival and partitioning essential at scale
7. **Horizontal Scaling**: Multiple collectors better than one powerful collector
8. **Continuous Monitoring**: Track framework performance metrics

**Production Implementation:**

✅ Framework performance tracking
✅ Columnstore indexes on fact tables
✅ Nonclustered indexes for queries
✅ Indexed views for aggregations
✅ Optimized parallel collection
✅ Connection pooling
✅ Resource Governor configuration
✅ Automated archival procedures
✅ Monthly partitioning
✅ Load balancing across collectors

**Best Practices:**

✅ Update statistics weekly (30% sample)
✅ Monitor Query Store for regressions
✅ Limit parallelism (MAXDOP 4)
✅ Use Resource Governor (40% CPU max)
✅ Archive data older than 90 days
✅ Partition by month
✅ Add collectors for 500+ servers
✅ Implement connection pooling
✅ Batch server processing (100-200)
✅ Monitor framework performance

**Performance Targets:**

| Servers | Collectors | Collection Time | Query Time | Database Size (90d) |
|---------|------------|-----------------|------------|---------------------|
| 100 | 1 | 5-10 min | <2 sec | <100 GB |
| 500 | 2-3 | 15-20 min | <5 sec | <300 GB |
| 1,000 | 4-5 | 20-30 min | <5 sec | <500 GB |
| 2,000 | 8-10 | 30-40 min | <5 sec | <800 GB |

**Connection to Next Chapter:**

Chapter 13 covers Cloud Integration, showing how to extend DBAOps to Azure SQL Database, AWS RDS, and hybrid environments, including Azure Arc, cloud-native monitoring, and cross-platform management.

---

## Review Questions

**Multiple Choice:**

1. What is the recommended MAXDOP setting for DBAOps queries?
   a) 0 (unlimited)
   b) 1
   c) 4
   d) 8

2. How often should statistics be updated on fact tables?
   a) Daily
   b) Weekly
   c) Monthly
   d) Never (auto-update only)

3. What was the throughput improvement in the GlobalTech case study?
   a) 200%
   b) 500%
   c) 873%
   d) 1000%

**Short Answer:**

4. Explain the benefits of columnstore indexes for fact tables. What are the tradeoffs?

5. Describe the difference between horizontal scaling (multiple collectors) and vertical scaling (one powerful collector). Which is better and why?

6. What is the purpose of Resource Governor in the DBAOps framework?

**Essay Questions:**

7. Design a performance tuning strategy for a DBAOps deployment monitoring 2,000 servers. Include:
   - Index strategy
   - Collector architecture
   - Partitioning approach
   - Resource management
   - Expected performance metrics

8. Analyze the GlobalTech case study. What optimization had the biggest impact? What would you do differently?

**Hands-On Exercises:**

9. **Exercise 12.1: Index Optimization**
   - Analyze current index usage
   - Identify missing indexes
   - Create columnstore indexes
   - Implement indexed views
   - Measure query improvement

10. **Exercise 12.2: Collector Tuning**
    - Baseline collection performance
    - Optimize ThrottleLimit
    - Implement connection pooling
    - Tune batch size
    - Measure throughput improvement

11. **Exercise 12.3: Implement Partitioning**
    - Create partition function
    - Create partition scheme
    - Migrate to partitioned table
    - Create archive process
    - Test partition switching

12. **Exercise 12.4: Performance Monitoring**
    - Implement framework metrics
    - Create performance dashboard
    - Set up Query Store monitoring
    - Configure performance alerts
    - Generate tuning report

---

*End of Chapter 12*

**Next Chapter:** Chapter 13 - Cloud Integration

