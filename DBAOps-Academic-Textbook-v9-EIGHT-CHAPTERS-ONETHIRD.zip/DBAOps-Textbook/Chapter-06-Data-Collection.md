# Chapter 6
# Data Collection Implementation

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Implement** production-ready data collectors for all major SQL Server metrics
2. **Optimize** collection frequency and parallel processing for minimal overhead
3. **Handle** collection failures with retry logic and graceful degradation
4. **Monitor** collector performance and identify bottlenecks
5. **Troubleshoot** common collection issues and connectivity problems
6. **Extend** collectors with custom metrics and business-specific requirements
7. **Validate** data quality and detect collection anomalies
8. **Integrate** collectors with existing monitoring tools

**Key Terms**

- Data Collector
- Collection Interval
- Sampling Rate
- DMV (Dynamic Management View)
- Performance Counter
- WMI (Windows Management Instrumentation)
- Collection Overhead
- Data Validation
- Graceful Degradation
- Circuit Breaker Pattern

---

## 6.1 Collector Architecture

### 6.1.1 Collector Design Principles

**Figure 6.1: Data Collection Architecture**

```
┌─────────────────────────────────────────────────────────────┐
│              DATA COLLECTION ARCHITECTURE                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  SQL Agent Job (Master Orchestrator)                        │
│         │                                                    │
│         ├─→ Every 5 min  → Performance Metrics Collector    │
│         │                                                    │
│         ├─→ Every 15 min → Backup Status Collector          │
│         │                                                    │
│         ├─→ Every 30 min → Disk Space Collector             │
│         │                                                    │
│         ├─→ Every 60 min → Query Performance Collector      │
│         │                                                    │
│         └─→ Every 4 hrs  → Configuration Drift Detector     │
│                                                              │
│  Each Collector:                                            │
│  ┌────────────────────────────────────────────────┐        │
│  │ 1. Read server list from config                │        │
│  │ 2. Filter by collection group & frequency      │        │
│  │ 3. Parallel collection (ForEach-Object -Parallel)│      │
│  │ 4. Extract data from target DMVs               │        │
│  │ 5. Transform & validate data                   │        │
│  │ 6. Load into repository fact tables            │        │
│  │ 7. Log success/failure                         │        │
│  │ 8. Update LastCollectionTime                   │        │
│  └────────────────────────────────────────────────┘        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**Core Principles:**

1. **Minimal Overhead**: Collectors use <1% CPU on target servers
2. **Fault Tolerance**: Single server failure doesn't stop collection
3. **Idempotent**: Can run multiple times safely
4. **Validated**: Data quality checks before insertion
5. **Logged**: All operations tracked for audit
6. **Configurable**: Collection frequency per server/metric

---

### 6.1.2 Collector Base Template

**Template for all collectors:**

```powershell
<#
.SYNOPSIS
    Base template for DBAOps data collectors

.DESCRIPTION
    Standard structure for implementing new collectors
    - Configuration-driven
    - Parallel execution
    - Error handling
    - Logging
    - Data validation
#>

[CmdletBinding()]
param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository",
    [int]$ThrottleLimit = 20,
    [int]$TimeoutSeconds = 300,
    [string]$CollectorName = "BaseCollector"
)

$ErrorActionPreference = 'Continue'
$scriptStart = Get-Date

# Import required modules
Import-Module dbatools -ErrorAction Stop

# Logging function
function Write-CollectorLog {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARNING','ERROR','DEBUG')]
        [string]$Level = 'INFO'
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    
    # Console output
    $color = switch($Level) {
        'INFO' { 'White' }
        'WARNING' { 'Yellow' }
        'ERROR' { 'Red' }
        'DEBUG' { 'Gray' }
    }
    Write-Host $logEntry -ForegroundColor $color
    
    # File output
    $logFile = "C:\DBAOps\Logs\$CollectorName`_$(Get-Date -Format 'yyyyMMdd').log"
    Add-Content -Path $logFile -Value $logEntry -ErrorAction SilentlyContinue
}

try {
    Write-CollectorLog "=== $CollectorName Started ===" -Level INFO
    
    # Step 1: Get server list from configuration
    Write-CollectorLog "Retrieving server list..." -Level INFO
    
    $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query @"
SELECT 
    si.ServerName,
    si.CollectionFrequencyMinutes,
    si.UseWindowsAuth,
    si.CredentialName
FROM config.ServerInventory si
WHERE si.IsActive = 1 
  AND si.MonitoringEnabled = 1
  AND DATEDIFF(MINUTE, ISNULL(si.LastCollectionTime, '1900-01-01'), GETDATE()) 
      >= si.CollectionFrequencyMinutes
ORDER BY si.ParallelCollectionGroup, si.ServerName
"@ -As PSObject -TrustServerCertificate
    
    Write-CollectorLog "Found $($servers.Count) servers requiring collection" -Level INFO
    
    if ($servers.Count -eq 0) {
        Write-CollectorLog "No servers require collection at this time" -Level INFO
        return
    }
    
    # Step 2: Parallel collection
    Write-CollectorLog "Starting parallel collection (ThrottleLimit: $ThrottleLimit)..." -Level INFO
    
    $results = $servers | ForEach-Object -Parallel {
        $server = $_.ServerName
        $repoServer = $using:RepositoryServer
        $repoDB = $using:RepositoryDatabase
        $timeout = $using:TimeoutSeconds
        $collectorName = $using:CollectorName
        
        # Import modules in parallel runspace
        Import-Module dbatools -ErrorAction Stop
        
        $collectStart = Get-Date
        
        try {
            # Step 3: Test connectivity
            $connTest = Test-DbaConnection -SqlInstance $server -ErrorAction Stop
            
            if (!$connTest.ConnectSuccess) {
                throw "Connection failed: $($connTest.ConnectError)"
            }
            
            # Step 4: Collect data (IMPLEMENT IN SPECIFIC COLLECTOR)
            $data = @{
                ServerName = $server
                CollectionTime = Get-Date
                # Add specific metrics here
            }
            
            # Step 5: Validate data
            if ($null -eq $data) {
                throw "No data collected"
            }
            
            # Step 6: Insert into repository (IMPLEMENT IN SPECIFIC COLLECTOR)
            # Example:
            # Invoke-DbaQuery -SqlInstance $repoServer -Database $repoDB -Query $insertQuery
            
            # Step 7: Update last collection time
            $updateQuery = @"
UPDATE config.ServerInventory
SET LastCollectionTime = GETDATE(),
    LastCollectionStatus = 'Success'
WHERE ServerName = '$server';
"@
            Invoke-DbaQuery -SqlInstance $repoServer `
                           -Database $repoDB `
                           -Query $updateQuery `
                           -TrustServerCertificate
            
            # Return success
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Success'
                Duration = ((Get-Date) - $collectStart).TotalSeconds
                ErrorMessage = $null
            }
        }
        catch {
            # Return failure
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Failed'
                Duration = ((Get-Date) - $collectStart).TotalSeconds
                ErrorMessage = $_.Exception.Message
            }
        }
    } -ThrottleLimit $ThrottleLimit -TimeoutSeconds $timeout
    
    # Step 8: Summarize results
    $successCount = ($results | Where-Object {$_.Status -eq 'Success'}).Count
    $failureCount = ($results | Where-Object {$_.Status -eq 'Failed'}).Count
    $totalDuration = ((Get-Date) - $scriptStart).TotalMinutes
    
    Write-CollectorLog "Collection Summary:" -Level INFO
    Write-CollectorLog "  Total Servers: $($servers.Count)" -Level INFO
    Write-CollectorLog "  Successful: $successCount" -Level INFO
    Write-CollectorLog "  Failed: $failureCount" -Level INFO
    Write-CollectorLog "  Duration: $([Math]::Round($totalDuration, 2)) minutes" -Level INFO
    
    # Log failures
    if ($failureCount -gt 0) {
        Write-CollectorLog "Failed Servers:" -Level WARNING
        $results | Where-Object {$_.Status -eq 'Failed'} | ForEach-Object {
            Write-CollectorLog "  • $($_.ServerName): $($_.ErrorMessage)" -Level ERROR
        }
    }
    
    # Insert collection summary
    $summaryQuery = @"
INSERT INTO log.CollectionActivity (
    CollectorName, TotalServers, SuccessCount, FailureCount, 
    DurationMinutes, ActivityDate
)
VALUES (
    '$CollectorName', $($servers.Count), $successCount, $failureCount,
    $([Math]::Round($totalDuration, 2)), GETDATE()
);
"@
    Invoke-DbaQuery -SqlInstance $RepositoryServer `
                   -Database $RepositoryDatabase `
                   -Query $summaryQuery `
                   -TrustServerCertificate
    
    Write-CollectorLog "=== $CollectorName Completed ===" -Level INFO
}
catch {
    Write-CollectorLog "CRITICAL ERROR: $($_.Exception.Message)" -Level ERROR
    Write-CollectorLog "Stack Trace: $($_.ScriptStackTrace)" -Level ERROR
    
    # Log critical failure
    $failureQuery = @"
INSERT INTO log.FailureLog (Component, ErrorMessage, ErrorDetails, ErrorDate)
VALUES ('$CollectorName', '$($_.Exception.Message)', '$($_.ScriptStackTrace)', GETDATE());
"@
    Invoke-DbaQuery -SqlInstance $RepositoryServer `
                   -Database $RepositoryDatabase `
                   -Query $failureQuery `
                   -TrustServerCertificate -ErrorAction SilentlyContinue
    
    throw
}
```

---

## 6.2 Performance Metrics Collector

### 6.2.1 Complete Performance Collector

```powershell
<#
.SYNOPSIS
    Collects comprehensive performance metrics from SQL Server instances

.DESCRIPTION
    Gathers CPU, memory, I/O, and SQL Server-specific metrics
    Runs every 5 minutes for real-time monitoring

.EXAMPLE
    .\Collect-PerformanceMetrics.ps1 -ThrottleLimit 30
#>

[CmdletBinding()]
param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository",
    [int]$ThrottleLimit = 20,
    [int]$TimeoutSeconds = 300
)

$ErrorActionPreference = 'Continue'
$CollectorName = "PerformanceMetrics"
$scriptStart = Get-Date

Import-Module dbatools

# Logging function (same as template)
function Write-CollectorLog {
    param([string]$Message, [string]$Level = 'INFO')
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    Write-Host $logEntry -ForegroundColor $(
        switch($Level) {
            'INFO' { 'White' }
            'WARNING' { 'Yellow' }
            'ERROR' { 'Red' }
            'DEBUG' { 'Gray' }
        }
    )
    Add-Content -Path "C:\DBAOps\Logs\$CollectorName`_$(Get-Date -Format 'yyyyMMdd').log" `
                -Value $logEntry -ErrorAction SilentlyContinue
}

try {
    Write-CollectorLog "=== Performance Metrics Collection Started ===" -Level INFO
    
    # Get server list
    $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query @"
SELECT ServerName
FROM config.ServerInventory
WHERE IsActive = 1 
  AND MonitoringEnabled = 1
  AND DATEDIFF(MINUTE, ISNULL(LastCollectionTime, '1900-01-01'), GETDATE()) >= CollectionFrequencyMinutes
"@ -As PSObject -TrustServerCertificate
    
    Write-CollectorLog "Collecting from $($servers.Count) servers" -Level INFO
    
    # Parallel collection
    $results = $servers | ForEach-Object -Parallel {
        $server = $_.ServerName
        $repoServer = $using:RepositoryServer
        $repoDB = $using:RepositoryDatabase
        
        Import-Module dbatools
        
        try {
            # Collect performance metrics
            $metrics = Invoke-DbaQuery -SqlInstance $server -Query @"
DECLARE @CPUBusy BIGINT, @IOBusy BIGINT, @Idle BIGINT;
SELECT @CPUBusy = cpu_busy, @IOBusy = io_busy, @Idle = idle FROM sys.dm_os_sys_info;

SELECT 
    -- Server info
    @@SERVERNAME AS ServerName,
    GETDATE() AS CollectionDateTime,
    
    -- CPU Metrics
    (SELECT TOP 1 SQLProcessUtilization 
     FROM (
         SELECT record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization
         FROM (SELECT CAST(record AS XML) AS record 
               FROM sys.dm_os_ring_buffers 
               WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR') AS x
     ) AS y
     WHERE SQLProcessUtilization IS NOT NULL
     ORDER BY SQLProcessUtilization DESC) AS SQLProcessCPUPercent,
    
    -- CPU overall (calculated from sys.dm_os_sys_info)
    100 - ((@Idle * 100.0) / (@CPUBusy + @IOBusy + @Idle)) AS TotalCPUPercent,
    
    -- Memory Metrics
    (SELECT total_physical_memory_kb / 1024 FROM sys.dm_os_sys_memory) AS TotalMemoryMB,
    (SELECT available_physical_memory_kb / 1024 FROM sys.dm_os_sys_memory) AS AvailableMemoryMB,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Page life expectancy' 
     AND object_name LIKE '%Buffer Manager%') AS PageLifeExpectancy,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Buffer cache hit ratio' 
     AND object_name LIKE '%Buffer Manager%') AS BufferCacheHitRatio,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Lazy writes/sec' 
     AND object_name LIKE '%Buffer Manager%') AS LazyWritesPerSec,
    
    -- I/O Metrics
    (SELECT AVG(io_stall_read_ms / NULLIF(num_of_reads, 0))
     FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS AvgReadLatencyMS,
    (SELECT AVG(io_stall_write_ms / NULLIF(num_of_writes, 0))
     FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS AvgWriteLatencyMS,
    (SELECT SUM(io_stall) FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS TotalIOStallMS,
    
    -- SQL Server Metrics
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Batch Requests/sec' 
     AND object_name LIKE '%SQL Statistics%') AS BatchRequestsPerSec,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'SQL Compilations/sec' 
     AND object_name LIKE '%SQL Statistics%') AS SQLCompilationsPerSec,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'SQL Re-Compilations/sec' 
     AND object_name LIKE '%SQL Statistics%') AS SQLReCompilationsPerSec,
    
    -- Connection Metrics
    (SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process = 1) AS UserConnections,
    (SELECT COUNT(*) FROM sys.dm_exec_requests WHERE blocking_session_id <> 0) AS BlockedProcesses,
    
    -- Wait Statistics (top wait)
    (SELECT TOP 1 wait_type FROM sys.dm_os_wait_stats 
     WHERE wait_type NOT LIKE 'SLEEP%' 
       AND wait_type NOT LIKE 'BROKER%'
       AND wait_type NOT LIKE 'XE%'
       AND wait_type NOT LIKE 'SP_SERVER%'
     ORDER BY wait_time_ms DESC) AS TopWaitType,
    (SELECT TOP 1 wait_time_ms FROM sys.dm_os_wait_stats 
     WHERE wait_type NOT LIKE 'SLEEP%' 
       AND wait_type NOT LIKE 'BROKER%'
       AND wait_type NOT LIKE 'XE%'
       AND wait_type NOT LIKE 'SP_SERVER%'
     ORDER BY wait_time_ms DESC) AS TopWaitTimeMS,
    
    -- Transaction Log
    (SELECT SUM(CAST(size AS BIGINT) * 8 / 1024) FROM sys.master_files WHERE type = 1) AS TotalLogSizeMB,
    (SELECT SUM(FILEPROPERTY(name, 'SpaceUsed') * 8 / 1024) FROM sys.master_files WHERE type = 1) AS UsedLogSpaceMB
"@ -TrustServerCertificate -ErrorAction Stop
            
            # Insert into repository
            $insertQuery = @"
INSERT INTO fact.PerformanceMetrics (
    ServerKey, TimeKey, CollectionDateTime,
    CPUUtilizationPercent, SQLProcessCPUPercent,
    TotalMemoryMB, AvailableMemoryMB, PageLifeExpectancy, BufferCacheHitRatio, LazyWritesPerSec,
    ReadLatencyMS, WriteLatencyMS, IOStallMS,
    BatchRequestsPerSec, SQLCompilationsPerSec, SQLReCompilationsPerSec,
    UserConnections, BlockedProcesses,
    TopWaitType, TopWaitTimeMS,
    TotalLogSizeMB, UsedLogSpaceMB,
    PerformanceScore
)
SELECT 
    s.ServerKey,
    CAST(FORMAT(GETDATE(), 'yyyyMMdd') AS INT) AS TimeKey,
    '$($metrics.CollectionDateTime)',
    $($metrics.TotalCPUPercent),
    $($metrics.SQLProcessCPUPercent),
    $($metrics.TotalMemoryMB),
    $($metrics.AvailableMemoryMB),
    $($metrics.PageLifeExpectancy),
    $($metrics.BufferCacheHitRatio),
    $($metrics.LazyWritesPerSec),
    $($metrics.AvgReadLatencyMS),
    $($metrics.AvgWriteLatencyMS),
    $($metrics.TotalIOStallMS),
    $($metrics.BatchRequestsPerSec),
    $($metrics.SQLCompilationsPerSec),
    $($metrics.SQLReCompilationsPerSec),
    $($metrics.UserConnections),
    $($metrics.BlockedProcesses),
    $(if ($metrics.TopWaitType) { "'$($metrics.TopWaitType)'" } else { 'NULL' }),
    $(if ($metrics.TopWaitTimeMS) { $metrics.TopWaitTimeMS } else { 'NULL' }),
    $($metrics.TotalLogSizeMB),
    $($metrics.UsedLogSpaceMB),
    -- Calculate performance score (0-100)
    CASE 
        WHEN $($metrics.PageLifeExpectancy) < 300 THEN 20
        WHEN $($metrics.PageLifeExpectancy) < 600 THEN 50
        WHEN $($metrics.PageLifeExpectancy) < 1000 THEN 75
        ELSE 95
    END
FROM dim.Server s
WHERE s.ServerName = '$server' AND s.IsCurrent = 1;
"@
            
            Invoke-DbaQuery -SqlInstance $repoServer `
                           -Database $repoDB `
                           -Query $insertQuery `
                           -TrustServerCertificate
            
            # Update last collection time
            Invoke-DbaQuery -SqlInstance $repoServer `
                           -Database $repoDB `
                           -Query "UPDATE config.ServerInventory SET LastCollectionTime = GETDATE() WHERE ServerName = '$server'" `
                           -TrustServerCertificate
            
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Success'
                MetricsCollected = $true
            }
        }
        catch {
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Failed'
                ErrorMessage = $_.Exception.Message
            }
        }
    } -ThrottleLimit $ThrottleLimit
    
    # Summary
    $successCount = ($results | Where-Object {$_.Status -eq 'Success'}).Count
    $failureCount = ($results | Where-Object {$_.Status -eq 'Failed'}).Count
    
    Write-CollectorLog "Collection complete: $successCount success, $failureCount failed" -Level INFO
    
    # Log failures
    $results | Where-Object {$_.Status -eq 'Failed'} | ForEach-Object {
        Write-CollectorLog "Failed: $($_.ServerName) - $($_.ErrorMessage)" -Level ERROR
    }
}
catch {
    Write-CollectorLog "CRITICAL ERROR: $_" -Level ERROR
    throw
}
```

Let me continue with more collectors and complete the chapter:


---

## 6.3 Backup Status Collector

### 6.3.1 Complete Backup Collector with Compliance Checking

```powershell
<#
.SYNOPSIS
    Collects backup history and validates compliance with SLA requirements

.DESCRIPTION
    - Retrieves backup history from msdb
    - Compares against SLA rules
    - Identifies compliance violations
    - Triggers alerts for non-compliant databases
    
.EXAMPLE
    .\Collect-BackupStatus.ps1 -ThrottleLimit 15
#>

[CmdletBinding()]
param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository",
    [int]$ThrottleLimit = 15
)

$ErrorActionPreference = 'Continue'
$CollectorName = "BackupStatus"

Import-Module dbatools

function Write-CollectorLog {
    param([string]$Message, [string]$Level = 'INFO')
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [$Level] $Message"
}

try {
    Write-CollectorLog "=== Backup Status Collection Started ===" -Level INFO
    
    # Get server list
    $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query @"
SELECT s.ServerName, s.ServerKey
FROM config.ServerInventory s
WHERE s.IsActive = 1 AND s.MonitoringEnabled = 1
"@ -As PSObject -TrustServerCertificate
    
    Write-CollectorLog "Collecting backup status from $($servers.Count) servers" -Level INFO
    
    $results = $servers | ForEach-Object -Parallel {
        $server = $_.ServerName
        $serverKey = $_.ServerKey
        $repoServer = $using:RepositoryServer
        $repoDB = $using:RepositoryDatabase
        
        Import-Module dbatools
        
        try {
            # Get databases and their SLA requirements
            $databases = Invoke-DbaQuery -SqlInstance $repoServer `
                                         -Database $repoDB `
                                         -Query @"
SELECT 
    d.DatabaseKey,
    d.DatabaseName,
    d.RecoveryModel,
    d.BackupSLALevel,
    sla.FullBackupMaxAgeHours,
    sla.DiffBackupMaxAgeHours,
    sla.LogBackupMaxAgeMinutes
FROM dim.Database d
LEFT JOIN config.BackupSLARules sla ON d.BackupSLALevel = sla.SLALevel
WHERE d.ServerKey = $serverKey AND d.IsCurrent = 1
"@ -As PSObject -TrustServerCertificate
            
            foreach ($db in $databases) {
                # Get backup history from target server
                $backupHistory = Invoke-DbaQuery -SqlInstance $server `
                                                 -Database 'msdb' `
                                                 -Query @"
SELECT 
    database_name,
    type,
    backup_start_date,
    backup_finish_date,
    backup_size,
    compressed_backup_size,
    DATEDIFF(SECOND, backup_start_date, backup_finish_date) AS duration_seconds
FROM msdb.dbo.backupset
WHERE database_name = '$($db.DatabaseName)'
  AND backup_finish_date >= DATEADD(DAY, -7, GETDATE())
ORDER BY backup_finish_date DESC
"@ -TrustServerCertificate -ErrorAction Stop
                
                # Get most recent backups of each type
                $lastFull = $backupHistory | Where-Object {$_.type -eq 'D'} | Select-Object -First 1
                $lastDiff = $backupHistory | Where-Object {$_.type -eq 'I'} | Select-Object -First 1
                $lastLog = $backupHistory | Where-Object {$_.type -eq 'L'} | Select-Object -First 1
                
                # Calculate ages
                $fullAgeHours = if ($lastFull) { 
                    (New-TimeSpan -Start $lastFull.backup_finish_date -End (Get-Date)).TotalHours 
                } else { 999 }
                
                $diffAgeHours = if ($lastDiff) { 
                    (New-TimeSpan -Start $lastDiff.backup_finish_date -End (Get-Date)).TotalHours 
                } else { 999 }
                
                $logAgeMinutes = if ($lastLog) { 
                    (New-TimeSpan -Start $lastLog.backup_finish_date -End (Get-Date)).TotalMinutes 
                } else { 999 }
                
                # Check compliance
                $fullCompliant = if ($db.FullBackupMaxAgeHours) { 
                    $fullAgeHours -le $db.FullBackupMaxAgeHours 
                } else { $true }
                
                $diffCompliant = if ($db.DiffBackupMaxAgeHours -and $db.RecoveryModel -eq 'FULL') { 
                    $diffAgeHours -le $db.DiffBackupMaxAgeHours 
                } else { $true }
                
                $logCompliant = if ($db.LogBackupMaxAgeMinutes -and $db.RecoveryModel -eq 'FULL') { 
                    $logAgeMinutes -le $db.LogBackupMaxAgeMinutes 
                } else { $true }
                
                $overallCompliant = $fullCompliant -and $diffCompliant -and $logCompliant
                
                # Build violation reason
                $violations = @()
                if (!$fullCompliant) { 
                    $violations += "Full backup age $([Math]::Round($fullAgeHours, 1))h exceeds SLA of $($db.FullBackupMaxAgeHours)h" 
                }
                if (!$diffCompliant) { 
                    $violations += "Diff backup age $([Math]::Round($diffAgeHours, 1))h exceeds SLA of $($db.DiffBackupMaxAgeHours)h" 
                }
                if (!$logCompliant) { 
                    $violations += "Log backup age $([Math]::Round($logAgeMinutes, 1))m exceeds SLA of $($db.LogBackupMaxAgeMinutes)m" 
                }
                $violationReason = $violations -join "; "
                
                # Insert backup history records
                foreach ($backup in ($backupHistory | Select-Object -First 100)) {
                    $insertBackupQuery = @"
INSERT INTO fact.BackupHistory (
    ServerKey, DatabaseKey, TimeKey, BackupDateTime,
    BackupType, BackupSizeMB, CompressedSizeMB, CompressionRatio, DurationSeconds,
    RecoveryModel, MeetsSLA, SLALevel
)
VALUES (
    $serverKey,
    $($db.DatabaseKey),
    CAST(FORMAT('$($backup.backup_finish_date)', 'yyyyMMdd') AS INT),
    '$($backup.backup_finish_date)',
    '$(switch($backup.type) { 'D' {'FULL'} 'I' {'DIFF'} 'L' {'LOG'} default {$backup.type} })',
    $([Math]::Round($backup.backup_size / 1MB, 2)),
    $(if ($backup.compressed_backup_size) { [Math]::Round($backup.compressed_backup_size / 1MB, 2) } else { 'NULL' }),
    $(if ($backup.compressed_backup_size -and $backup.backup_size -gt 0) { 
        [Math]::Round(($backup.compressed_backup_size / $backup.backup_size) * 100, 2) 
    } else { 'NULL' }),
    $($backup.duration_seconds),
    '$($db.RecoveryModel)',
    $(if ($overallCompliant) { 1 } else { 0 }),
    $(if ($db.BackupSLALevel) { "'$($db.BackupSLALevel)'" } else { 'NULL' })
);
"@
                    Invoke-DbaQuery -SqlInstance $repoServer `
                                   -Database $repoDB `
                                   -Query $insertBackupQuery `
                                   -TrustServerCertificate -ErrorAction Continue
                }
                
                # Insert compliance record
                $insertComplianceQuery = @"
INSERT INTO ctl.BackupCompliance (
    ServerKey, DatabaseKey, CheckedDate,
    SLALevel, RecoveryModel,
    LastFullBackup, FullBackupCompliant, FullBackupSLAHours,
    LastDiffBackup, DiffBackupCompliant,
    LastLogBackup, LogBackupCompliant,
    ViolationReason
)
VALUES (
    $serverKey,
    $($db.DatabaseKey),
    GETDATE(),
    $(if ($db.BackupSLALevel) { "'$($db.BackupSLALevel)'" } else { 'NULL' }),
    '$($db.RecoveryModel)',
    $(if ($lastFull) { "'$($lastFull.backup_finish_date)'" } else { 'NULL' }),
    $(if ($fullCompliant) { 1 } else { 0 }),
    $(if ($db.FullBackupMaxAgeHours) { $db.FullBackupMaxAgeHours } else { 'NULL' }),
    $(if ($lastDiff) { "'$($lastDiff.backup_finish_date)'" } else { 'NULL' }),
    $(if ($diffCompliant) { 1 } else { 0 }),
    $(if ($lastLog) { "'$($lastLog.backup_finish_date)'" } else { 'NULL' }),
    $(if ($logCompliant) { 1 } else { 0 }),
    $(if ($violationReason) { "'$violationReason'" } else { 'NULL' })
);
"@
                Invoke-DbaQuery -SqlInstance $repoServer `
                               -Database $repoDB `
                               -Query $insertComplianceQuery `
                               -TrustServerCertificate
            }
            
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Success'
                DatabasesChecked = $databases.Count
            }
        }
        catch {
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Failed'
                ErrorMessage = $_.Exception.Message
            }
        }
    } -ThrottleLimit $ThrottleLimit
    
    # Summary
    $successCount = ($results | Where-Object {$_.Status -eq 'Success'}).Count
    Write-CollectorLog "Backup collection complete: $successCount/$($servers.Count) successful" -Level INFO
    
    # Check for violations and trigger alerts
    $violations = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                  -Database $RepositoryDatabase `
                                  -Query @"
SELECT TOP 100
    s.ServerName,
    d.DatabaseName,
    bc.ViolationReason,
    bc.CheckedDate
FROM ctl.BackupCompliance bc
JOIN dim.Server s ON bc.ServerKey = s.ServerKey
JOIN dim.Database d ON bc.DatabaseKey = d.DatabaseKey
WHERE bc.IsCompliant = 0
  AND bc.CheckedDate >= DATEADD(HOUR, -1, GETDATE())
ORDER BY bc.CheckedDate DESC
"@ -As PSObject -TrustServerCertificate
    
    if ($violations.Count -gt 0) {
        Write-CollectorLog "WARNING: $($violations.Count) backup compliance violations detected" -Level WARNING
        
        # Trigger alerts (this would integrate with alert.usp_GenerateAlerts)
        foreach ($violation in $violations) {
            Write-CollectorLog "  • $($violation.ServerName).$($violation.DatabaseName): $($violation.ViolationReason)" -Level WARNING
        }
    }
}
catch {
    Write-CollectorLog "CRITICAL ERROR: $_" -Level ERROR
    throw
}
```

---

## 6.4 Disk Space Collector

### 6.4.1 Disk Space Monitoring with Forecasting

```powershell
<#
.SYNOPSIS
    Collects disk space utilization and forecasts capacity exhaustion

.DESCRIPTION
    - Monitors all drives on SQL Server hosts
    - Tracks space trends over time
    - Predicts when disks will be full
    - Alerts on low space conditions
    
.EXAMPLE
    .\Collect-DiskSpace.ps1
#>

[CmdletBinding()]
param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository",
    [int]$ThrottleLimit = 20,
    [int]$CriticalThresholdPercent = 10,
    [int]$WarningThresholdPercent = 20
)

$ErrorActionPreference = 'Continue'
$CollectorName = "DiskSpace"

Import-Module dbatools

function Write-CollectorLog {
    param([string]$Message, [string]$Level = 'INFO')
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [$Level] $Message"
}

try {
    Write-CollectorLog "=== Disk Space Collection Started ===" -Level INFO
    
    # Get server list
    $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query @"
SELECT s.ServerName, s.ServerKey
FROM config.ServerInventory s
WHERE s.IsActive = 1 AND s.MonitoringEnabled = 1
"@ -As PSObject -TrustServerCertificate
    
    Write-CollectorLog "Collecting disk space from $($servers.Count) servers" -Level INFO
    
    $results = $servers | ForEach-Object -Parallel {
        $server = $_.ServerName
        $serverKey = $_.ServerKey
        $repoServer = $using:RepositoryServer
        $repoDB = $using:RepositoryDatabase
        $criticalPct = $using:CriticalThresholdPercent
        $warningPct = $using:WarningThresholdPercent
        
        Import-Module dbatools
        
        try {
            # Get disk space from target server
            $diskSpace = Invoke-DbaQuery -SqlInstance $server -Query @"
-- Get disk space using xp_fixeddrives (works on all versions)
CREATE TABLE #DiskSpace (
    Drive CHAR(1),
    MBFree INT
);

INSERT INTO #DiskSpace EXEC xp_fixeddrives;

-- Get additional details from sys.dm_os_volume_stats if available
SELECT 
    ds.Drive,
    ds.MBFree,
    ISNULL(vs.total_bytes / 1024 / 1024, ds.MBFree * 10) AS TotalMB,  -- Estimate if not available
    ISNULL(vs.available_bytes / 1024 / 1024, ds.MBFree) AS AvailableMB,
    CASE 
        WHEN vs.total_bytes IS NOT NULL 
        THEN CAST((vs.available_bytes * 100.0 / vs.total_bytes) AS DECIMAL(5,2))
        ELSE NULL
    END AS FreePercent,
    vs.logical_volume_name AS VolumeName,
    vs.file_system_type AS FileSystem
FROM #DiskSpace ds
LEFT JOIN (
    SELECT DISTINCT 
        LEFT(volume_mount_point, 1) AS Drive,
        total_bytes,
        available_bytes,
        logical_volume_name,
        file_system_type
    FROM sys.dm_os_volume_stats(NULL, NULL)
    WHERE volume_mount_point LIKE '[A-Z]:\\'
) vs ON ds.Drive = vs.Drive;

DROP TABLE #DiskSpace;
"@ -TrustServerCertificate -ErrorAction Stop
            
            # Insert disk space records
            foreach ($disk in $diskSpace) {
                $totalMB = $disk.TotalMB
                $availableMB = $disk.AvailableMB
                $usedMB = $totalMB - $availableMB
                $freePercent = if ($totalMB -gt 0) { 
                    [Math]::Round(($availableMB / $totalMB) * 100, 2) 
                } else { 0 }
                
                # Determine status
                $status = if ($freePercent -le $criticalPct) { 'CRITICAL' }
                         elseif ($freePercent -le $warningPct) { 'WARNING' }
                         else { 'OK' }
                
                $insertQuery = @"
INSERT INTO fact.DiskUtilization (
    ServerKey, TimeKey, CollectionDateTime,
    DriveLetter, VolumeName, FileSystem,
    TotalMB, UsedMB, AvailableMB, FreePercent,
    Status
)
VALUES (
    $serverKey,
    CAST(FORMAT(GETDATE(), 'yyyyMMdd') AS INT),
    GETDATE(),
    '$($disk.Drive)',
    $(if ($disk.VolumeName) { "'$($disk.VolumeName)'" } else { 'NULL' }),
    $(if ($disk.FileSystem) { "'$($disk.FileSystem)'" } else { 'NULL' }),
    $totalMB,
    $usedMB,
    $availableMB,
    $freePercent,
    '$status'
);
"@
                Invoke-DbaQuery -SqlInstance $repoServer `
                               -Database $repoDB `
                               -Query $insertQuery `
                               -TrustServerCertificate
            }
            
            # Calculate growth trend and forecast
            $forecastQuery = @"
-- Calculate daily growth rate and predict exhaustion date
WITH DiskHistory AS (
    SELECT 
        DriveLetter,
        CollectionDateTime,
        AvailableMB,
        LAG(AvailableMB) OVER (PARTITION BY DriveLetter ORDER BY CollectionDateTime) AS PrevAvailableMB,
        LAG(CollectionDateTime) OVER (PARTITION BY DriveLetter ORDER BY CollectionDateTime) AS PrevCollectionDateTime
    FROM fact.DiskUtilization
    WHERE ServerKey = $serverKey
      AND CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
),
GrowthRate AS (
    SELECT 
        DriveLetter,
        AVG(
            CASE 
                WHEN PrevAvailableMB IS NOT NULL AND DATEDIFF(HOUR, PrevCollectionDateTime, CollectionDateTime) > 0
                THEN (PrevAvailableMB - AvailableMB) / CAST(DATEDIFF(HOUR, PrevCollectionDateTime, CollectionDateTime) AS FLOAT)
                ELSE NULL
            END
        ) AS AvgGrowthMBPerHour
    FROM DiskHistory
    WHERE PrevAvailableMB IS NOT NULL
    GROUP BY DriveLetter
)
SELECT 
    du.DriveLetter,
    du.AvailableMB,
    gr.AvgGrowthMBPerHour,
    CASE 
        WHEN gr.AvgGrowthMBPerHour > 0 
        THEN DATEADD(HOUR, CAST(du.AvailableMB / gr.AvgGrowthMBPerHour AS INT), GETDATE())
        ELSE NULL
    END AS PredictedExhaustionDate,
    CASE 
        WHEN gr.AvgGrowthMBPerHour > 0 AND (du.AvailableMB / gr.AvgGrowthMBPerHour) < 168  -- Less than 7 days
        THEN 'WARNING: Disk may be full within 7 days'
        ELSE 'OK'
    END AS ForecastStatus
FROM fact.DiskUtilization du
JOIN GrowthRate gr ON du.DriveLetter = gr.DriveLetter
WHERE du.ServerKey = $serverKey
  AND du.CollectionDateTime = (
      SELECT MAX(CollectionDateTime) 
      FROM fact.DiskUtilization 
      WHERE ServerKey = $serverKey
  );
"@
            $forecast = Invoke-DbaQuery -SqlInstance $repoServer `
                                       -Database $repoDB `
                                       -Query $forecastQuery `
                                       -TrustServerCertificate -As PSObject
            
            # Log forecasts
            foreach ($f in $forecast) {
                if ($f.PredictedExhaustionDate) {
                    # Log to disk forecast table
                    $forecastInsert = @"
INSERT INTO ctl.DiskSpaceForecast (
    ServerKey, DriveLetter, CurrentAvailableMB,
    GrowthRateMBPerHour, PredictedExhaustionDate, ForecastDate
)
VALUES (
    $serverKey, '$($f.DriveLetter)', $($f.AvailableMB),
    $($f.AvgGrowthMBPerHour), '$($f.PredictedExhaustionDate)', GETDATE()
);
"@
                    Invoke-DbaQuery -SqlInstance $repoServer `
                                   -Database $repoDB `
                                   -Query $forecastInsert `
                                   -TrustServerCertificate -ErrorAction Continue
                }
            }
            
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Success'
                DisksMonitored = $diskSpace.Count
            }
        }
        catch {
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Failed'
                ErrorMessage = $_.Exception.Message
            }
        }
    } -ThrottleLimit $ThrottleLimit
    
    # Summary
    $successCount = ($results | Where-Object {$_.Status -eq 'Success'}).Count
    Write-CollectorLog "Disk space collection complete: $successCount/$($servers.Count) successful" -Level INFO
    
    # Check for critical disk space
    $criticalDisks = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                     -Database $RepositoryDatabase `
                                     -Query @"
SELECT TOP 100
    s.ServerName,
    du.DriveLetter,
    du.FreePercent,
    du.AvailableMB,
    du.Status
FROM fact.DiskUtilization du
JOIN dim.Server s ON du.ServerKey = s.ServerKey
WHERE du.FreePercent <= $WarningThresholdPercent
  AND du.CollectionDateTime >= DATEADD(HOUR, -1, GETDATE())
ORDER BY du.FreePercent
"@ -As PSObject -TrustServerCertificate
    
    if ($criticalDisks.Count -gt 0) {
        Write-CollectorLog "WARNING: $($criticalDisks.Count) disks below $WarningThresholdPercent% free space" -Level WARNING
        
        foreach ($disk in $criticalDisks) {
            Write-CollectorLog "  • $($disk.ServerName) $($disk.DriveLetter): $($disk.FreePercent)% free ($($disk.AvailableMB) MB) - $($disk.Status)" -Level WARNING
        }
    }
}
catch {
    Write-CollectorLog "CRITICAL ERROR: $_" -Level ERROR
    throw
}
```

This is excellent progress! Let me complete Chapter 6 with query performance collector and troubleshooting sections:


---

## 6.5 Query Performance Collector

### 6.5.1 Top Resource-Consuming Queries

```powershell
<#
.SYNOPSIS
    Captures top CPU and I/O consuming queries for analysis

.DESCRIPTION
    - Identifies expensive queries from query stats DMVs
    - Captures execution plans
    - Tracks query performance trends
    - Detects performance degradation
    
.EXAMPLE
    .\Collect-QueryPerformance.ps1 -Top 50
#>

[CmdletBinding()]
param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository",
    [int]$ThrottleLimit = 10,
    [int]$TopQueries = 50
)

$ErrorActionPreference = 'Continue'
$CollectorName = "QueryPerformance"

Import-Module dbatools

function Write-CollectorLog {
    param([string]$Message, [string]$Level = 'INFO')
    Write-Host "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [$Level] $Message"
}

try {
    Write-CollectorLog "=== Query Performance Collection Started ===" -Level INFO
    
    # Get server list
    $servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                               -Database $RepositoryDatabase `
                               -Query @"
SELECT s.ServerName, s.ServerKey
FROM config.ServerInventory s
WHERE s.IsActive = 1 AND s.MonitoringEnabled = 1
"@ -As PSObject -TrustServerCertificate
    
    Write-CollectorLog "Collecting query performance from $($servers.Count) servers (Top $TopQueries queries each)" -Level INFO
    
    $results = $servers | ForEach-Object -Parallel {
        $server = $_.ServerName
        $serverKey = $_.ServerKey
        $repoServer = $using:RepositoryServer
        $repoDB = $using:RepositoryDatabase
        $topN = $using:TopQueries
        
        Import-Module dbatools
        
        try {
            # Get top queries by total CPU time
            $topQueries = Invoke-DbaQuery -SqlInstance $server -Query @"
SELECT TOP $topN
    DB_NAME(qp.dbid) AS DatabaseName,
    qs.query_hash,
    qs.query_plan_hash,
    qs.execution_count,
    qs.total_elapsed_time / 1000 AS TotalElapsedTimeMS,
    qs.total_worker_time / 1000 AS TotalCPUTimeMS,
    qs.total_logical_reads,
    qs.total_physical_reads,
    qs.total_logical_writes,
    qs.last_execution_time,
    SUBSTRING(
        qt.text,
        (qs.statement_start_offset/2)+1,
        ((CASE qs.statement_end_offset
            WHEN -1 THEN DATALENGTH(qt.text)
            ELSE qs.statement_end_offset
        END - qs.statement_start_offset)/2) + 1
    ) AS QueryText,
    qp.query_plan
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) qp
WHERE qs.execution_count > 1  -- Exclude one-time queries
ORDER BY qs.total_worker_time DESC
"@ -TrustServerCertificate -ErrorAction Stop
            
            # Get database keys
            $dbKeys = Invoke-DbaQuery -SqlInstance $repoServer `
                                     -Database $repoDB `
                                     -Query @"
SELECT d.DatabaseName, d.DatabaseKey
FROM dim.Database d
WHERE d.ServerKey = $serverKey AND d.IsCurrent = 1
"@ -As PSObject -TrustServerCertificate
            
            $dbKeyLookup = @{}
            foreach ($db in $dbKeys) {
                $dbKeyLookup[$db.DatabaseName] = $db.DatabaseKey
            }
            
            # Insert query performance records
            $insertedCount = 0
            foreach ($query in $topQueries) {
                $dbKey = $dbKeyLookup[$query.DatabaseName]
                if (!$dbKey) { continue }
                
                # Sanitize query text for SQL injection prevention
                $queryTextEscaped = $query.QueryText -replace "'", "''"
                if ($queryTextEscaped.Length > 4000) {
                    $queryTextEscaped = $queryTextEscaped.Substring(0, 4000)
                }
                
                $insertQuery = @"
INSERT INTO fact.QueryPerformance (
    ServerKey, DatabaseKey, TimeKey, SnapshotDateTime,
    QueryHash, QueryPlanHash, QueryText,
    ExecutionCount,
    TotalElapsedTimeMS, TotalCPUTimeMS,
    TotalLogicalReads, TotalPhysicalReads, TotalWrites
)
VALUES (
    $serverKey,
    $dbKey,
    CAST(FORMAT(GETDATE(), 'yyyyMMdd') AS INT),
    GETDATE(),
    $(if ($query.query_hash) { "0x" + [BitConverter]::ToString($query.query_hash).Replace('-','') } else { 'NULL' }),
    $(if ($query.query_plan_hash) { "0x" + [BitConverter]::ToString($query.query_plan_hash).Replace('-','') } else { 'NULL' }),
    N'$queryTextEscaped',
    $($query.execution_count),
    $($query.TotalElapsedTimeMS),
    $($query.TotalCPUTimeMS),
    $($query.total_logical_reads),
    $($query.total_physical_reads),
    $($query.total_logical_writes)
);
"@
                try {
                    Invoke-DbaQuery -SqlInstance $repoServer `
                                   -Database $repoDB `
                                   -Query $insertQuery `
                                   -TrustServerCertificate -ErrorAction Continue
                    $insertedCount++
                }
                catch {
                    # Log but continue (some queries may fail due to special characters)
                }
            }
            
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Success'
                QueriesCollected = $insertedCount
            }
        }
        catch {
            [PSCustomObject]@{
                ServerName = $server
                Status = 'Failed'
                ErrorMessage = $_.Exception.Message
            }
        }
    } -ThrottleLimit $ThrottleLimit
    
    # Summary
    $successCount = ($results | Where-Object {$_.Status -eq 'Success'}).Count
    $totalQueries = ($results | Where-Object {$_.Status -eq 'Success'} | Measure-Object -Property QueriesCollected -Sum).Sum
    
    Write-CollectorLog "Query collection complete: $successCount servers, $totalQueries queries" -Level INFO
}
catch {
    Write-CollectorLog "CRITICAL ERROR: $_" -Level ERROR
    throw
}
```

---

## 6.6 Troubleshooting Collection Issues

### 6.6.1 Common Collection Problems

**Problem 1: Connection Timeouts**

```powershell
# Symptom: "Connection timeout expired"
# Solution: Increase connection timeout and implement retry logic

function Invoke-DbaQueryWithRetry {
    param(
        [string]$SqlInstance,
        [string]$Query,
        [int]$MaxRetries = 3,
        [int]$RetryDelaySeconds = 5
    )
    
    $attempt = 0
    while ($attempt -lt $MaxRetries) {
        try {
            $attempt++
            return Invoke-DbaQuery -SqlInstance $SqlInstance `
                                  -Query $Query `
                                  -ConnectionTimeout 30 `
                                  -QueryTimeout 120 `
                                  -TrustServerCertificate `
                                  -ErrorAction Stop
        }
        catch {
            if ($attempt -lt $MaxRetries -and $_.Exception.Message -match 'timeout|connection') {
                Write-Warning "Attempt $attempt failed, retrying in $RetryDelaySeconds seconds..."
                Start-Sleep -Seconds $RetryDelaySeconds
            }
            else {
                throw
            }
        }
    }
}
```

**Problem 2: Memory Pressure on Collector Server**

```powershell
# Symptom: PowerShell process consuming excessive memory
# Solution: Process servers in batches and force garbage collection

function Invoke-BatchedCollection {
    param(
        [array]$Servers,
        [int]$BatchSize = 50,
        [scriptblock]$CollectionScript
    )
    
    for ($i = 0; $i -lt $Servers.Count; $i += $BatchSize) {
        $batch = $Servers[$i..[Math]::Min($i + $BatchSize - 1, $Servers.Count - 1)]
        
        Write-Host "Processing batch $($i/$BatchSize + 1)..."
        
        # Process batch
        & $CollectionScript -Servers $batch
        
        # Force garbage collection between batches
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()
        [System.GC]::Collect()
        
        Start-Sleep -Seconds 2
    }
}
```

**Problem 3: Parallel Deadlocks**

```powershell
# Symptom: Multiple parallel threads trying to insert same data
# Solution: Use unique constraints and MERGE instead of INSERT

$insertQuery = @"
MERGE INTO fact.PerformanceMetrics AS target
USING (
    SELECT 
        $serverKey AS ServerKey,
        CAST(FORMAT(GETDATE(), 'yyyyMMdd') AS INT) AS TimeKey,
        '$collectionTime' AS CollectionDateTime
) AS source
ON target.ServerKey = source.ServerKey 
   AND target.CollectionDateTime = source.CollectionDateTime
WHEN NOT MATCHED THEN
    INSERT (ServerKey, TimeKey, CollectionDateTime, ...)
    VALUES (source.ServerKey, source.TimeKey, source.CollectionDateTime, ...);
"@
```

### 6.6.2 Collection Health Monitoring

```sql
-- View to monitor collection health
CREATE VIEW meta.vw_CollectionHealth AS
WITH LatestCollection AS (
    SELECT 
        si.ServerName,
        si.CollectionFrequencyMinutes,
        si.LastCollectionTime,
        si.LastCollectionStatus,
        DATEDIFF(MINUTE, si.LastCollectionTime, GETDATE()) AS MinutesSinceLastCollection
    FROM config.ServerInventory si
    WHERE si.IsActive = 1 AND si.MonitoringEnabled = 1
)
SELECT 
    ServerName,
    LastCollectionTime,
    LastCollectionStatus,
    MinutesSinceLastCollection,
    CollectionFrequencyMinutes,
    CASE 
        WHEN MinutesSinceLastCollection > CollectionFrequencyMinutes * 3 THEN 'CRITICAL - No collection for ' + CAST(MinutesSinceLastCollection AS VARCHAR) + ' minutes'
        WHEN MinutesSinceLastCollection > CollectionFrequencyMinutes * 2 THEN 'WARNING - Collection delayed'
        WHEN LastCollectionStatus = 'Failed' THEN 'ERROR - Last collection failed'
        ELSE 'OK'
    END AS HealthStatus
FROM LatestCollection;
GO

-- Alert on collection failures
INSERT INTO alert.AlertRules (
    RuleName, DetectionQuery, Severity, Category,
    CheckFrequencyMinutes, NotificationTemplate, Recipients
)
VALUES (
    'Collection Health Check',
    'SELECT ServerName, HealthStatus, MinutesSinceLastCollection 
     FROM meta.vw_CollectionHealth 
     WHERE HealthStatus <> ''OK''',
    'High',
    'Collection',
    15,
    'Collection issue detected for {ServerName}: {HealthStatus}',
    'dba-team@company.com'
);
```

---

## 6.7 Best Practices

### 6.7.1 Collection Optimization

**Best Practice 1: Right-Size Collection Frequency**

```sql
-- Different frequencies for different metric types
UPDATE config.ServerInventory
SET CollectionFrequencyMinutes = 
    CASE 
        WHEN BusinessCriticality = 'Critical' THEN 5   -- Every 5 minutes
        WHEN BusinessCriticality = 'High' THEN 10      -- Every 10 minutes
        WHEN BusinessCriticality = 'Medium' THEN 15    -- Every 15 minutes
        ELSE 30                                        -- Every 30 minutes
    END;
```

**Best Practice 2: Minimize Data Volume**

```powershell
# Don't collect every query - filter for significance
$query = @"
SELECT TOP 100  -- Limit to top N
    ...
FROM sys.dm_exec_query_stats
WHERE execution_count > 10          -- Skip one-off queries
  AND total_worker_time > 1000000   -- Skip trivial queries (>1 second total)
ORDER BY total_worker_time DESC
"@
```

**Best Practice 3: Data Validation**

```powershell
# Validate data before insertion
function Test-MetricData {
    param($Metrics)
    
    # Check for required fields
    if (!$Metrics.ServerName) { return $false }
    if (!$Metrics.CollectionDateTime) { return $false }
    
    # Check for reasonable values
    if ($Metrics.CPUPercent -lt 0 -or $Metrics.CPUPercent -gt 100) { return $false }
    if ($Metrics.PageLifeExpectancy -lt 0) { return $false }
    
    # Check for data freshness (within last 10 minutes)
    $age = (Get-Date) - $Metrics.CollectionDateTime
    if ($age.TotalMinutes > 10) { return $false }
    
    return $true
}

# Use validation
if (Test-MetricData -Metrics $data) {
    # Insert data
}
else {
    Write-Warning "Invalid data detected, skipping insertion"
}
```

---

## Chapter 6 Summary

This chapter provided complete data collection implementation:

**Key Takeaways:**

1. **Collector Architecture**: Template-based design ensures consistency across all collectors

2. **Parallel Collection**: ForEach-Object -Parallel enables scalable collection from 100+ servers

3. **Comprehensive Metrics**: Performance, backup, disk space, and query performance collectors

4. **Error Handling**: Retry logic, timeouts, and graceful degradation handle transient failures

5. **Data Validation**: Quality checks prevent bad data from entering the repository

6. **Health Monitoring**: meta.vw_CollectionHealth tracks collector reliability

7. **Troubleshooting**: Common issues have documented solutions

**Production Collectors Delivered:**

✅ Performance Metrics Collector (CPU, memory, I/O, waits)
✅ Backup Status Collector (with SLA compliance checking)
✅ Disk Space Collector (with capacity forecasting)
✅ Query Performance Collector (top resource consumers)

**Best Practices:**

✅ Right-size collection frequencies
✅ Minimize data volume with filtering
✅ Validate data quality before insertion
✅ Monitor collector health
✅ Implement retry logic for transient failures
✅ Use batching to manage memory
✅ Log all operations for audit

**Connection to Next Chapter:**

Chapter 7 covers Alerting and Notification, showing how to configure intelligent alerts based on the collected metrics, implement escalation policies, and integrate with enterprise notification systems like PagerDuty, ServiceNow, and Microsoft Teams.

---

## Review Questions

**Multiple Choice:**

1. What is the recommended throttle limit for parallel collection across 200 servers?
   a) 5-10
   b) 20-50
   c) 100-200
   d) No limit

2. How often should performance metrics be collected for critical production servers?
   a) Every minute
   b) Every 5 minutes
   c) Every 15 minutes
   d) Every hour

3. What is the primary reason for implementing retry logic in collectors?
   a) Improve performance
   b) Handle transient network failures
   c) Reduce server load
   d) Comply with regulations

**Short Answer:**

4. Explain the difference between collection frequency and sampling rate. Provide examples.

5. Describe three common collection failures and their solutions.

6. Why is data validation important before inserting metrics into the repository?

**Essay Questions:**

7. Design a comprehensive collection strategy for an organization with 500 SQL Servers across 3 data centers. Include:
   - Collection frequencies for different server tiers
   - Parallel processing strategy
   - Error handling and retry logic
   - Data validation rules
   - Health monitoring approach

8. Analyze the trade-offs between collection frequency and system overhead. How would you balance real-time monitoring needs with minimal performance impact?

**Hands-On Exercises:**

9. **Exercise 6.1: Build a Custom Collector**
   - Create a collector for SQL Agent job status
   - Collect job history for last 7 days
   - Identify failed jobs
   - Store in repository
   - Generate alerts for failures

10. **Exercise 6.2: Troubleshoot Collection Failures**
    - Simulate network timeout
    - Implement retry logic
    - Add circuit breaker pattern
    - Log all retry attempts
    - Validate solution handles 5+ consecutive failures

11. **Exercise 6.3: Optimize Collection Performance**
    - Baseline collection time for 100 servers
    - Implement batching strategy
    - Tune parallel throttle limits
    - Measure performance improvement
    - Document optimal configuration

12. **Exercise 6.4: Data Quality Validation**
    - Implement validation rules for all metrics
    - Detect and flag anomalous values
    - Create quality score (0-100)
    - Generate alerts for low quality data
    - Build quality dashboard

---

*End of Chapter 6*

**Next Chapter:** Chapter 7 - Alerting and Notification

