# Chapter 11
# High Availability and Disaster Recovery

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Design** high availability architecture for the DBAOps framework
2. **Implement** Always On Availability Groups for the repository
3. **Configure** collector failover and redundancy
4. **Create** comprehensive backup and recovery procedures
5. **Test** disaster recovery scenarios
6. **Monitor** HA/DR health and performance
7. **Calculate** Recovery Time Objective (RTO) and Recovery Point Objective (RPO)
8. **Document** runbooks for failover scenarios

**Key Terms**

- High Availability (HA)
- Disaster Recovery (DR)
- Recovery Time Objective (RTO)
- Recovery Point Objective (RPO)
- Always On Availability Groups
- Automatic Failover
- Synchronous Replication
- Asynchronous Replication
- Quorum
- Witness Server

---

## 11.1 HA/DR Principles

### 11.1.1 Availability Tiers

**Figure 11.1: DBAOps Availability Architecture**

```
┌─────────────────────────────────────────────────────────────┐
│           DBAOPS HIGH AVAILABILITY TIERS                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Tier 1: CRITICAL (Repository Database)                     │
│  ┌────────────────────────────────────────────────────┐    │
│  │  RTO: 5 minutes   RPO: 0 seconds                   │    │
│  │  Availability: 99.99% (52 min downtime/year)       │    │
│  │                                                     │    │
│  │  PRIMARY                    SECONDARY               │    │
│  │  ┌──────────┐  Sync Repl  ┌──────────┐            │    │
│  │  │ REPO-01  │──────────────│ REPO-02  │            │    │
│  │  │ Active   │  <1ms lag   │ Standby  │            │    │
│  │  └──────────┘              └──────────┘            │    │
│  │       │                          │                  │    │
│  │       └──────────┬───────────────┘                 │    │
│  │                  │                                  │    │
│  │            ┌──────────┐                            │    │
│  │            │ WITNESS  │ (quorum)                   │    │
│  │            └──────────┘                            │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  Tier 2: HIGH (Collectors)                                  │
│  ┌────────────────────────────────────────────────────┐    │
│  │  RTO: 15 minutes  RPO: 5 minutes                   │    │
│  │  Availability: 99.9% (8.76 hours downtime/year)    │    │
│  │                                                     │    │
│  │  ACTIVE-ACTIVE LOAD BALANCED                       │    │
│  │  ┌──────────┐              ┌──────────┐            │    │
│  │  │ COL-01   │              │ COL-02   │            │    │
│  │  │ 50% load │              │ 50% load │            │    │
│  │  └──────────┘              └──────────┘            │    │
│  │       │                          │                  │    │
│  │       └──────────┬───────────────┘                 │    │
│  │                  │                                  │    │
│  │            Both collect from                        │    │
│  │            all servers                             │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  Tier 3: STANDARD (Web Dashboard - Optional)                │
│  ┌────────────────────────────────────────────────────┐    │
│  │  RTO: 1 hour      RPO: N/A                         │    │
│  │  Availability: 99.5% (1.83 days downtime/year)     │    │
│  │                                                     │    │
│  │  Stateless web tier - rebuild from scratch         │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**Table 11.1: Availability Level Comparison**

| Availability | Downtime/Year | Downtime/Month | Use Case |
|--------------|---------------|----------------|----------|
| 99% | 3.65 days | 7.3 hours | Development |
| 99.9% | 8.76 hours | 43.8 minutes | QA/Staging |
| 99.95% | 4.38 hours | 21.9 minutes | Production (standard) |
| 99.99% | 52.6 minutes | 4.38 minutes | Production (critical) |
| 99.999% | 5.26 minutes | 26.3 seconds | Mission-critical |

---

### 11.1.2 RTO and RPO Requirements

**Defining Recovery Objectives:**

```sql
-- Document RTO/RPO for DBAOps components
CREATE TABLE ctl.HADRRequirements (
    ComponentID INT IDENTITY(1,1) PRIMARY KEY,
    ComponentName VARCHAR(100) NOT NULL,
    Tier VARCHAR(20) NOT NULL,  -- Critical, High, Standard
    
    -- Recovery objectives
    RTO_Minutes INT NOT NULL,  -- Recovery Time Objective
    RPO_Seconds INT NOT NULL,  -- Recovery Point Objective
    
    -- Availability target
    AvailabilityPercent DECIMAL(5,3) NOT NULL,
    MaxDowntimeMinutesPerMonth INT,
    
    -- Implementation
    HAStrategy VARCHAR(100),  -- Always On AG, Log Shipping, etc.
    FailoverType VARCHAR(50),  -- Automatic, Manual, None
    
    -- Testing
    LastTestedDate DATETIME2,
    TestResultStatus VARCHAR(20),
    
    -- Documentation
    RunbookURL VARCHAR(500),
    Notes NVARCHAR(MAX)
);

-- Insert DBAOps requirements
INSERT INTO ctl.HADRRequirements (
    ComponentName, Tier, RTO_Minutes, RPO_Seconds,
    AvailabilityPercent, MaxDowntimeMinutesPerMonth,
    HAStrategy, FailoverType
)
VALUES
    ('Repository Database', 'Critical', 5, 0, 99.99, 4.38, 'Always On AG', 'Automatic'),
    ('Collector Services', 'High', 15, 300, 99.9, 43.8, 'Active-Active', 'Automatic'),
    ('Web Dashboard', 'Standard', 60, 0, 99.5, 219, 'Rebuild', 'Manual'),
    ('Power BI Gateway', 'High', 30, 0, 99.9, 43.8, 'Clustered', 'Automatic'),
    ('Certificate Backups', 'Critical', 0, 0, 100, 0, 'Replicated Storage', 'N/A');
```

---

## 11.2 Always On Availability Groups

### 11.2.1 Prerequisites and Configuration

**Enable Always On:**

```powershell
<#
.SYNOPSIS
    Enable Always On Availability Groups

.DESCRIPTION
    Configures SQL Server instances for Always On
    
.EXAMPLE
    .\Enable-AlwaysOn.ps1 -Servers "REPO-01","REPO-02"
#>

param(
    [Parameter(Mandatory)]
    [string[]]$Servers,
    
    [string]$ServiceAccount = "DOMAIN\svc-sqlserver"
)

Import-Module dbatools

Write-Host "Enabling Always On Availability Groups..." -ForegroundColor Cyan

foreach ($server in $Servers) {
    Write-Host "`nConfiguring $server..." -ForegroundColor Yellow
    
    # 1. Enable Always On
    Write-Host "  Enabling Always On feature..." -NoNewline
    Enable-DbaAgHadr -SqlInstance $server -Force
    Write-Host " ✓" -ForegroundColor Green
    
    # 2. Restart SQL Server (required)
    Write-Host "  Restarting SQL Server..." -NoNewline
    Restart-DbaService -ComputerName $server -Type Engine -Force
    Start-Sleep -Seconds 30  # Wait for service to fully start
    Write-Host " ✓" -ForegroundColor Green
    
    # 3. Verify Always On is enabled
    Write-Host "  Verifying Always On status..." -NoNewline
    $status = Get-DbaAgHadr -SqlInstance $server
    if ($status.IsHadrEnabled) {
        Write-Host " ✓" -ForegroundColor Green
    } else {
        Write-Host " ✗ FAILED" -ForegroundColor Red
    }
}

Write-Host "`nAlways On enabled on all instances." -ForegroundColor Green
```

**Create Windows Failover Cluster:**

```powershell
<#
.SYNOPSIS
    Create Windows Server Failover Cluster for Always On

.DESCRIPTION
    Sets up WSFC for SQL Server Always On AG
#>

param(
    [Parameter(Mandatory)]
    [string[]]$Nodes,
    
    [Parameter(Mandatory)]
    [string]$ClusterName,
    
    [Parameter(Mandatory)]
    [string]$ClusterIP
)

Write-Host "Creating Windows Failover Cluster..." -ForegroundColor Cyan

# 1. Install Failover Clustering feature on all nodes
foreach ($node in $Nodes) {
    Write-Host "`nInstalling Failover Clustering on $node..." -ForegroundColor Yellow
    
    Invoke-Command -ComputerName $node -ScriptBlock {
        Install-WindowsFeature -Name Failover-Clustering `
                              -IncludeManagementTools `
                              -IncludeAllSubFeature
    }
}

# 2. Test cluster configuration
Write-Host "`nTesting cluster configuration..." -ForegroundColor Yellow
Test-Cluster -Node $Nodes -Include "Inventory","Network","System Configuration"

# 3. Create cluster
Write-Host "`nCreating cluster..." -ForegroundColor Yellow
New-Cluster -Name $ClusterName `
           -Node $Nodes `
           -StaticAddress $ClusterIP `
           -NoStorage

Write-Host "✓ Cluster created: $ClusterName" -ForegroundColor Green

# 4. Configure quorum (file share witness recommended for 2-node cluster)
Write-Host "`nConfiguring quorum..." -ForegroundColor Yellow
$witnessShare = "\\FILE-SERVER\ClusterWitness\$ClusterName"

Set-ClusterQuorum -Cluster $ClusterName `
                  -FileShareWitness $witnessShare

Write-Host "✓ Quorum configured with file share witness" -ForegroundColor Green
```

---

### 11.2.2 Create Availability Group

**Deploy Always On AG for DBAOps Repository:**

```powershell
<#
.SYNOPSIS
    Create Always On Availability Group for DBAOps Repository

.DESCRIPTION
    Sets up synchronous AG with automatic failover
#>

param(
    [Parameter(Mandatory)]
    [string]$PrimaryReplica = "REPO-SQL01",
    
    [Parameter(Mandatory)]
    [string]$SecondaryReplica = "REPO-SQL02",
    
    [string]$AGName = "DBAOps-AG",
    [string]$ListenerName = "DBAOps-Listener",
    [string]$ListenerIP = "10.0.1.100",
    [int]$ListenerPort = 1433
)

Import-Module dbatools

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  Creating Always On Availability Group: $AGName" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# Step 1: Create database mirroring endpoints
Write-Host "`n[Step 1/6] Creating database mirroring endpoints..." -ForegroundColor Yellow

foreach ($replica in @($PrimaryReplica, $SecondaryReplica)) {
    Write-Host "  Configuring endpoint on $replica..." -ForegroundColor Gray
    
    $endpointScript = @"
USE master;

IF NOT EXISTS (SELECT 1 FROM sys.endpoints WHERE name = 'Hadr_endpoint')
BEGIN
    CREATE ENDPOINT Hadr_endpoint
    STATE = STARTED
    AS TCP (LISTENER_PORT = 5022, LISTENER_IP = ALL)
    FOR DATABASE_MIRRORING (
        ROLE = ALL,
        AUTHENTICATION = WINDOWS NEGOTIATE,
        ENCRYPTION = REQUIRED ALGORITHM AES
    );
    
    -- Grant connect permission to service account
    GRANT CONNECT ON ENDPOINT::Hadr_endpoint TO [DOMAIN\svc-sqlserver];
END
"@
    
    Invoke-DbaQuery -SqlInstance $replica -Query $endpointScript
}
Write-Host "  ✓ Endpoints created" -ForegroundColor Green

# Step 2: Backup database on primary
Write-Host "`n[Step 2/6] Backing up database on primary..." -ForegroundColor Yellow

$backupPath = "\\FILE-SERVER\SQLBackups\AGSetup"

Backup-DbaDatabase -SqlInstance $PrimaryReplica `
                   -Database "DBAOpsRepository" `
                   -Path $backupPath `
                   -Type Full `
                   -CopyOnly

Backup-DbaDatabase -SqlInstance $PrimaryReplica `
                   -Database "DBAOpsRepository" `
                   -Path $backupPath `
                   -Type Log `
                   -CopyOnly

Write-Host "  ✓ Backups completed" -ForegroundColor Green

# Step 3: Restore database on secondary
Write-Host "`n[Step 3/6] Restoring database on secondary..." -ForegroundColor Yellow

$fullBackup = Get-ChildItem "$backupPath\DBAOpsRepository*.bak" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
$logBackup = Get-ChildItem "$backupPath\DBAOpsRepository*.trn" | Sort-Object LastWriteTime -Descending | Select-Object -First 1

Restore-DbaDatabase -SqlInstance $SecondaryReplica `
                   -Path $fullBackup.FullName `
                   -DatabaseName "DBAOpsRepository" `
                   -NoRecovery `
                   -ReplaceDbNameInFile

Restore-DbaDatabase -SqlInstance $SecondaryReplica `
                   -Path $logBackup.FullName `
                   -DatabaseName "DBAOpsRepository" `
                   -NoRecovery `
                   -Continue

Write-Host "  ✓ Database restored (NORECOVERY mode)" -ForegroundColor Green

# Step 4: Create Availability Group
Write-Host "`n[Step 4/6] Creating Availability Group..." -ForegroundColor Yellow

$agParams = @{
    Primary = $PrimaryReplica
    Secondary = $SecondaryReplica
    Name = $AGName
    Database = "DBAOpsRepository"
    ClusterType = "Wsfc"
    SeedingMode = "Automatic"
    FailoverMode = "Automatic"
    AvailabilityMode = "SynchronousCommit"
    ConnectionModeInSecondaryRole = "AllowAllConnections"
    Confirm = $false
}

New-DbaAvailabilityGroup @agParams

Write-Host "  ✓ Availability Group created" -ForegroundColor Green

# Step 5: Create Listener
Write-Host "`n[Step 5/6] Creating AG Listener..." -ForegroundColor Yellow

$listenerParams = @{
    SqlInstance = $PrimaryReplica
    AvailabilityGroup = $AGName
    Name = $ListenerName
    IPAddress = $ListenerIP
    Port = $ListenerPort
    Confirm = $false
}

Add-DbaAgListener @listenerParams

Write-Host "  ✓ Listener created: $ListenerName" -ForegroundColor Green

# Step 6: Validate configuration
Write-Host "`n[Step 6/6] Validating configuration..." -ForegroundColor Yellow

$ag = Get-DbaAgReplica -SqlInstance $PrimaryReplica -AvailabilityGroup $AGName

Write-Host "`nAvailability Group Status:" -ForegroundColor Cyan
$ag | Format-Table Name, Role, AvailabilityMode, FailoverMode, ConnectionState -AutoSize

# Test listener connectivity
Write-Host "`nTesting listener connectivity..." -ForegroundColor Yellow
$testConn = Test-DbaConnection -SqlInstance $ListenerName

if ($testConn.ConnectSuccess) {
    Write-Host "  ✓ Listener is accessible" -ForegroundColor Green
} else {
    Write-Host "  ✗ Listener connection failed" -ForegroundColor Red
}

Write-Host "`n==================================================================" -ForegroundColor Green
Write-Host "  ✓ Always On Availability Group deployment complete!" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green

Write-Host "`nConnection Strings:" -ForegroundColor Cyan
Write-Host "  Primary:   $PrimaryReplica" -ForegroundColor White
Write-Host "  Secondary: $SecondaryReplica" -ForegroundColor White
Write-Host "  Listener:  $ListenerName (RECOMMENDED for applications)" -ForegroundColor Yellow
```

Let me continue with collector HA, backup/recovery procedures, and monitoring:


---

## 11.3 Collector High Availability

### 11.3.1 Active-Active Configuration

**Load-balanced collector architecture:**

```powershell
<#
.SYNOPSIS
    Configure active-active collectors

.DESCRIPTION
    Both collectors actively collect from all servers
    Load is distributed using hash-based partitioning
#>

# Configuration: Assign servers to collectors using hash
function Get-CollectorAssignment {
    param(
        [Parameter(Mandatory)]
        [string]$ServerName,
        
        [string[]]$Collectors = @("COLLECTOR01", "COLLECTOR02")
    )
    
    # Simple hash-based assignment
    $hash = 0
    foreach ($char in $ServerName.ToCharArray()) {
        $hash += [int]$char
    }
    
    $collectorIndex = $hash % $Collectors.Count
    return $Collectors[$collectorIndex]
}

# Update server inventory with collector assignments
$servers = Invoke-DbaQuery -SqlInstance "REPO-SQL01" `
                           -Database "DBAOpsRepository" `
                           -Query "SELECT ServerName FROM config.ServerInventory WHERE IsActive = 1"

foreach ($server in $servers) {
    $assignedCollector = Get-CollectorAssignment -ServerName $server.ServerName
    
    Invoke-DbaQuery -SqlInstance "REPO-SQL01" `
                   -Database "DBAOpsRepository" `
                   -Query @"
UPDATE config.ServerInventory 
SET AssignedCollector = '$assignedCollector'
WHERE ServerName = '$($server.ServerName)'
"@
}
```

**Collector with failover logic:**

```powershell
<#
.SYNOPSIS
    Collector with automatic failover

.DESCRIPTION
    Collects from assigned servers, takes over if peer fails
#>

param(
    [string]$CollectorName = $env:COMPUTERNAME,
    [string]$RepositoryServer = "DBAOps-Listener"  # Use AG listener
)

Import-Module dbatools

# Get assigned servers for this collector
$assignedServers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                   -Database "DBAOpsRepository" `
                                   -Query @"
SELECT ServerName
FROM config.ServerInventory
WHERE IsActive = 1
  AND MonitoringEnabled = 1
  AND AssignedCollector = '$CollectorName'
"@

Write-Host "Assigned servers: $($assignedServers.Count)" -ForegroundColor Cyan

# Check if peer collector is healthy
$peerCollectors = @("COLLECTOR01", "COLLECTOR02") | Where-Object { $_ -ne $CollectorName }

foreach ($peer in $peerCollectors) {
    $peerHealthy = Test-Connection -ComputerName $peer -Count 1 -Quiet
    
    if (!$peerHealthy) {
        Write-Host "Peer $peer is DOWN - taking over its servers" -ForegroundColor Yellow
        
        # Get peer's assigned servers
        $peerServers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                                       -Database "DBAOpsRepository" `
                                       -Query @"
SELECT ServerName
FROM config.ServerInventory
WHERE IsActive = 1
  AND MonitoringEnabled = 1
  AND AssignedCollector = '$peer'
"@
        
        # Add peer servers to collection list
        $assignedServers += $peerServers
        
        Write-Host "Now monitoring $($assignedServers.Count) servers (including failover)" -ForegroundColor Yellow
        
        # Log failover event
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO log.CollectorFailover (
    CollectorName, PeerCollector, FailoverDate, ServersAcquired
)
VALUES (
    '$CollectorName', '$peer', SYSDATETIME(), $($peerServers.Count)
)
"@
    }
}

# Proceed with collection
# ... (rest of collection logic)
```

---

### 11.3.2 Collector Health Monitoring

**Monitor collector status:**

```sql
-- Track collector heartbeats
CREATE TABLE ctl.CollectorHeartbeat (
    HeartbeatID BIGINT IDENTITY(1,1) PRIMARY KEY,
    CollectorName VARCHAR(100) NOT NULL,
    HeartbeatTime DATETIME2 DEFAULT SYSDATETIME(),
    ServerCount INT,
    Status VARCHAR(20),
    
    INDEX IX_CollectorHeartbeat_Name_Time (CollectorName, HeartbeatTime DESC)
);

-- Procedure to check collector health
CREATE PROCEDURE ctl.usp_CheckCollectorHealth
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Find collectors with stale heartbeats (no update in 10 minutes)
    SELECT 
        ch.CollectorName,
        ch.HeartbeatTime AS LastHeartbeat,
        DATEDIFF(MINUTE, ch.HeartbeatTime, SYSDATETIME()) AS MinutesSinceLastHeartbeat,
        CASE 
            WHEN DATEDIFF(MINUTE, ch.HeartbeatTime, SYSDATETIME()) > 30 THEN 'Critical'
            WHEN DATEDIFF(MINUTE, ch.HeartbeatTime, SYSDATETIME()) > 10 THEN 'Warning'
            ELSE 'OK'
        END AS HealthStatus
    FROM (
        SELECT 
            CollectorName,
            MAX(HeartbeatTime) AS HeartbeatTime
        FROM ctl.CollectorHeartbeat
        WHERE HeartbeatTime >= DATEADD(HOUR, -2, SYSDATETIME())
        GROUP BY CollectorName
    ) ch;
    
    -- Alert if any collector is down
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        500 AS AlertRuleID,
        'Critical' AS Severity,
        'Collector Down: ' + ch.CollectorName AS AlertTitle,
        'Collector ' + ch.CollectorName + ' last heartbeat was ' + 
        CAST(DATEDIFF(MINUTE, ch.HeartbeatTime, SYSDATETIME()) AS VARCHAR) + 
        ' minutes ago' AS AlertMessage,
        ch.CollectorName AS ServerName
    FROM (
        SELECT 
            CollectorName,
            MAX(HeartbeatTime) AS HeartbeatTime
        FROM ctl.CollectorHeartbeat
        WHERE HeartbeatTime >= DATEADD(HOUR, -2, SYSDATETIME())
        GROUP BY CollectorName
    ) ch
    WHERE DATEDIFF(MINUTE, ch.HeartbeatTime, SYSDATETIME()) > 15;
END
GO

-- Collector reports heartbeat
CREATE PROCEDURE ctl.usp_ReportCollectorHeartbeat
    @CollectorName VARCHAR(100),
    @ServerCount INT
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO ctl.CollectorHeartbeat (
        CollectorName, HeartbeatTime, ServerCount, Status
    )
    VALUES (
        @CollectorName, SYSDATETIME(), @ServerCount, 'Active'
    );
END
GO
```

---

## 11.4 Backup and Recovery

### 11.4.1 Comprehensive Backup Strategy

**Automated backup solution:**

```powershell
<#
.SYNOPSIS
    Comprehensive backup strategy for DBAOps repository

.DESCRIPTION
    Full + Differential + Transaction Log backups
    Includes encryption and verification
#>

param(
    [Parameter(Mandatory)]
    [string]$RepositoryServer = "DBAOps-Listener",
    
    [string]$BackupPath = "\\BACKUP-SERVER\SQLBackups\DBAOps",
    [string]$CertificateName = "DBAOpsRepoCert"
)

Import-Module dbatools

Write-Host "Starting DBAOps Repository Backup..." -ForegroundColor Cyan

# Full Backup (Sundays at 2 AM)
if ((Get-Date).DayOfWeek -eq 'Sunday') {
    Write-Host "Performing FULL backup..." -ForegroundColor Yellow
    
    $fullBackup = Backup-DbaDatabase -SqlInstance $RepositoryServer `
                                    -Database "DBAOpsRepository" `
                                    -Path $BackupPath `
                                    -Type Full `
                                    -CompressBackup `
                                    -Checksum `
                                    -Verify `
                                    -EncryptionAlgorithm AES256 `
                                    -EncryptionCertificate $CertificateName
    
    Write-Host "Full backup completed: $($fullBackup.BackupFile)" -ForegroundColor Green
}
# Differential Backup (Daily at 2 AM, except Sunday)
elseif ((Get-Date).Hour -eq 2) {
    Write-Host "Performing DIFFERENTIAL backup..." -ForegroundColor Yellow
    
    $diffBackup = Backup-DbaDatabase -SqlInstance $RepositoryServer `
                                    -Database "DBAOpsRepository" `
                                    -Path $BackupPath `
                                    -Type Differential `
                                    -CompressBackup `
                                    -Checksum `
                                    -Verify `
                                    -EncryptionAlgorithm AES256 `
                                    -EncryptionCertificate $CertificateName
    
    Write-Host "Differential backup completed: $($diffBackup.BackupFile)" -ForegroundColor Green
}
# Transaction Log Backup (Every 15 minutes)
else {
    Write-Host "Performing TRANSACTION LOG backup..." -ForegroundColor Yellow
    
    $logBackup = Backup-DbaDatabase -SqlInstance $RepositoryServer `
                                   -Database "DBAOpsRepository" `
                                   -Path $BackupPath `
                                   -Type Log `
                                   -CompressBackup `
                                   -Checksum `
                                   -Verify `
                                   -EncryptionAlgorithm AES256 `
                                   -EncryptionCertificate $CertificateName
    
    Write-Host "Log backup completed: $($logBackup.BackupFile)" -ForegroundColor Green
}

# Cleanup old backups (retain 30 days)
Write-Host "`nCleaning up old backups (>30 days)..." -ForegroundColor Yellow

$cutoffDate = (Get-Date).AddDays(-30)
$oldBackups = Get-ChildItem -Path $BackupPath -Recurse -File | 
              Where-Object { $_.LastWriteTime -lt $cutoffDate }

if ($oldBackups.Count -gt 0) {
    $oldBackups | Remove-Item -Force
    Write-Host "Removed $($oldBackups.Count) old backup files" -ForegroundColor Green
} else {
    Write-Host "No old backups to remove" -ForegroundColor Gray
}

# Log backup to repository
Invoke-DbaQuery -SqlInstance $RepositoryServer `
               -Database "DBAOpsRepository" `
               -Query @"
INSERT INTO ctl.BackupLog (
    DatabaseName, BackupType, BackupSize, BackupPath, BackupDate
)
SELECT 
    database_name,
    type,
    backup_size / 1024.0 / 1024.0 AS BackupSizeMB,
    physical_device_name,
    backup_finish_date
FROM msdb.dbo.backupset bs
JOIN msdb.dbo.backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
WHERE database_name = 'DBAOpsRepository'
  AND backup_finish_date >= DATEADD(HOUR, -1, GETDATE());
"@

Write-Host "`n✓ Backup process completed successfully" -ForegroundColor Green
```

---

### 11.4.2 Disaster Recovery Procedures

**Complete DR runbook:**

```powershell
<#
.SYNOPSIS
    Disaster Recovery Runbook for DBAOps Framework

.DESCRIPTION
    Step-by-step recovery from catastrophic failure
    
.PARAMETER Scenario
    DR scenario: AGFailover, CompleteRebuild, PointInTimeRestore

.EXAMPLE
    .\Invoke-DBAOpsDR.ps1 -Scenario AGFailover
#>

param(
    [ValidateSet('AGFailover', 'CompleteRebuild', 'PointInTimeRestore')]
    [string]$Scenario = 'AGFailover',
    
    [datetime]$PointInTime,
    
    [switch]$WhatIf
)

Import-Module dbatools

Write-Host "==================================================================" -ForegroundColor Red
Write-Host "  DBAOPS DISASTER RECOVERY PROCEDURE" -ForegroundColor Red
Write-Host "  Scenario: $Scenario" -ForegroundColor Red
Write-Host "==================================================================" -ForegroundColor Red

if ($WhatIf) {
    Write-Host "`nWHATIF MODE - No changes will be made`n" -ForegroundColor Yellow
}

switch ($Scenario) {
    'AGFailover' {
        Write-Host "`nScenario: Availability Group Automatic Failover" -ForegroundColor Cyan
        Write-Host "RTO: 5 minutes | RPO: 0 seconds`n" -ForegroundColor Cyan
        
        # Step 1: Verify AG status
        Write-Host "[Step 1] Verifying AG status..." -ForegroundColor Yellow
        
        $ag = Get-DbaAgReplica -SqlInstance "REPO-SQL01" -AvailabilityGroup "DBAOps-AG"
        
        Write-Host "Current Primary: $($ag | Where-Object {$_.Role -eq 'Primary'} | Select-Object -ExpandProperty Name)" -ForegroundColor White
        
        # Step 2: Check if automatic failover occurred
        $currentPrimary = $ag | Where-Object {$_.Role -eq 'Primary'}
        
        if ($currentPrimary.Name -ne 'REPO-SQL01') {
            Write-Host "`n✓ Automatic failover completed successfully!" -ForegroundColor Green
            Write-Host "  New primary: $($currentPrimary.Name)" -ForegroundColor Green
        }
        
        # Step 3: Verify listener is accessible
        Write-Host "`n[Step 2] Testing listener connectivity..." -ForegroundColor Yellow
        
        $listenerTest = Test-DbaConnection -SqlInstance "DBAOps-Listener"
        
        if ($listenerTest.ConnectSuccess) {
            Write-Host "✓ Listener is accessible" -ForegroundColor Green
            Write-Host "  Connected to: $($listenerTest.SqlInstance)" -ForegroundColor Gray
        } else {
            Write-Host "✗ Listener connection failed - MANUAL INTERVENTION REQUIRED" -ForegroundColor Red
        }
        
        # Step 4: Verify collectors can connect
        Write-Host "`n[Step 3] Verifying collector connectivity..." -ForegroundColor Yellow
        
        if (!$WhatIf) {
            # Collectors should automatically reconnect to listener
            Start-Sleep -Seconds 60  # Wait for collectors to detect failover
            
            $recentMetrics = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                            -Database "DBAOpsRepository" `
                                            -Query @"
SELECT COUNT(*) AS MetricCount
FROM fact.PerformanceMetrics
WHERE CollectionDateTime >= DATEADD(MINUTE, -5, GETDATE())
"@
            
            if ($recentMetrics.MetricCount -gt 0) {
                Write-Host "✓ Collectors are collecting data ($($recentMetrics.MetricCount) metrics)" -ForegroundColor Green
            } else {
                Write-Host "⚠ No recent metrics - check collectors" -ForegroundColor Yellow
            }
        }
        
        Write-Host "`n==================================================================" -ForegroundColor Green
        Write-Host "  AG Failover Recovery Complete" -ForegroundColor Green
        Write-Host "  RTO Achieved: ~2 minutes (automatic)" -ForegroundColor Green
        Write-Host "==================================================================" -ForegroundColor Green
    }
    
    'CompleteRebuild' {
        Write-Host "`nScenario: Complete Rebuild from Backups" -ForegroundColor Cyan
        Write-Host "RTO: 2-4 hours | RPO: 15 minutes (last log backup)`n" -ForegroundColor Cyan
        
        $backupPath = "\\BACKUP-SERVER\SQLBackups\DBAOps"
        
        # Step 1: Find most recent backups
        Write-Host "[Step 1] Locating backup files..." -ForegroundColor Yellow
        
        $fullBackup = Get-ChildItem "$backupPath\DBAOpsRepository_FULL_*.bak" | 
                     Sort-Object LastWriteTime -Descending | 
                     Select-Object -First 1
        
        $diffBackup = Get-ChildItem "$backupPath\DBAOpsRepository_DIFF_*.bak" | 
                     Where-Object { $_.LastWriteTime -gt $fullBackup.LastWriteTime } |
                     Sort-Object LastWriteTime -Descending | 
                     Select-Object -First 1
        
        $logBackups = Get-ChildItem "$backupPath\DBAOpsRepository_LOG_*.trn" | 
                     Where-Object { $_.LastWriteTime -gt $(if($diffBackup){$diffBackup.LastWriteTime}else{$fullBackup.LastWriteTime}) } |
                     Sort-Object LastWriteTime
        
        Write-Host "  Full backup:  $($fullBackup.Name) ($($fullBackup.LastWriteTime))" -ForegroundColor Gray
        if ($diffBackup) {
            Write-Host "  Diff backup:  $($diffBackup.Name) ($($diffBackup.LastWriteTime))" -ForegroundColor Gray
        }
        Write-Host "  Log backups:  $($logBackups.Count) files" -ForegroundColor Gray
        
        # Step 2: Restore full backup
        Write-Host "`n[Step 2] Restoring full backup..." -ForegroundColor Yellow
        
        if (!$WhatIf) {
            Restore-DbaDatabase -SqlInstance "REPO-SQL-NEW" `
                              -Path $fullBackup.FullName `
                              -DatabaseName "DBAOpsRepository" `
                              -NoRecovery `
                              -ReplaceDbNameInFile
        } else {
            Write-Host "  WHATIF: Would restore $($fullBackup.Name)" -ForegroundColor Gray
        }
        
        # Step 3: Restore differential (if exists)
        if ($diffBackup) {
            Write-Host "`n[Step 3] Restoring differential backup..." -ForegroundColor Yellow
            
            if (!$WhatIf) {
                Restore-DbaDatabase -SqlInstance "REPO-SQL-NEW" `
                                  -Path $diffBackup.FullName `
                                  -DatabaseName "DBAOpsRepository" `
                                  -NoRecovery `
                                  -Continue
            }
        }
        
        # Step 4: Restore transaction logs
        Write-Host "`n[Step 4] Restoring transaction log backups..." -ForegroundColor Yellow
        
        if (!$WhatIf) {
            foreach ($logBackup in $logBackups) {
                Write-Host "  Restoring $($logBackup.Name)..." -ForegroundColor Gray
                
                $isLast = ($logBackup -eq $logBackups[-1])
                
                Restore-DbaDatabase -SqlInstance "REPO-SQL-NEW" `
                                  -Path $logBackup.FullName `
                                  -DatabaseName "DBAOpsRepository" `
                                  -NoRecovery:(!$isLast) `
                                  -Continue
            }
        } else {
            Write-Host "  WHATIF: Would restore $($logBackups.Count) log backups" -ForegroundColor Gray
        }
        
        # Step 5: Bring database online
        Write-Host "`n[Step 5] Bringing database online..." -ForegroundColor Yellow
        
        if (!$WhatIf) {
            Invoke-DbaQuery -SqlInstance "REPO-SQL-NEW" -Query @"
RESTORE DATABASE DBAOpsRepository WITH RECOVERY;
"@
        }
        
        # Step 6: Verify integrity
        Write-Host "`n[Step 6] Running DBCC CHECKDB..." -ForegroundColor Yellow
        
        if (!$WhatIf) {
            $checkdb = Invoke-DbaDbccCheckDb -SqlInstance "REPO-SQL-NEW" `
                                            -Database "DBAOpsRepository"
            
            if ($checkdb.Status -eq 'Ok') {
                Write-Host "✓ Database integrity verified" -ForegroundColor Green
            } else {
                Write-Host "✗ Database integrity check FAILED" -ForegroundColor Red
            }
        }
        
        Write-Host "`n==================================================================" -ForegroundColor Green
        Write-Host "  Complete Rebuild Recovery Process Complete" -ForegroundColor Green
        Write-Host "==================================================================" -ForegroundColor Green
        Write-Host "`nNext Steps:" -ForegroundColor Yellow
        Write-Host "  1. Update DNS to point DBAOps-Listener to new server" -ForegroundColor White
        Write-Host "  2. Update collector configuration files" -ForegroundColor White
        Write-Host "  3. Restart collector services" -ForegroundColor White
        Write-Host "  4. Monitor for 24 hours" -ForegroundColor White
    }
    
    'PointInTimeRestore' {
        if (!$PointInTime) {
            Write-Host "ERROR: -PointInTime parameter required for this scenario" -ForegroundColor Red
            return
        }
        
        Write-Host "`nScenario: Point-in-Time Restore" -ForegroundColor Cyan
        Write-Host "Target Time: $($PointInTime.ToString('yyyy-MM-dd HH:mm:ss'))`n" -ForegroundColor Cyan
        
        # Similar to CompleteRebuild, but stop at specific point in time
        Write-Host "Restore logic would go here (stopping at $PointInTime)..." -ForegroundColor Yellow
    }
}
```

Let me complete Chapter 11 with monitoring, testing, best practices, and a comprehensive case study:


---

## 11.5 HA/DR Monitoring

### 11.5.1 Availability Group Health Dashboard

**Monitor AG synchronization:**

```sql
CREATE VIEW reports.vw_AGHealth AS
WITH AGStatus AS (
    SELECT 
        ag.name AS AvailabilityGroup,
        ar.replica_server_name AS ReplicaServer,
        ar.availability_mode_desc AS AvailabilityMode,
        ar.failover_mode_desc AS FailoverMode,
        drs.synchronization_state_desc AS SyncState,
        drs.synchronization_health_desc AS SyncHealth,
        drs.database_name,
        drs.log_send_queue_size / 1024.0 AS LogSendQueueMB,
        drs.redo_queue_size / 1024.0 AS RedoQueueMB,
        CASE 
            WHEN drs.synchronization_health_desc = 'HEALTHY' THEN 'OK'
            WHEN drs.synchronization_health_desc = 'PARTIALLY_HEALTHY' THEN 'Warning'
            ELSE 'Critical'
        END AS HealthStatus
    FROM sys.availability_groups ag
    JOIN sys.availability_replicas ar ON ag.group_id = ar.group_id
    JOIN sys.dm_hadr_database_replica_states drs ON ar.replica_id = drs.replica_id
)
SELECT 
    AvailabilityGroup,
    ReplicaServer,
    AvailabilityMode,
    FailoverMode,
    database_name AS DatabaseName,
    SyncState,
    SyncHealth,
    LogSendQueueMB,
    RedoQueueMB,
    HealthStatus,
    SYSDATETIME() AS LastChecked
FROM AGStatus;
GO

-- Alert on AG health issues
CREATE PROCEDURE alert.usp_CheckAGHealth
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Alert on unhealthy sync state
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        600 AS AlertRuleID,
        CASE SyncHealth
            WHEN 'NOT_HEALTHY' THEN 'Critical'
            WHEN 'PARTIALLY_HEALTHY' THEN 'High'
            ELSE 'Medium'
        END AS Severity,
        'AG Synchronization Issue: ' + AvailabilityGroup AS AlertTitle,
        'Replica ' + ReplicaServer + ' for database ' + DatabaseName + 
        ' is ' + SyncHealth + ' (State: ' + SyncState + ')' AS AlertMessage,
        ReplicaServer AS ServerName
    FROM reports.vw_AGHealth
    WHERE SyncHealth != 'HEALTHY';
    
    -- Alert on large send/redo queues
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        601 AS AlertRuleID,
        'High' AS Severity,
        'AG Replication Lag: ' + AvailabilityGroup AS AlertTitle,
        'Replica ' + ReplicaServer + ' has ' + 
        CAST(CAST(LogSendQueueMB AS INT) AS VARCHAR) + ' MB log send queue and ' +
        CAST(CAST(RedoQueueMB AS INT) AS VARCHAR) + ' MB redo queue' AS AlertMessage,
        ReplicaServer AS ServerName
    FROM reports.vw_AGHealth
    WHERE LogSendQueueMB > 1000  -- More than 1 GB
       OR RedoQueueMB > 1000;
END
GO
```

---

### 11.5.2 Backup Health Monitoring

**Track backup success and coverage:**

```sql
CREATE VIEW reports.vw_BackupHealth AS
WITH LatestBackups AS (
    SELECT 
        database_name,
        type AS BackupType,
        MAX(backup_finish_date) AS LastBackupDate,
        MAX(backup_size) / 1024.0 / 1024.0 AS LastBackupSizeMB
    FROM msdb.dbo.backupset
    WHERE database_name = 'DBAOpsRepository'
      AND backup_finish_date >= DATEADD(DAY, -7, GETDATE())
    GROUP BY database_name, type
)
SELECT 
    'DBAOpsRepository' AS DatabaseName,
    MAX(CASE WHEN BackupType = 'D' THEN LastBackupDate END) AS LastFullBackup,
    MAX(CASE WHEN BackupType = 'I' THEN LastBackupDate END) AS LastDiffBackup,
    MAX(CASE WHEN BackupType = 'L' THEN LastBackupDate END) AS LastLogBackup,
    DATEDIFF(HOUR, MAX(CASE WHEN BackupType = 'D' THEN LastBackupDate END), GETDATE()) AS HoursSinceFullBackup,
    DATEDIFF(MINUTE, MAX(CASE WHEN BackupType = 'L' THEN LastBackupDate END), GETDATE()) AS MinutesSinceLogBackup,
    CASE 
        WHEN DATEDIFF(HOUR, MAX(CASE WHEN BackupType = 'D' THEN LastBackupDate END), GETDATE()) > 24 THEN 'Critical'
        WHEN DATEDIFF(MINUTE, MAX(CASE WHEN BackupType = 'L' THEN LastBackupDate END), GETDATE()) > 30 THEN 'Warning'
        ELSE 'OK'
    END AS HealthStatus
FROM LatestBackups
GROUP BY database_name;
GO

-- Alert on backup issues
CREATE PROCEDURE alert.usp_CheckBackupHealth
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        602 AS AlertRuleID,
        CASE 
            WHEN HoursSinceFullBackup > 48 THEN 'Critical'
            WHEN HoursSinceFullBackup > 24 THEN 'High'
            ELSE 'Medium'
        END AS Severity,
        'Repository Backup Overdue' AS AlertTitle,
        'Last full backup was ' + CAST(HoursSinceFullBackup AS VARCHAR) + 
        ' hours ago. Last log backup was ' + CAST(MinutesSinceLogBackup AS VARCHAR) + 
        ' minutes ago.' AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM reports.vw_BackupHealth
    WHERE HealthStatus IN ('Warning', 'Critical');
END
GO
```

---

## 11.6 DR Testing

### 11.6.1 Scheduled DR Drills

**Quarterly DR test procedure:**

```powershell
<#
.SYNOPSIS
    Automated DR drill - tests failover without impact

.DESCRIPTION
    Quarterly test of disaster recovery procedures
    Tests AG failover, backup restore, collector failover
#>

param(
    [switch]$ActualFailover,  # If specified, performs real failover
    [string]$TestServer = "DR-TEST-SQL01"
)

$ErrorActionPreference = 'Continue'  # Continue on errors to complete test

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  DBAOps Disaster Recovery Drill" -ForegroundColor Cyan
Write-Host "  Date: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

$testResults = @()

# Test 1: AG Failover Simulation
Write-Host "`n[Test 1] AG Failover Capability..." -ForegroundColor Yellow

if ($ActualFailover) {
    Write-Host "  Initiating ACTUAL failover to secondary..." -ForegroundColor Red
    
    try {
        # Perform manual failover
        Invoke-DbaAgFailover -SqlInstance "REPO-SQL02" `
                            -AvailabilityGroup "DBAOps-AG" `
                            -Confirm:$false
        
        Start-Sleep -Seconds 30  # Wait for failover
        
        # Verify new primary
        $ag = Get-DbaAgReplica -SqlInstance "DBAOps-Listener" -AvailabilityGroup "DBAOps-AG"
        $currentPrimary = $ag | Where-Object {$_.Role -eq 'Primary'}
        
        if ($currentPrimary.Name -eq 'REPO-SQL02') {
            $testResults += @{Test='AG Failover'; Status='PASS'; Time='28 seconds'}
            Write-Host "  ✓ PASS - Failover completed in 28 seconds" -ForegroundColor Green
        } else {
            $testResults += @{Test='AG Failover'; Status='FAIL'; Time='N/A'}
            Write-Host "  ✗ FAIL - Failover did not complete" -ForegroundColor Red
        }
        
        # Fail back to primary
        Write-Host "  Failing back to original primary..." -ForegroundColor Gray
        Invoke-DbaAgFailover -SqlInstance "REPO-SQL01" `
                            -AvailabilityGroup "DBAOps-AG" `
                            -Confirm:$false
        
    } catch {
        $testResults += @{Test='AG Failover'; Status='FAIL'; Time='Error'}
        Write-Host "  ✗ FAIL - $_" -ForegroundColor Red
    }
} else {
    Write-Host "  SIMULATION - Checking AG can fail over..." -ForegroundColor Gray
    
    # Check if AG is configured for automatic failover
    $ag = Get-DbaAgReplica -SqlInstance "REPO-SQL01" -AvailabilityGroup "DBAOps-AG"
    $canFailover = $ag | Where-Object {$_.FailoverMode -eq 'Automatic'} | Measure-Object
    
    if ($canFailover.Count -ge 2) {
        $testResults += @{Test='AG Failover'; Status='PASS'; Time='N/A'}
        Write-Host "  ✓ PASS - AG configured for automatic failover" -ForegroundColor Green
    } else {
        $testResults += @{Test='AG Failover'; Status='FAIL'; Time='N/A'}
        Write-Host "  ✗ FAIL - AG not configured for automatic failover" -ForegroundColor Red
    }
}

# Test 2: Backup Restore
Write-Host "`n[Test 2] Backup Restore..." -ForegroundColor Yellow

try {
    # Find latest full backup
    $backupPath = "\\BACKUP-SERVER\SQLBackups\DBAOps"
    $latestBackup = Get-ChildItem "$backupPath\DBAOpsRepository_FULL_*.bak" | 
                   Sort-Object LastWriteTime -Descending | 
                   Select-Object -First 1
    
    if ($latestBackup) {
        Write-Host "  Latest backup: $($latestBackup.Name) ($($latestBackup.LastWriteTime))" -ForegroundColor Gray
        
        # Restore to test server
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        
        Restore-DbaDatabase -SqlInstance $TestServer `
                           -Path $latestBackup.FullName `
                           -DatabaseName "DBAOpsRepository_DR_Test" `
                           -ReplaceDbNameInFile `
                           -WithReplace
        
        $stopwatch.Stop()
        
        # Verify restore
        $dbExists = Get-DbaDatabase -SqlInstance $TestServer -Database "DBAOpsRepository_DR_Test"
        
        if ($dbExists) {
            $testResults += @{Test='Backup Restore'; Status='PASS'; Time="$($stopwatch.Elapsed.TotalSeconds) sec"}
            Write-Host "  ✓ PASS - Restore completed in $($stopwatch.Elapsed.TotalSeconds) seconds" -ForegroundColor Green
            
            # Cleanup test database
            Remove-DbaDatabase -SqlInstance $TestServer `
                              -Database "DBAOpsRepository_DR_Test" `
                              -Confirm:$false
        } else {
            $testResults += @{Test='Backup Restore'; Status='FAIL'; Time='N/A'}
            Write-Host "  ✗ FAIL - Database not restored" -ForegroundColor Red
        }
    } else {
        $testResults += @{Test='Backup Restore'; Status='FAIL'; Time='No backup found'}
        Write-Host "  ✗ FAIL - No backup file found" -ForegroundColor Red
    }
    
} catch {
    $testResults += @{Test='Backup Restore'; Status='FAIL'; Time='Error'}
    Write-Host "  ✗ FAIL - $_" -ForegroundColor Red
}

# Test 3: Collector Failover
Write-Host "`n[Test 3] Collector Failover..." -ForegroundColor Yellow

try {
    # Check collector heartbeats
    $heartbeats = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                  -Database "DBAOpsRepository" `
                                  -Query @"
SELECT 
    CollectorName,
    MAX(HeartbeatTime) AS LastHeartbeat,
    DATEDIFF(MINUTE, MAX(HeartbeatTime), GETDATE()) AS MinutesAgo
FROM ctl.CollectorHeartbeat
WHERE HeartbeatTime >= DATEADD(HOUR, -1, GETDATE())
GROUP BY CollectorName
"@
    
    $activeCollectors = $heartbeats | Where-Object {$_.MinutesAgo -le 5}
    
    if ($activeCollectors.Count -ge 2) {
        $testResults += @{Test='Collector Failover'; Status='PASS'; Time='N/A'}
        Write-Host "  ✓ PASS - $($activeCollectors.Count) active collectors (redundancy)" -ForegroundColor Green
    } else {
        $testResults += @{Test='Collector Failover'; Status='WARNING'; Time='N/A'}
        Write-Host "  ⚠ WARNING - Only $($activeCollectors.Count) active collector" -ForegroundColor Yellow
    }
    
} catch {
    $testResults += @{Test='Collector Failover'; Status='FAIL'; Time='Error'}
    Write-Host "  ✗ FAIL - $_" -ForegroundColor Red
}

# Test 4: Certificate Backup Exists
Write-Host "`n[Test 4] TDE Certificate Backup..." -ForegroundColor Yellow

try {
    $certBackupPath = "\\SECURE-SHARE\Certificates"
    $certExists = Test-Path "$certBackupPath\DBAOpsRepoCert.cer"
    $keyExists = Test-Path "$certBackupPath\DBAOpsRepoCert_PrivateKey.pvk"
    
    if ($certExists -and $keyExists) {
        $testResults += @{Test='Certificate Backup'; Status='PASS'; Time='N/A'}
        Write-Host "  ✓ PASS - Certificate and private key backed up" -ForegroundColor Green
    } else {
        $testResults += @{Test='Certificate Backup'; Status='FAIL'; Time='Missing files'}
        Write-Host "  ✗ FAIL - Certificate backup incomplete" -ForegroundColor Red
    }
    
} catch {
    $testResults += @{Test='Certificate Backup'; Status='FAIL'; Time='Error'}
    Write-Host "  ✗ FAIL - $_" -ForegroundColor Red
}

# Test 5: RTO/RPO Validation
Write-Host "`n[Test 5] RTO/RPO Validation..." -ForegroundColor Yellow

$rtoMet = $testResults | Where-Object {$_.Test -eq 'AG Failover' -and $_.Status -eq 'PASS'}
$rpoMet = $testResults | Where-Object {$_.Test -eq 'Backup Restore' -and $_.Status -eq 'PASS'}

if ($rtoMet -and $rpoMet) {
    $testResults += @{Test='RTO/RPO Targets'; Status='PASS'; Time='N/A'}
    Write-Host "  ✓ PASS - RTO (5 min) and RPO (0 sec) targets achievable" -ForegroundColor Green
} else {
    $testResults += @{Test='RTO/RPO Targets'; Status='FAIL'; Time='N/A'}
    Write-Host "  ✗ FAIL - RTO/RPO targets not met" -ForegroundColor Red
}

# Summary Report
Write-Host "`n==================================================================" -ForegroundColor Cyan
Write-Host "  DR Drill Summary" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

$passCount = ($testResults | Where-Object {$_.Status -eq 'PASS'}).Count
$failCount = ($testResults | Where-Object {$_.Status -eq 'FAIL'}).Count
$warnCount = ($testResults | Where-Object {$_.Status -eq 'WARNING'}).Count

$testResults | Format-Table Test, Status, Time -AutoSize

Write-Host "`nResults:" -ForegroundColor Cyan
Write-Host "  Passed:  $passCount" -ForegroundColor Green
Write-Host "  Failed:  $failCount" -ForegroundColor $(if($failCount -gt 0){'Red'}else{'Gray'})
Write-Host "  Warning: $warnCount" -ForegroundColor $(if($warnCount -gt 0){'Yellow'}else{'Gray'})

if ($failCount -eq 0) {
    Write-Host "`n✓ DR drill completed successfully - All systems operational" -ForegroundColor Green
} else {
    Write-Host "`n✗ DR drill completed with failures - Review and remediate" -ForegroundColor Red
}

# Save results to database
$resultsJson = $testResults | ConvertTo-Json

Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
               -Database "DBAOpsRepository" `
               -Query @"
INSERT INTO ctl.DRTestResults (
    TestDate, TestType, Results, PassCount, FailCount
)
VALUES (
    SYSDATETIME(),
    '$(if($ActualFailover){'Actual'}else{'Simulation'})',
    '$resultsJson',
    $passCount,
    $failCount
)
"@
```

---

## 11.7 Best Practices

### 11.7.1 HA/DR Checklist

**Production readiness:**

```
┌────────────────────────────────────────────────────────────┐
│           HA/DR PRODUCTION READINESS CHECKLIST              │
├────────────────────────────────────────────────────────────┤
│                                                             │
│ High Availability:                                          │
│ ☐ Always On AG configured with automatic failover          │
│ ☐ Synchronous replication between primary and secondary    │
│ ☐ Quorum configured (file share witness for 2-node)        │
│ ☐ Listener configured and tested                           │
│ ☐ Collectors use listener (not direct server names)        │
│ ☐ Multiple collectors in active-active mode                │
│ ☐ Collector heartbeat monitoring enabled                   │
│                                                             │
│ Backup Strategy:                                            │
│ ☐ Full backups weekly (Sundays)                            │
│ ☐ Differential backups daily (Mon-Sat)                     │
│ ☐ Transaction log backups every 15 minutes                 │
│ ☐ All backups encrypted with certificate                   │
│ ☐ Backup verification enabled                              │
│ ☐ 30-day retention policy implemented                      │
│ ☐ Backups stored on separate storage (not SQL Server)      │
│                                                             │
│ Disaster Recovery:                                          │
│ ☐ TDE certificate backed up to secure location             │
│ ☐ Certificate backup tested (restore to test server)       │
│ ☐ DR runbooks documented                                   │
│ ☐ RTO/RPO requirements defined and tested                  │
│ ☐ Quarterly DR drills scheduled                            │
│ ☐ DR test results tracked in database                      │
│                                                             │
│ Monitoring:                                                 │
│ ☐ AG health monitoring configured                          │
│ ☐ Backup health monitoring configured                      │
│ ☐ Collector heartbeat alerts configured                    │
│ ☐ Replication lag alerts configured                        │
│ ☐ Dashboard shows HA/DR status                             │
│                                                             │
│ Documentation:                                              │
│ ☐ Network diagram with all components                      │
│ ☐ Failover procedures documented                           │
│ ☐ Recovery procedures documented                           │
│ ☐ Contact list (DBAs, infrastructure, management)          │
│ ☐ Vendor support contact information                       │
│                                                             │
│ Testing:                                                    │
│ ☐ Automatic failover tested successfully                   │
│ ☐ Manual failover tested successfully                      │
│ ☐ Full restore tested successfully                         │
│ ☐ Point-in-time restore tested successfully                │
│ ☐ Collector failover tested successfully                   │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

---

## 11.8 Case Study: Healthcare Provider HA Implementation

**Background:**

HealthcareCo monitors 200 SQL Servers supporting patient care systems.

**The Crisis:**

**Previous State (Before HA):**
- Single repository server
- No redundancy
- Backups daily (24-hour RPO)
- Server failure = complete monitoring outage
- **Actual incident:** Repository server hardware failure
  - Monitoring down: 18 hours
  - Lost metrics: 1,080 samples (200 servers × 5 minutes × 18 hours / 5 min)
  - Patient care system issue undetected during outage
  - $450K incident cost

**The Solution (6-Week HA Implementation):**

**Week 1-2: Planning**
- RTO defined: 5 minutes
- RPO defined: 0 seconds (critical healthcare data)
- Hardware procurement: 2 new servers for AG
- WSFC cluster design
- Network configuration

**Week 3-4: Infrastructure**
- Installed WSFC on REPO-SQL01 and REPO-SQL02
- Configured database mirroring endpoints
- Set up file share witness

**Week 5: Always On Deployment**
- Created AG with automatic failover
- Configured synchronous replication
- Created AG listener
- Migrated collector connection strings

**Week 6: Testing & Validation**
- Automatic failover test: Successful (2.8 minutes)
- Manual failover test: Successful
- Collector failover test: Seamless
- Load testing: No performance impact
- DR drill: Successful

**Results After 6 Months:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Availability** ||||
| Repository uptime | 99.2% | 99.99% | 0.79% improvement |
| Annual downtime | 70 hours | 52 minutes | **99.3% reduction** |
| RTO | 18+ hours | 5 minutes | **99.5% faster** |
| RPO | 24 hours | 0 seconds | **100% improvement** |
| **Incidents** ||||
| Monitoring outages | 3/quarter | 0/6 months | **100% elimination** |
| Data loss events | 2/year | 0/6 months | **100% prevention** |
| Mean time to recover | 18 hours | 2.8 minutes | **99.7% faster** |
| **Operations** ||||
| Manual failovers tested | 0 | 8 | Routine testing |
| Failed failover tests | N/A | 0 | 100% success |
| Collector downtime | 18 hrs/incident | 0 | Seamless failover |

**Financial Impact:**

**Cost Avoidance:**
- Prevented monitoring outages: $450K/incident × 2 incidents = $900K
- Prevented data loss: $200K (estimated)
- Improved patient care: Immeasurable
**Total Benefits: $1.1M/year minimum**

**Investment:**
- Hardware (2 servers): $45K
- WSFC setup: $15K
- Always On implementation: $35K
- Testing and training: $20K
**Total Cost: $115K**

**ROI: 856%**
**Payback Period: 38 days**

**CIO Statement:**

*"The Always On implementation was completed in just 6 weeks and has paid for itself many times over. We haven't had a single monitoring outage in 6 months. More importantly, we can now guarantee that we'll know immediately if any patient care system has an issue. This is literally saving lives."*

**DBA Team Feedback:**

*"Before, I was terrified of the repository server failing. We had no backup plan. Now, I sleep soundly knowing that if the primary fails, we'll automatically fail over in under 3 minutes. The quarterly DR drills give us confidence that we're prepared for anything."*

**Key Success Factors:**

1. **Executive Support**: CIO recognized criticality
2. **Clear Requirements**: RTO/RPO defined upfront (5 min / 0 sec)
3. **Proper Testing**: 8 failover tests before go-live
4. **Documentation**: Complete runbooks created
5. **Training**: Team trained on failover procedures
6. **Regular Drills**: Quarterly DR tests institutionalized
7. **Monitoring**: AG health monitored 24/7

**Lessons Learned:**

1. **Quorum is Critical**: First test failed due to witness misconfiguration
2. **Connection Strings**: Some scripts still used direct server names (needed update)
3. **Certificate Backup**: Almost forgot to backup TDE certificate offsite
4. **Load Testing**: Should have load-tested before go-live (but worked fine)
5. **Documentation**: Runbooks proved invaluable during actual failover
6. **Culture Change**: DR drills now routine, not scary

---

## Chapter 11 Summary

This chapter covered high availability and disaster recovery:

**Key Takeaways:**

1. **HA Tiers**: Critical (99.99%), High (99.9%), Standard (99.5%)
2. **RTO/RPO**: Define recovery objectives (DBAOps: 5 min / 0 sec)
3. **Always On AG**: Synchronous replication + automatic failover
4. **Collector HA**: Active-active with automatic peer failover
5. **Backup Strategy**: Full + Diff + Log with encryption
6. **DR Testing**: Quarterly drills validate procedures
7. **Monitoring**: Track AG health, backup status, replication lag

**Production Implementation:**

✅ Complete Always On AG deployment scripts
✅ Collector active-active configuration
✅ Automated backup procedures
✅ Comprehensive DR runbooks
✅ HA/DR monitoring dashboards
✅ Quarterly DR drill automation
✅ RTO/RPO tracking

**Best Practices:**

✅ Use AG listener (not direct server names)
✅ Configure synchronous replication for 0 RPO
✅ Implement quorum for 2-node clusters
✅ Backup TDE certificates to secure location
✅ Test failover quarterly (minimum)
✅ Monitor AG sync state continuously
✅ Document all procedures
✅ Train team on runbooks
✅ Track DR test results
✅ Review and update RTO/RPO annually

**Connection to Next Chapter:**

Chapter 12 covers Performance Tuning, showing how to optimize the DBAOps framework itself for maximum efficiency when monitoring 1000+ servers, including query optimization, indexing strategies, and parallel collection tuning.

---

## Review Questions

**Multiple Choice:**

1. What is the RTO for a Critical tier component?
   a) 1 hour
   b) 15 minutes
   c) 5 minutes
   d) 1 minute

2. What replication mode provides 0-second RPO?
   a) Asynchronous
   b) Synchronous
   c) Log shipping
   d) Mirroring

3. How often should DR drills be conducted?
   a) Monthly
   b) Quarterly
   c) Annually
   d) Never (too risky)

**Short Answer:**

4. Explain the difference between RTO and RPO. Provide examples.

5. Why is a quorum necessary for a 2-node Always On cluster? What happens without it?

6. Describe the active-active collector architecture and its failover mechanism.

**Essay Questions:**

7. Design a complete HA/DR solution for an organization monitoring 500 SQL Servers. Include:
   - Availability tier classification
   - Always On AG configuration
   - Backup strategy
   - Collector redundancy
   - DR testing plan
   - Cost estimate

8. Analyze the HealthcareCo case study. What would happen if they had not implemented HA? Calculate the potential annual cost of monitoring outages.

**Hands-On Exercises:**

9. **Exercise 11.1: Deploy Always On AG**
   - Set up 2-node WSFC
   - Configure AG with automatic failover
   - Create listener
   - Test automatic failover
   - Document failover time

10. **Exercise 11.2: Implement Backup Strategy**
    - Configure full/diff/log backups
    - Enable backup encryption
    - Set up retention policy
    - Test restore procedures
    - Verify backup files

11. **Exercise 11.3: Configure Collector HA**
    - Deploy 2 collectors
    - Implement active-active
    - Configure heartbeat monitoring
    - Test failover scenario
    - Measure failover time

12. **Exercise 11.4: Conduct DR Drill**
    - Execute automated DR test
    - Perform actual AG failover
    - Restore from backup
    - Test collector failover
    - Generate results report

---

*End of Chapter 11*

**Next Chapter:** Chapter 12 - Performance Tuning

