# Chapter 19
# DevOps Integration

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Integrate** DBAOps with CI/CD pipelines
2. **Implement** database DevOps practices
3. **Automate** schema deployments
4. **Version control** database objects
5. **Validate** deployments automatically
6. **Monitor** deployment health
7. **Rollback** failed deployments
8. **Measure** deployment success rates

**Key Terms**

- DevOps
- CI/CD (Continuous Integration/Continuous Deployment)
- Infrastructure as Code (IaC)
- Database Migration
- Schema Versioning
- Deployment Pipeline
- Blue-Green Deployment
- Feature Flags
- GitOps

---

## 19.1 DevOps Framework

### 19.1.1 CI/CD Pipeline Integration

**DBAOps deployment tracking:**

```sql
CREATE TABLE devops.Deployments (
    DeploymentID BIGINT IDENTITY(1,1) PRIMARY KEY,
    
    -- Deployment metadata
    DeploymentName VARCHAR(200),
    Version VARCHAR(50),
    Environment VARCHAR(50),  -- Dev, QA, Staging, Production
    
    -- Source control
    Repository VARCHAR(200),
    Branch VARCHAR(100),
    CommitHash VARCHAR(100),
    PullRequestID VARCHAR(50),
    
    -- Timing
    QueuedDateTime DATETIME2,
    StartDateTime DATETIME2,
    EndDateTime DATETIME2,
    Duration_Minutes AS DATEDIFF(MINUTE, StartDateTime, EndDateTime),
    
    -- Status
    Status VARCHAR(50),  -- Queued, InProgress, Success, Failed, RolledBack
    DeploymentType VARCHAR(50),  -- Schema, Code, Data, Configuration
    
    -- Changes
    ObjectsModified INT,
    ObjectsAdded INT,
    ObjectsDeleted INT,
    
    -- Approvals
    ApprovedBy NVARCHAR(128),
    ApprovedDateTime DATETIME2,
    
    -- Results
    SuccessRate DECIMAL(5,2),
    ErrorCount INT,
    WarningCount INT,
    
    -- Rollback
    CanRollback BIT DEFAULT 1,
    RolledBackDateTime DATETIME2,
    RolledBackBy NVARCHAR(128),
    
    DeployedBy NVARCHAR(128),
    
    INDEX IX_Deployments_DateTime (StartDateTime DESC),
    INDEX IX_Deployments_Environment_Status (Environment, Status)
);
GO

-- Deployment steps
CREATE TABLE devops.DeploymentSteps (
    StepID BIGINT IDENTITY(1,1) PRIMARY KEY,
    DeploymentID BIGINT NOT NULL,
    StepSequence INT NOT NULL,
    
    StepName VARCHAR(200),
    StepType VARCHAR(50),  -- PreValidation, Backup, Deploy, Validation, Monitoring
    
    StartDateTime DATETIME2,
    EndDateTime DATETIME2,
    Duration_Seconds AS DATEDIFF(SECOND, StartDateTime, EndDateTime),
    
    Status VARCHAR(20),
    Output NVARCHAR(MAX),
    ErrorMessage NVARCHAR(MAX),
    
    FOREIGN KEY (DeploymentID) REFERENCES devops.Deployments(DeploymentID)
);
GO
```

---

### 19.1.2 Azure DevOps Integration

**Automated deployment pipeline:**

```powershell
<#
.SYNOPSIS
    Azure DevOps pipeline for database deployment

.DESCRIPTION
    Integrates with DBAOps framework for safe database deployments
#>

param(
    [Parameter(Mandatory)]
    [string]$Environment,
    
    [Parameter(Mandatory)]
    [string]$Version,
    
    [string]$TargetServer,
    [string]$DatabaseName
)

# Set error action
$ErrorActionPreference = "Stop"

# Log deployment start
$deploymentId = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                -Database "DBAOpsRepository" `
                                -Query @"
INSERT INTO devops.Deployments (
    DeploymentName, Version, Environment, Repository, Branch, CommitHash,
    QueuedDateTime, Status, DeployedBy
)
OUTPUT INSERTED.DeploymentID
VALUES (
    'Database Schema Update',
    '$Version',
    '$Environment',
    '$(Build.Repository.Name)',
    '$(Build.SourceBranchName)',
    '$(Build.SourceVersion)',
    SYSDATETIME(),
    'Queued',
    '$(Build.RequestedFor)'
)
"@ | Select-Object -ExpandProperty DeploymentID

Write-Host "Deployment ID: $deploymentId"

function Log-DeploymentStep {
    param(
        [int]$DeploymentID,
        [int]$Sequence,
        [string]$StepName,
        [string]$StepType,
        [string]$Status,
        [string]$Output = "",
        [string]$Error = ""
    )
    
    Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                   -Database "DBAOpsRepository" `
                   -Query @"
INSERT INTO devops.DeploymentSteps (
    DeploymentID, StepSequence, StepName, StepType, 
    StartDateTime, Status, Output, ErrorMessage
)
VALUES (
    $DeploymentID,
    $Sequence,
    '$StepName',
    '$StepType',
    SYSDATETIME(),
    '$Status',
    '$($Output.Replace("'", "''"))',
    '$($Error.Replace("'", "''"))'
)
"@
}

try {
    # Step 1: Pre-deployment validation
    Write-Host "Step 1: Pre-deployment validation..."
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 1 `
                      -StepName "Pre-deployment Validation" -StepType "PreValidation" `
                      -Status "InProgress"
    
    # Check if target server is healthy
    $serverHealth = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                    -Database "DBAOpsRepository" `
                                    -Query @"
SELECT PerformanceScore 
FROM fact.PerformanceMetrics pm
JOIN dim.Server s ON pm.ServerKey = s.ServerKey
WHERE s.ServerName = '$TargetServer'
  AND pm.CollectionDateTime >= DATEADD(MINUTE, -15, GETDATE())
ORDER BY pm.CollectionDateTime DESC
"@ | Select-Object -First 1
    
    if ($serverHealth.PerformanceScore -lt 50) {
        throw "Server health score too low: $($serverHealth.PerformanceScore). Aborting deployment."
    }
    
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 1 `
                      -StepName "Pre-deployment Validation" -StepType "PreValidation" `
                      -Status "Success" -Output "Server health: $($serverHealth.PerformanceScore)"
    
    # Step 2: Backup
    Write-Host "Step 2: Creating backup..."
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 2 `
                      -StepName "Pre-deployment Backup" -StepType "Backup" `
                      -Status "InProgress"
    
    $backupPath = "\\backup-server\PreDeployment\${DatabaseName}_${Version}_$(Get-Date -Format 'yyyyMMdd_HHmmss').bak"
    
    Backup-DbaDatabase -SqlInstance $TargetServer `
                      -Database $DatabaseName `
                      -Path $backupPath `
                      -Type Full `
                      -CompressBackup `
                      -Verify
    
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 2 `
                      -StepName "Pre-deployment Backup" -StepType "Backup" `
                      -Status "Success" -Output "Backup: $backupPath"
    
    # Step 3: Deploy schema changes
    Write-Host "Step 3: Deploying schema changes..."
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 3 `
                      -StepName "Schema Deployment" -StepType "Deploy" `
                      -Status "InProgress"
    
    # Apply migrations (example using Flyway or DbUp pattern)
    $migrationScripts = Get-ChildItem -Path "$(Build.SourcesDirectory)/migrations" -Filter "*.sql" | 
                        Sort-Object Name
    
    $objectsModified = 0
    foreach ($script in $migrationScripts) {
        Write-Host "  Applying: $($script.Name)"
        
        Invoke-DbaQuery -SqlInstance $TargetServer `
                       -Database $DatabaseName `
                       -File $script.FullName
        
        $objectsModified++
    }
    
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 3 `
                      -StepName "Schema Deployment" -StepType "Deploy" `
                      -Status "Success" -Output "$objectsModified scripts applied"
    
    # Step 4: Post-deployment validation
    Write-Host "Step 4: Post-deployment validation..."
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 4 `
                      -StepName "Post-deployment Validation" -StepType "Validation" `
                      -Status "InProgress"
    
    # Run validation queries
    $validationResults = Invoke-DbaQuery -SqlInstance $TargetServer `
                                         -Database $DatabaseName `
                                         -File "$(Build.SourcesDirectory)/validation/post-deploy.sql"
    
    if ($validationResults.TestsPassed -ne $validationResults.TotalTests) {
        throw "Validation failed: $($validationResults.TestsPassed)/$($validationResults.TotalTests) tests passed"
    }
    
    Log-DeploymentStep -DeploymentID $deploymentId -Sequence 4 `
                      -StepName "Post-deployment Validation" -StepType "Validation" `
                      -Status "Success" -Output "All validation tests passed"
    
    # Step 5: Monitor for issues
    Write-Host "Step 5: Monitoring deployment health..."
    Start-Sleep -Seconds 60  # Wait 1 minute
    
    $postDeployHealth = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                        -Database "DBAOpsRepository" `
                                        -Query @"
SELECT 
    COUNT(*) AS ErrorCount
FROM alert.AlertQueue
WHERE ServerName = '$TargetServer'
  AND CreatedDateTime >= DATEADD(MINUTE, -5, GETDATE())
  AND Severity IN ('Critical', 'High')
"@
    
    if ($postDeployHealth.ErrorCount -gt 0) {
        Write-Warning "Detected $($postDeployHealth.ErrorCount) alerts post-deployment"
    }
    
    # Update deployment status
    Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                   -Database "DBAOpsRepository" `
                   -Query @"
UPDATE devops.Deployments
SET Status = 'Success',
    EndDateTime = SYSDATETIME(),
    ObjectsModified = $objectsModified,
    ErrorCount = $($postDeployHealth.ErrorCount)
WHERE DeploymentID = $deploymentId
"@
    
    Write-Host "✓ Deployment completed successfully" -ForegroundColor Green
    
    # Publish deployment metrics to Azure DevOps
    Write-Host "##vso[task.setvariable variable=DeploymentSuccess]true"
    Write-Host "##vso[task.setvariable variable=DeploymentID]$deploymentId"
}
catch {
    Write-Error "Deployment failed: $_"
    
    # Log failure
    Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                   -Database "DBAOpsRepository" `
                   -Query @"
UPDATE devops.Deployments
SET Status = 'Failed',
    EndDateTime = SYSDATETIME(),
    ErrorCount = 1
WHERE DeploymentID = $deploymentId
"@
    
    # Optionally auto-rollback
    if ($Environment -eq "Production") {
        Write-Host "Initiating rollback..." -ForegroundColor Yellow
        
        # Restore from backup
        Restore-DbaDatabase -SqlInstance $TargetServer `
                           -Path $backupPath `
                           -DatabaseName $DatabaseName `
                           -WithReplace
        
        Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                       -Database "DBAOpsRepository" `
                       -Query @"
UPDATE devops.Deployments
SET Status = 'RolledBack',
    RolledBackDateTime = SYSDATETIME(),
    RolledBackBy = 'Automated'
WHERE DeploymentID = $deploymentId
"@
    }
    
    exit 1
}
```

---

## 19.2 Database Version Control

### 19.2.1 Schema Migration Framework

```sql
CREATE TABLE devops.SchemaMigrations (
    MigrationID INT IDENTITY(1,1) PRIMARY KEY,
    Version VARCHAR(50) NOT NULL UNIQUE,
    Description NVARCHAR(500),
    
    ScriptName VARCHAR(200),
    ScriptHash VARCHAR(100),  -- SHA256 hash
    
    AppliedDateTime DATETIME2 DEFAULT SYSDATETIME(),
    AppliedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    
    ExecutionTime_Seconds INT,
    Status VARCHAR(20),
    
    INDEX IX_SchemaMigrations_Version (Version DESC)
);
GO

-- Procedure to apply migration
CREATE PROCEDURE devops.usp_ApplyMigration
    @Version VARCHAR(50),
    @Description NVARCHAR(500),
    @ScriptContent NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Check if already applied
    IF EXISTS (SELECT 1 FROM devops.SchemaMigrations WHERE Version = @Version)
    BEGIN
        RAISERROR('Migration %s already applied', 16, 1, @Version);
        RETURN;
    END
    
    DECLARE @StartTime DATETIME2 = SYSDATETIME();
    DECLARE @Status VARCHAR(20);
    
    BEGIN TRY
        -- Apply migration
        EXEC sp_executesql @ScriptContent;
        
        SET @Status = 'Success';
    END TRY
    BEGIN CATCH
        SET @Status = 'Failed';
        
        -- Log error but don't record migration
        DECLARE @ErrorMsg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR('Migration failed: %s', 16, 1, @ErrorMsg);
        RETURN;
    END CATCH
    
    -- Record successful migration
    INSERT INTO devops.SchemaMigrations (
        Version, Description, AppliedBy, ExecutionTime_Seconds, Status
    )
    VALUES (
        @Version,
        @Description,
        SUSER_SNAME(),
        DATEDIFF(SECOND, @StartTime, SYSDATETIME()),
        @Status
    );
END
GO
```

---

## 19.3 Deployment Metrics

### 19.3.1 DORA Metrics

```sql
CREATE VIEW devops.vw_DORAMetrics AS
WITH DeploymentMetrics AS (
    SELECT 
        DATEPART(YEAR, StartDateTime) AS Year,
        DATEPART(MONTH, StartDateTime) AS Month,
        Environment,
        
        -- Deployment Frequency
        COUNT(*) AS TotalDeployments,
        COUNT(*) * 1.0 / NULLIF(DAY(EOMONTH(MIN(StartDateTime))), 0) AS DeploymentsPerDay,
        
        -- Lead Time for Changes (queue to deployment)
        AVG(DATEDIFF(MINUTE, QueuedDateTime, EndDateTime)) AS AvgLeadTime_Minutes,
        
        -- Change Failure Rate
        SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS FailureRate_Percent,
        
        -- Time to Restore Service (failed deployments)
        AVG(CASE WHEN Status = 'RolledBack' 
            THEN DATEDIFF(MINUTE, StartDateTime, RolledBackDateTime) 
            ELSE NULL END) AS AvgRecoveryTime_Minutes
    FROM devops.Deployments
    WHERE StartDateTime >= DATEADD(MONTH, -6, GETDATE())
    GROUP BY DATEPART(YEAR, StartDateTime), DATEPART(MONTH, StartDateTime), Environment
)
SELECT 
    Year,
    Month,
    Environment,
    TotalDeployments,
    DeploymentsPerDay,
    
    -- Performance tier
    CASE 
        WHEN DeploymentsPerDay >= 1 THEN 'Elite'
        WHEN DeploymentsPerDay >= 0.14 THEN 'High'  -- Weekly
        WHEN DeploymentsPerDay >= 0.03 THEN 'Medium'  -- Monthly
        ELSE 'Low'
    END AS DeploymentFrequency_Tier,
    
    AvgLeadTime_Minutes,
    CASE 
        WHEN AvgLeadTime_Minutes < 60 THEN 'Elite'  -- < 1 hour
        WHEN AvgLeadTime_Minutes < 1440 THEN 'High'  -- < 1 day
        WHEN AvgLeadTime_Minutes < 10080 THEN 'Medium'  -- < 1 week
        ELSE 'Low'
    END AS LeadTime_Tier,
    
    FailureRate_Percent,
    CASE 
        WHEN FailureRate_Percent < 5 THEN 'Elite'
        WHEN FailureRate_Percent < 10 THEN 'High'
        WHEN FailureRate_Percent < 15 THEN 'Medium'
        ELSE 'Low'
    END AS ChangeFailureRate_Tier,
    
    AvgRecoveryTime_Minutes,
    CASE 
        WHEN AvgRecoveryTime_Minutes < 60 THEN 'Elite'  -- < 1 hour
        WHEN AvgRecoveryTime_Minutes < 1440 THEN 'High'  -- < 1 day
        WHEN AvgRecoveryTime_Minutes < 10080 THEN 'Medium'  -- < 1 week
        ELSE 'Low'
    END AS RecoveryTime_Tier
FROM DeploymentMetrics;
GO
```

---

## 19.4 Case Study: SaaS Platform DevOps

**Background:** CloudApp, 40 databases, 200 deployments/month.

**Challenge:**
- Manual deployments (4-6 hours each)
- 18% failure rate
- No rollback capability
- Production incidents after deployments

**6-Month DevOps Transformation:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Deployment** ||||
| Deployment time | 4-6 hours | 12 minutes | **96% faster** |
| Deployments/month | 8 | 200 | **25x increase** |
| Manual steps | 47 | 0 | Fully automated |
| **Quality** ||||
| Failure rate | 18% | 2.3% | **87% reduction** |
| Rollback time | 8 hours | 3 minutes | **99% faster** |
| Post-deploy incidents | 12/month | 1/month | **92% reduction** |
| **DORA Metrics** ||||
| Deployment frequency | Monthly | Daily | Elite tier |
| Lead time | 4 days | 45 minutes | Elite tier |
| Change failure rate | 18% | 2.3% | Elite tier |
| Recovery time | 8 hours | 3 minutes | Elite tier |

**Value:** $4.8M/year
**ROI: 3,840%**

---

## Chapter 19 Summary

**Key Takeaways:**
1. Integrate DBAOps with CI/CD pipelines
2. Automate database deployments
3. Version control all schema changes
4. Validate before and after deployment
5. Monitor deployment health
6. Enable fast rollbacks
7. Measure with DORA metrics

**Production:**
✅ CI/CD integration
✅ Automated deployments
✅ Schema versioning
✅ DORA metrics
✅ 96% faster deployments
✅ $4.8M value

**Next:** Chapter 20 - Cost Optimization

