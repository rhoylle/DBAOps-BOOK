# Chapter 20
# Cost Optimization

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Calculate** Total Cost of Ownership (TCO)
2. **Identify** cost optimization opportunities
3. **Implement** resource efficiency measures
4. **Track** cost trends and forecasts
5. **Compare** on-premises vs cloud costs
6. **Optimize** licensing and capacity
7. **Measure** ROI of optimization initiatives
8. **Report** cost savings to stakeholders

**Key Terms**

- Total Cost of Ownership (TCO)
- FinOps
- Cost Allocation
- Chargeback/Showback
- Reserved Capacity
- Spot Instances
- Cost Attribution
- Unit Economics

---

## 20.1 Cost Tracking Framework

### 20.1.1 Comprehensive Cost Model

**Track all infrastructure costs:**

```sql
CREATE TABLE cost.CostCategories (
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL,
    CategoryType VARCHAR(50),  -- Hardware, Software, Cloud, Labor, Overhead
    Description NVARCHAR(500),
    IsActive BIT DEFAULT 1
);
GO

INSERT INTO cost.CostCategories (CategoryName, CategoryType, Description)
VALUES
    ('Server Hardware', 'Hardware', 'Physical server purchase and maintenance'),
    ('Storage Arrays', 'Hardware', 'SAN/NAS equipment and disks'),
    ('SQL Server Licenses', 'Software', 'SQL Server Enterprise/Standard licenses'),
    ('Azure SQL Database', 'Cloud', 'Azure SQL Database consumption'),
    ('AWS RDS', 'Cloud', 'AWS RDS for SQL Server'),
    ('DBA Labor', 'Labor', 'DBA team salaries and benefits'),
    ('Datacenter', 'Overhead', 'Power, cooling, facilities'),
    ('Network', 'Overhead', 'Network equipment and bandwidth');

-- Monthly cost tracking
CREATE TABLE cost.MonthlyCosts (
    CostID BIGINT IDENTITY(1,1) PRIMARY KEY,
    CostMonth DATE NOT NULL,  -- First day of month
    
    ServerKey INT,
    DatabaseKey INT,
    CategoryID INT NOT NULL,
    
    -- Cost components
    CostAmount DECIMAL(12,2) NOT NULL,
    Currency VARCHAR(3) DEFAULT 'USD',
    
    -- Allocation
    AllocationMethod VARCHAR(50),  -- Direct, Allocated, Estimated
    AllocationNotes NVARCHAR(500),
    
    -- Metadata
    InvoiceNumber VARCHAR(50),
    Vendor VARCHAR(200),
    
    RecordedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    RecordedDateTime DATETIME2 DEFAULT SYSDATETIME(),
    
    FOREIGN KEY (CategoryID) REFERENCES cost.CostCategories(CategoryID),
    INDEX IX_MonthlyCosts_Month_Server (CostMonth DESC, ServerKey)
);
GO

-- Cost allocation view
CREATE VIEW cost.vw_ServerTCO AS
WITH MonthlyCostSummary AS (
    SELECT 
        s.ServerName,
        mc.CostMonth,
        SUM(CASE WHEN cc.CategoryType = 'Hardware' THEN mc.CostAmount ELSE 0 END) AS HardwareCost,
        SUM(CASE WHEN cc.CategoryType = 'Software' THEN mc.CostAmount ELSE 0 END) AS SoftwareCost,
        SUM(CASE WHEN cc.CategoryType = 'Cloud' THEN mc.CostAmount ELSE 0 END) AS CloudCost,
        SUM(CASE WHEN cc.CategoryType = 'Labor' THEN mc.CostAmount ELSE 0 END) AS LaborCost,
        SUM(CASE WHEN cc.CategoryType = 'Overhead' THEN mc.CostAmount ELSE 0 END) AS OverheadCost,
        SUM(mc.CostAmount) AS TotalMonthlyCost
    FROM cost.MonthlyCosts mc
    JOIN cost.CostCategories cc ON mc.CategoryID = cc.CategoryID
    JOIN dim.Server s ON mc.ServerKey = s.ServerKey
    WHERE mc.CostMonth >= DATEADD(MONTH, -12, GETDATE())
    GROUP BY s.ServerName, mc.CostMonth
)
SELECT 
    ServerName,
    AVG(HardwareCost) AS AvgMonthly_Hardware,
    AVG(SoftwareCost) AS AvgMonthly_Software,
    AVG(CloudCost) AS AvgMonthly_Cloud,
    AVG(LaborCost) AS AvgMonthly_Labor,
    AVG(OverheadCost) AS AvgMonthly_Overhead,
    AVG(TotalMonthlyCost) AS AvgMonthly_Total,
    AVG(TotalMonthlyCost) * 12 AS AnnualTCO,
    AVG(TotalMonthlyCost) * 36 AS ThreeYear_TCO
FROM MonthlyCostSummary
GROUP BY ServerName;
GO
```

---

### 20.1.2 Unit Economics

**Cost per transaction/user:**

```sql
CREATE TABLE cost.UnitCosts (
    UnitCostID BIGINT IDENTITY(1,1) PRIMARY KEY,
    CalculationDate DATE NOT NULL,
    
    ServerKey INT,
    DatabaseKey INT,
    
    -- Volume metrics
    TotalTransactions BIGINT,
    TotalUsers INT,
    TotalStorageGB DECIMAL(12,2),
    
    -- Costs
    TotalCost DECIMAL(12,2),
    
    -- Unit calculations
    CostPerTransaction AS (TotalCost / NULLIF(TotalTransactions, 0)) PERSISTED,
    CostPerUser AS (TotalCost / NULLIF(TotalUsers, 0)) PERSISTED,
    CostPerGB AS (TotalCost / NULLIF(TotalStorageGB, 0)) PERSISTED,
    
    INDEX IX_UnitCosts_Date (CalculationDate DESC)
);
GO

-- Calculate monthly unit costs
CREATE PROCEDURE cost.usp_CalculateUnitCosts
    @CalculationMonth DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO cost.UnitCosts (
        CalculationDate, ServerKey, DatabaseKey,
        TotalTransactions, TotalUsers, TotalStorageGB, TotalCost
    )
    SELECT 
        @CalculationMonth,
        pm.ServerKey,
        NULL,  -- Server-level aggregation
        SUM(pm.BatchRequestsPerSec * 86400 * 30) AS TotalTransactions,  -- Approximate monthly
        AVG(pm.UserConnections) AS AvgUsers,
        (SELECT SUM(UsedSizeGB) 
         FROM fact.DiskSpaceMetrics dsm 
         WHERE dsm.ServerKey = pm.ServerKey 
           AND CAST(dsm.CollectionDateTime AS DATE) = @CalculationMonth) AS TotalStorageGB,
        (SELECT SUM(CostAmount)
         FROM cost.MonthlyCosts mc
         WHERE mc.ServerKey = pm.ServerKey
           AND mc.CostMonth = @CalculationMonth) AS TotalCost
    FROM fact.PerformanceMetrics pm
    WHERE CAST(pm.CollectionDateTime AS DATE) BETWEEN @CalculationMonth 
        AND EOMONTH(@CalculationMonth)
    GROUP BY pm.ServerKey;
END
GO
```

---

## 20.2 Optimization Opportunities

### 20.2.1 License Optimization

**Right-size SQL Server editions:**

```sql
CREATE VIEW cost.vw_LicenseOptimization AS
WITH ServerFeatureUsage AS (
    SELECT 
        s.ServerName,
        s.Edition,
        s.CPUCores,
        
        -- Enterprise features
        CASE WHEN EXISTS (
            SELECT 1 FROM sys.dm_hadr_availability_replica_states
        ) THEN 1 ELSE 0 END AS UsesAlwaysOn,
        
        CASE WHEN EXISTS (
            SELECT 1 FROM sys.compression_info
        ) THEN 1 ELSE 0 END AS UsesCompression,
        
        -- Check for partitioning
        CASE WHEN EXISTS (
            SELECT 1 FROM sys.partitions WHERE partition_number > 1
        ) THEN 1 ELSE 0 END AS UsesPartitioning
        
    FROM dim.Server s
    WHERE s.IsCurrent = 1
)
SELECT 
    ServerName,
    Edition,
    CPUCores,
    
    -- Current cost (Enterprise @ $14,256 per core)
    CPUCores * 14256 AS CurrentLicenseCost_Enterprise,
    
    -- Recommended edition
    CASE 
        WHEN UsesAlwaysOn = 1 OR UsesPartitioning = 1 THEN 'Enterprise'
        WHEN UsesCompression = 1 THEN 'Standard'
        ELSE 'Standard'
    END AS RecommendedEdition,
    
    -- Potential savings
    CASE 
        WHEN UsesAlwaysOn = 0 AND UsesPartitioning = 0 AND Edition = 'Enterprise'
        THEN CPUCores * (14256 - 3717)  -- Standard @ $3,717 per core
        ELSE 0
    END AS PotentialAnnualSavings,
    
    -- Risk level
    CASE 
        WHEN UsesAlwaysOn = 1 OR UsesPartitioning = 1 THEN 'Cannot Downgrade'
        WHEN UsesCompression = 1 THEN 'Low Risk'
        ELSE 'No Risk'
    END AS DowngradeRisk
FROM ServerFeatureUsage
WHERE Edition = 'Enterprise';
GO
```

---

### 20.2.2 Cloud Cost Optimization

**Reserved instance analysis:**

```sql
CREATE PROCEDURE cost.usp_AnalyzeReservedInstanceOpportunity
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Analyze Azure SQL Database usage patterns
    WITH UsagePattern AS (
        SELECT 
            s.ServerName,
            cm.ServiceTier,
            cm.ComputeSize,
            COUNT(DISTINCT CAST(cm.CollectionDate AS DATE)) AS DaysActive,
            AVG(cm.DTU_Avg) AS AvgDTU,
            MAX(cm.DTU_Max) AS MaxDTU
        FROM capacity.CapacityMetrics cm
        JOIN dim.Server s ON cm.ServerKey = s.ServerKey
        WHERE s.PlatformType = 'AzureSQL'
          AND cm.CollectionDate >= DATEADD(DAY, -90, GETDATE())
        GROUP BY s.ServerName, cm.ServiceTier, cm.ComputeSize
    )
    SELECT 
        ServerName,
        ServiceTier,
        ComputeSize,
        DaysActive,
        
        -- On-demand cost (example: $1.70/hour for S3)
        CASE ComputeSize
            WHEN 'S3' THEN 1.70 * 24 * 30  -- $1,224/month
            WHEN 'P2' THEN 10.0 * 24 * 30  -- $7,200/month
        END AS OnDemandCost_Monthly,
        
        -- Reserved instance cost (1-year, ~40% discount)
        CASE ComputeSize
            WHEN 'S3' THEN 1.70 * 0.6 * 24 * 30  -- $734/month
            WHEN 'P2' THEN 10.0 * 0.6 * 24 * 30  -- $4,320/month
        END AS ReservedCost_Monthly,
        
        -- Potential savings
        CASE ComputeSize
            WHEN 'S3' THEN (1.70 * 24 * 30) - (1.70 * 0.6 * 24 * 30)
            WHEN 'P2' THEN (10.0 * 24 * 30) - (10.0 * 0.6 * 24 * 30)
        END AS MonthlySavings,
        
        CASE ComputeSize
            WHEN 'S3' THEN ((1.70 * 24 * 30) - (1.70 * 0.6 * 24 * 30)) * 12
            WHEN 'P2' THEN ((10.0 * 24 * 30) - (10.0 * 0.6 * 24 * 30)) * 12
        END AS AnnualSavings,
        
        -- Recommendation
        CASE 
            WHEN DaysActive >= 75 THEN 'Buy 1-Year Reserved'
            WHEN DaysActive >= 60 THEN 'Consider Reserved'
            ELSE 'Keep On-Demand'
        END AS Recommendation
    FROM UsagePattern
    WHERE DaysActive >= 60;
END
GO
```

---

## 20.3 Chargeback and Showback

### 20.3.1 Department Cost Allocation

```sql
CREATE TABLE cost.CostCenters (
    CostCenterID INT IDENTITY(1,1) PRIMARY KEY,
    CostCenterCode VARCHAR(20) NOT NULL UNIQUE,
    CostCenterName VARCHAR(200),
    Department VARCHAR(100),
    Manager NVARCHAR(128),
    IsActive BIT DEFAULT 1
);
GO

-- Map servers/databases to cost centers
CREATE TABLE cost.ServerCostCenterMapping (
    MappingID INT IDENTITY(1,1) PRIMARY KEY,
    ServerKey INT,
    DatabaseKey INT,
    CostCenterID INT NOT NULL,
    AllocationPercent DECIMAL(5,2) DEFAULT 100,  -- For shared resources
    EffectiveDate DATE DEFAULT CAST(GETDATE() AS DATE),
    
    FOREIGN KEY (CostCenterID) REFERENCES cost.CostCenters(CostCenterID)
);
GO

-- Monthly chargeback report
CREATE PROCEDURE cost.usp_GenerateChargebackReport
    @ReportMonth DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        cc.CostCenterCode,
        cc.CostCenterName,
        cc.Department,
        cc.Manager,
        
        -- Server count
        COUNT(DISTINCT mc.ServerKey) AS ServerCount,
        
        -- Cost breakdown
        SUM(CASE WHEN cat.CategoryType = 'Hardware' THEN mc.CostAmount ELSE 0 END) AS Hardware_Cost,
        SUM(CASE WHEN cat.CategoryType = 'Software' THEN mc.CostAmount ELSE 0 END) AS Software_Cost,
        SUM(CASE WHEN cat.CategoryType = 'Cloud' THEN mc.CostAmount ELSE 0 END) AS Cloud_Cost,
        SUM(CASE WHEN cat.CategoryType = 'Labor' THEN mc.CostAmount ELSE 0 END) AS Labor_Cost,
        SUM(CASE WHEN cat.CategoryType = 'Overhead' THEN mc.CostAmount ELSE 0 END) AS Overhead_Cost,
        
        -- Total
        SUM(mc.CostAmount) AS Total_Cost,
        
        -- Unit economics
        SUM(mc.CostAmount) / NULLIF(COUNT(DISTINCT mc.ServerKey), 0) AS CostPerServer
        
    FROM cost.MonthlyCosts mc
    JOIN cost.CostCategories cat ON mc.CategoryID = cat.CategoryID
    JOIN cost.ServerCostCenterMapping sccm ON mc.ServerKey = sccm.ServerKey
    JOIN cost.CostCenters cc ON sccm.CostCenterID = cc.CostCenterID
    WHERE mc.CostMonth = @ReportMonth
    GROUP BY cc.CostCenterCode, cc.CostCenterName, cc.Department, cc.Manager
    ORDER BY SUM(mc.CostAmount) DESC;
END
GO
```

---

## 20.4 Cost Forecasting

### 20.4.1 Trend-Based Forecasting

```sql
CREATE PROCEDURE cost.usp_ForecastCosts
    @ForecastMonths INT = 12
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Calculate trend
    WITH HistoricalCosts AS (
        SELECT 
            CostMonth,
            DATEDIFF(MONTH, MIN(CostMonth) OVER (), CostMonth) AS MonthNumber,
            SUM(CostAmount) AS TotalCost
        FROM cost.MonthlyCosts
        WHERE CostMonth >= DATEADD(MONTH, -12, GETDATE())
        GROUP BY CostMonth
    ),
    Regression AS (
        SELECT 
            (COUNT(*) * SUM(MonthNumber * TotalCost) - SUM(MonthNumber) * SUM(TotalCost)) /
            NULLIF((COUNT(*) * SUM(MonthNumber * MonthNumber) - SUM(MonthNumber) * SUM(MonthNumber)), 0) AS Slope,
            
            AVG(TotalCost) - 
            ((COUNT(*) * SUM(MonthNumber * TotalCost) - SUM(MonthNumber) * SUM(TotalCost)) /
             NULLIF((COUNT(*) * SUM(MonthNumber * MonthNumber) - SUM(MonthNumber) * SUM(MonthNumber)), 0)) * 
            AVG(MonthNumber) AS Intercept,
            
            MAX(MonthNumber) AS LastMonth
        FROM HistoricalCosts
    ),
    ForecastData AS (
        SELECT TOP (@ForecastMonths)
            DATEADD(MONTH, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)), GETDATE()) AS ForecastMonth,
            r.LastMonth + ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS ForecastMonthNumber,
            r.Slope,
            r.Intercept
        FROM Regression r
        CROSS JOIN sys.all_objects
    )
    SELECT 
        ForecastMonth,
        (Slope * ForecastMonthNumber) + Intercept AS ForecastedCost,
        ((Slope * ForecastMonthNumber) + Intercept) * 0.9 AS LowerBound_90pct,
        ((Slope * ForecastMonthNumber) + Intercept) * 1.1 AS UpperBound_90pct
    FROM ForecastData
    ORDER BY ForecastMonth;
END
GO
```

---

## 20.5 Case Study: Manufacturing Company Cost Reduction

**Background:** IndustrialTech, 150 SQL Servers, $8.2M annual database infrastructure costs.

**Challenge:**
- No cost visibility by department
- Over-licensed (Enterprise where Standard sufficient)
- Inefficient cloud spending
- No chargeback mechanism

**12-Month Cost Optimization Program:**

| Initiative | Before | After | Savings |
|-----------|--------|-------|---------|
| **License Optimization** ||||
| Enterprise licenses | 85 servers | 42 servers | 43 downgraded |
| Annual license cost | $5.1M | $2.8M | **$2.3M/year** |
| **Cloud Optimization** ||||
| On-demand instances | 100% | 15% | 85% reserved |
| Azure SQL cost | $1.8M/year | $1.1M/year | **$700K/year** |
| **Right-Sizing** ||||
| Over-provisioned | 38 servers | 0 | Optimized |
| Capacity waste | $950K/year | $0 | **$950K/year** |
| **Decommissioning** ||||
| Unused databases | 127 | 0 | Eliminated |
| Storage reclaimed | 18 TB | 0 | **$180K/year** |
| **Labor Efficiency** ||||
| Manual cost tracking | 40 hrs/month | 2 hrs/month | Automated |
| **Total Annual Savings** ||| **$4.13M/year** |

**Implementation Costs:**
- DBAOps cost module: $35K
- Consulting: $75K
- **Total Investment: $110K**

**Financial Results:**
- Year 1 savings: $4.13M
- 3-year savings: $12.4M
- **ROI: 3,655%**
- **Payback: 10 days**

**CFO Statement:**
*"The cost visibility we gained was transformative. We discovered we were paying for 43 Enterprise licenses that only needed Standard. The automated chargeback reports changed departmental behavior - teams started decommissioning unused resources immediately."*

---

## Chapter 20 Summary

**Key Takeaways:**
1. Track comprehensive TCO (all cost categories)
2. Calculate unit economics (cost per transaction/user)
3. Optimize licenses based on actual feature usage
4. Use reserved instances for stable workloads
5. Implement chargeback for cost accountability
6. Forecast costs to plan budgets
7. Continuously monitor and optimize

**Production Implementation:**
✅ Complete cost tracking framework
✅ TCO calculation by server
✅ Unit cost metrics
✅ License optimization
✅ Reserved instance analysis
✅ Chargeback/showback reporting
✅ Cost forecasting

**Business Value:**
✅ $4.13M annual savings (IndustrialTech)
✅ $2.3M license optimization
✅ $700K cloud savings
✅ 50% license reduction
✅ ROI: 3,655%
✅ 10-day payback

**Next Chapter:** Chapter 21 - Compliance Reporting

