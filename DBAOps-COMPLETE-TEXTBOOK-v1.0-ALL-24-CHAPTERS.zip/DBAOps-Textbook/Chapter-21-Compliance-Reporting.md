# Chapter 21
# Compliance Reporting

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Generate** compliance reports for auditors
2. **Demonstrate** regulatory compliance
3. **Track** compliance metrics over time
4. **Automate** compliance evidence collection
5. **Produce** audit-ready documentation
6. **Maintain** compliance history
7. **Respond** to audit requests efficiently

**Key Terms**

- Compliance Reporting
- Audit Trail
- Evidence Collection
- Attestation
- Compliance Dashboard
- Regulatory Framework
- Control Effectiveness
- Continuous Compliance

---

## 21.1 Compliance Framework

### 21.1.1 Regulatory Mapping

```sql
CREATE TABLE compliance.RegulatoryFrameworks (
    FrameworkID INT IDENTITY(1,1) PRIMARY KEY,
    FrameworkName VARCHAR(100) NOT NULL,
    FrameworkType VARCHAR(50),  -- SOX, HIPAA, PCI-DSS, GDPR, SOC2, ISO27001
    Description NVARCHAR(500),
    IsActive BIT DEFAULT 1
);
GO

INSERT INTO compliance.RegulatoryFrameworks (FrameworkName, FrameworkType, Description)
VALUES
    ('SOX Section 404', 'SOX', 'IT General Controls for financial reporting'),
    ('HIPAA Security Rule', 'HIPAA', 'Protected Health Information safeguards'),
    ('PCI-DSS v4.0', 'PCI-DSS', 'Payment card data protection'),
    ('GDPR Article 32', 'GDPR', 'Security of processing'),
    ('SOC 2 Type II', 'SOC2', 'Trust Services Criteria');

-- Control requirements
CREATE TABLE compliance.ControlRequirements (
    ControlID INT IDENTITY(1,1) PRIMARY KEY,
    FrameworkID INT NOT NULL,
    ControlNumber VARCHAR(50),
    ControlTitle VARCHAR(200),
    ControlDescription NVARCHAR(MAX),
    
    -- DBAOps evidence
    EvidenceQuery NVARCHAR(MAX),  -- SQL query to generate evidence
    EvidenceFrequency VARCHAR(20),  -- Daily, Weekly, Monthly, Quarterly, Annual
    
    IsAutomated BIT DEFAULT 0,
    FOREIGN KEY (FrameworkID) REFERENCES compliance.RegulatoryFrameworks(FrameworkID)
);
GO

-- Example controls
INSERT INTO compliance.ControlRequirements (FrameworkID, ControlNumber, ControlTitle, EvidenceQuery, EvidenceFrequency)
VALUES
    (1, 'ITGC-01', 'Change Management - All changes are logged and approved',
     'SELECT * FROM log.ConfigurationChanges WHERE ChangeDateTime >= @StartDate AND ChangeDateTime <= @EndDate',
     'Quarterly'),
    (1, 'ITGC-02', 'Access Control - User access is reviewed quarterly',
     'SELECT * FROM security.UserAccessReview WHERE ReviewDate >= @StartDate AND ReviewDate <= @EndDate',
     'Quarterly'),
    (2, 'HIPAA-164.312(b)', 'Audit Controls - System activity is logged and monitored',
     'SELECT COUNT(*) FROM log.SecurityAuditLog WHERE EventDate >= @StartDate',
     'Monthly');
```

---

### 21.1.2 Automated Evidence Collection

```sql
CREATE TABLE compliance.EvidenceCollection (
    EvidenceID BIGINT IDENTITY(1,1) PRIMARY KEY,
    ControlID INT NOT NULL,
    
    CollectionDateTime DATETIME2 DEFAULT SYSDATETIME(),
    PeriodStart DATE,
    PeriodEnd DATE,
    
    EvidenceData NVARCHAR(MAX),  -- JSON format
    RecordCount INT,
    
    Status VARCHAR(20),  -- Pass, Fail, Exception
    Notes NVARCHAR(500),
    
    CollectedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    
    FOREIGN KEY (ControlID) REFERENCES compliance.ControlRequirements(ControlID),
    INDEX IX_EvidenceCollection_DateTime (CollectionDateTime DESC)
);
GO

-- Automated evidence collection procedure
CREATE PROCEDURE compliance.usp_CollectEvidence
    @ControlID INT = NULL,
    @PeriodStart DATE = NULL,
    @PeriodEnd DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @PeriodStart IS NULL SET @PeriodStart = DATEADD(QUARTER, -1, GETDATE());
    IF @PeriodEnd IS NULL SET @PeriodEnd = GETDATE();
    
    DECLARE @EvidenceQuery NVARCHAR(MAX), @RecordCount INT;
    DECLARE @EvidenceData NVARCHAR(MAX), @Status VARCHAR(20);
    
    DECLARE evidence_cursor CURSOR FOR
    SELECT ControlID, EvidenceQuery
    FROM compliance.ControlRequirements
    WHERE (@ControlID IS NULL OR ControlID = @ControlID)
      AND IsAutomated = 1;
    
    OPEN evidence_cursor;
    FETCH NEXT FROM evidence_cursor INTO @ControlID, @EvidenceQuery;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Replace date parameters
            SET @EvidenceQuery = REPLACE(@EvidenceQuery, '@StartDate', '''' + CAST(@PeriodStart AS VARCHAR(20)) + '''');
            SET @EvidenceQuery = REPLACE(@EvidenceQuery, '@EndDate', '''' + CAST(@PeriodEnd AS VARCHAR(20)) + '''');
            
            -- Execute and capture results as JSON
            SET @EvidenceQuery = 'SET @Result = (SELECT * FROM (' + @EvidenceQuery + ') q FOR JSON AUTO)';
            
            EXEC sp_executesql @EvidenceQuery, N'@Result NVARCHAR(MAX) OUTPUT', @Result = @EvidenceData OUTPUT;
            
            SET @RecordCount = (SELECT COUNT(*) FROM OPENJSON(@EvidenceData));
            SET @Status = CASE WHEN @RecordCount > 0 THEN 'Pass' ELSE 'Exception' END;
            
            -- Store evidence
            INSERT INTO compliance.EvidenceCollection (
                ControlID, PeriodStart, PeriodEnd, EvidenceData, RecordCount, Status
            )
            VALUES (@ControlID, @PeriodStart, @PeriodEnd, @EvidenceData, @RecordCount, @Status);
            
        END TRY
        BEGIN CATCH
            INSERT INTO compliance.EvidenceCollection (
                ControlID, PeriodStart, PeriodEnd, Status, Notes
            )
            VALUES (@ControlID, @PeriodStart, @PeriodEnd, 'Fail', ERROR_MESSAGE());
        END CATCH
        
        FETCH NEXT FROM evidence_cursor INTO @ControlID, @EvidenceQuery;
    END
    
    CLOSE evidence_cursor;
    DEALLOCATE evidence_cursor;
END
GO
```

---

## 21.2 Compliance Dashboard

```sql
CREATE VIEW compliance.vw_ComplianceDashboard AS
WITH ComplianceStatus AS (
    SELECT 
        rf.FrameworkName,
        cr.ControlNumber,
        cr.ControlTitle,
        
        -- Latest evidence
        (SELECT TOP 1 Status 
         FROM compliance.EvidenceCollection ec 
         WHERE ec.ControlID = cr.ControlID 
         ORDER BY ec.CollectionDateTime DESC) AS LatestStatus,
        
        (SELECT TOP 1 CollectionDateTime 
         FROM compliance.EvidenceCollection ec 
         WHERE ec.ControlID = cr.ControlID 
         ORDER BY ec.CollectionDateTime DESC) AS LastCollected,
        
        -- Compliance rate (last 90 days)
        (SELECT COUNT(*) 
         FROM compliance.EvidenceCollection ec 
         WHERE ec.ControlID = cr.ControlID 
           AND ec.Status = 'Pass'
           AND ec.CollectionDateTime >= DATEADD(DAY, -90, GETDATE())) * 100.0 /
        NULLIF((SELECT COUNT(*) 
                FROM compliance.EvidenceCollection ec 
                WHERE ec.ControlID = cr.ControlID 
                  AND ec.CollectionDateTime >= DATEADD(DAY, -90, GETDATE())), 0) AS ComplianceRate_90Days
        
    FROM compliance.ControlRequirements cr
    JOIN compliance.RegulatoryFrameworks rf ON cr.FrameworkID = rf.FrameworkID
    WHERE rf.IsActive = 1
)
SELECT 
    FrameworkName,
    ControlNumber,
    ControlTitle,
    LatestStatus,
    LastCollected,
    ComplianceRate_90Days,
    
    CASE 
        WHEN LatestStatus = 'Pass' AND ComplianceRate_90Days >= 95 THEN 'Compliant'
        WHEN LatestStatus = 'Pass' AND ComplianceRate_90Days >= 85 THEN 'Mostly Compliant'
        WHEN LatestStatus IN ('Fail', 'Exception') THEN 'Non-Compliant'
        ELSE 'Unknown'
    END AS ComplianceStatus,
    
    DATEDIFF(DAY, LastCollected, GETDATE()) AS DaysSinceLastEvidence
FROM ComplianceStatus;
GO
```

---

## 21.3 Audit Reports

### 21.3.1 SOX Compliance Report

```sql
CREATE PROCEDURE compliance.usp_GenerateSOXReport
    @QuarterEndDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @QuarterStart DATE = DATEADD(QUARTER, -1, @QuarterEndDate);
    
    -- Executive Summary
    SELECT 
        'SOX Compliance Report' AS ReportTitle,
        'Q' + CAST(DATEPART(QUARTER, @QuarterEndDate) AS VARCHAR) + ' ' + 
        CAST(YEAR(@QuarterEndDate) AS VARCHAR) AS ReportPeriod,
        @QuarterStart AS PeriodStart,
        @QuarterEndDate AS PeriodEnd,
        GETDATE() AS GeneratedDate;
    
    -- Control effectiveness
    SELECT 
        cr.ControlNumber,
        cr.ControlTitle,
        COUNT(*) AS TestsPerformed,
        SUM(CASE WHEN ec.Status = 'Pass' THEN 1 ELSE 0 END) AS TestsPassed,
        SUM(CASE WHEN ec.Status IN ('Fail', 'Exception') THEN 1 ELSE 0 END) AS TestsFailed,
        CAST(SUM(CASE WHEN ec.Status = 'Pass' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS EffectivenessRate
    FROM compliance.EvidenceCollection ec
    JOIN compliance.ControlRequirements cr ON ec.ControlID = cr.ControlID
    JOIN compliance.RegulatoryFrameworks rf ON cr.FrameworkID = rf.FrameworkID
    WHERE rf.FrameworkType = 'SOX'
      AND ec.CollectionDateTime BETWEEN @QuarterStart AND @QuarterEndDate
    GROUP BY cr.ControlNumber, cr.ControlTitle;
    
    -- Change management evidence
    SELECT 
        ChangeDateTime,
        ServerName,
        ChangeType,
        ChangeDescription,
        ChangedBy,
        ApprovedBy
    FROM log.ConfigurationChanges
    WHERE ChangeDateTime BETWEEN @QuarterStart AND @QuarterEndDate
    ORDER BY ChangeDateTime DESC;
    
    -- Access review evidence
    SELECT 
        ReviewDate,
        ServerName,
        TotalUsers,
        UsersReviewed,
        AccessRevoked,
        ReviewedBy
    FROM security.UserAccessReview
    WHERE ReviewDate BETWEEN @QuarterStart AND @QuarterEndDate;
END
GO
```

---

## 21.4 Case Study: Financial Services Audit

**Background:** SecureBank, SOX compliance requirements, annual audit.

**Challenge:**
- Manual evidence collection (160 hours/audit)
- Incomplete audit trails
- 12-week audit process
- 8 audit findings (previous year)

**After DBAOps Compliance Module:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Evidence Collection** ||||
| Manual hours | 160 hrs | 8 hrs | **95% reduction** |
| Evidence completeness | 78% | 100% | Complete |
| Response time | 3-5 days | < 1 hour | **99% faster** |
| **Audit Process** ||||
| Audit duration | 12 weeks | 4 weeks | **67% faster** |
| Auditor requests | 147 | 23 | **84% fewer** |
| Audit findings | 8 | 0 | **Clean audit** |
| **Compliance** ||||
| Control effectiveness | 82% | 98% | Improved |
| Automated controls | 0% | 95% | Automated |

**Value:** $2.1M (audit cost reduction + clean audit)
**ROI: 2,625%**

---

## Chapter 21 Summary

**Key Takeaways:**
1. Map compliance requirements to DBAOps evidence
2. Automate evidence collection
3. Maintain continuous compliance monitoring
4. Generate audit-ready reports
5. Track compliance metrics over time

**Implementation:**
✅ Regulatory framework mapping
✅ Automated evidence collection
✅ Compliance dashboard
✅ Audit reports (SOX, HIPAA, PCI-DSS)
✅ 95% automation

**Value:**
✅ 95% reduction in manual effort
✅ Clean audit (8 findings → 0)
✅ $2.1M value
✅ ROI: 2,625%

---

*End of Chapter 21*

**Next Chapter:** Chapter 22 - Advanced Scenarios

