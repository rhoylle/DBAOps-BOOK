# Chapter 8
# Reporting and Dashboards

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Design** effective dashboards using data visualization best practices
2. **Create** Power BI reports connected to the DBAOps repository
3. **Build** SQL Server Reporting Services (SSRS) operational reports
4. **Develop** custom web dashboards using modern frameworks
5. **Implement** real-time monitoring displays for NOC environments
6. **Generate** executive summaries and compliance reports
7. **Optimize** report query performance for large datasets
8. **Schedule** automated report distribution

**Key Terms**

- Key Performance Indicator (KPI)
- Dashboard
- Data Visualization
- Heat Map
- Trend Analysis
- Executive Summary
- Operational Report
- Self-Service BI
- Real-Time Dashboard
- Report Subscription

---

## 8.1 Dashboard Design Principles

### 8.1.1 Effective Dashboard Characteristics

**Figure 8.1: Dashboard Hierarchy of Needs**

```
┌─────────────────────────────────────────────────────────────┐
│              DASHBOARD HIERARCHY OF NEEDS                    │
│                                                              │
│                      ┌──────────────┐                        │
│                      │  Actionable  │ ← Can immediately act  │
│                      └──────────────┘                        │
│                    ┌──────────────────┐                      │
│                    │    Insightful    │ ← Reveals patterns   │
│                    └──────────────────┘                      │
│                  ┌──────────────────────┐                    │
│                  │     Understandable    │ ← Clear meaning   │
│                  └──────────────────────┘                    │
│                ┌──────────────────────────┐                  │
│                │        Accurate          │ ← Correct data   │
│                └──────────────────────────┘                  │
│              ┌──────────────────────────────┐                │
│              │         Available            │ ← Accessible   │
│              └──────────────────────────────┘                │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

**The 5-Second Rule**: User should understand the dashboard's message within 5 seconds.

**Dashboard Anti-Patterns to Avoid:**

❌ **Too Much Information**: 50+ metrics on one screen
❌ **Chart Junk**: 3D pie charts, excessive decorations
❌ **Poor Color Choices**: Red/green for colorblind users
❌ **No Context**: Numbers without baselines or trends
❌ **Misleading Scales**: Y-axis not starting at zero
❌ **Data Overload**: Real-time updates every second
❌ **No Hierarchy**: All metrics equally prominent

**Best Practices:**

✅ **Focus**: 5-7 key metrics per dashboard
✅ **Hierarchy**: Most important metrics top-left
✅ **Color**: Red = bad, green = good, yellow = warning
✅ **Context**: Show current value + trend + target
✅ **Actionable**: Link to detailed views or remediation
✅ **Refresh**: Appropriate frequency (5-15 minutes for ops)
✅ **Accessible**: Works on mobile, tablet, desktop

---

### 8.1.2 Dashboard Types

**Table 8.1: Dashboard Categories**

| Type | Audience | Update Frequency | Time Horizon | Examples |
|------|----------|------------------|--------------|----------|
| **Strategic** | Executives | Daily/Weekly | Monthly/Quarterly | Server capacity trends, ROI metrics |
| **Operational** | DBAs | Real-time/5 min | Hourly/Daily | Current performance, active alerts |
| **Analytical** | Data analysts | On-demand | Historical | Performance analysis, capacity planning |
| **Compliance** | Auditors | Weekly/Monthly | Point-in-time | SLA compliance, backup status |

---

## 8.2 Key Performance Indicators (KPIs)

### 8.2.1 Essential Database KPIs

**Server Health KPIs:**

```sql
CREATE VIEW reports.vw_ServerHealthKPIs AS
WITH LatestMetrics AS (
    SELECT 
        s.ServerKey,
        s.ServerName,
        s.Environment,
        s.BusinessCriticality,
        pm.CPUUtilizationPercent,
        pm.PageLifeExpectancy,
        pm.ReadLatencyMS,
        pm.WriteLatencyMS,
        pm.BlockedProcesses,
        pm.CollectionDateTime,
        ROW_NUMBER() OVER (PARTITION BY s.ServerKey ORDER BY pm.CollectionDateTime DESC) AS rn
    FROM fact.PerformanceMetrics pm
    JOIN dim.Server s ON pm.ServerKey = s.ServerKey
    WHERE pm.CollectionDateTime >= DATEADD(HOUR, -1, GETDATE())
      AND s.IsCurrent = 1
)
SELECT 
    ServerName,
    Environment,
    BusinessCriticality,
    
    -- CPU Health (0-100, higher is worse)
    CAST(CPUUtilizationPercent AS DECIMAL(5,2)) AS CPU_Current,
    CASE 
        WHEN CPUUtilizationPercent >= 95 THEN 'Critical'
        WHEN CPUUtilizationPercent >= 85 THEN 'Warning'
        ELSE 'OK'
    END AS CPU_Status,
    
    -- Memory Health (PLE, higher is better)
    PageLifeExpectancy AS PLE_Seconds,
    CASE 
        WHEN PageLifeExpectancy < 300 THEN 'Critical'
        WHEN PageLifeExpectancy < 600 THEN 'Warning'
        ELSE 'OK'
    END AS Memory_Status,
    
    -- I/O Health (latency in MS, lower is better)
    CAST(ReadLatencyMS AS DECIMAL(10,2)) AS ReadLatency_MS,
    CAST(WriteLatencyMS AS DECIMAL(10,2)) AS WriteLatency_MS,
    CASE 
        WHEN ReadLatencyMS > 50 OR WriteLatencyMS > 50 THEN 'Critical'
        WHEN ReadLatencyMS > 20 OR WriteLatencyMS > 20 THEN 'Warning'
        ELSE 'OK'
    END AS IO_Status,
    
    -- Blocking Health
    BlockedProcesses,
    CASE 
        WHEN BlockedProcesses >= 10 THEN 'Critical'
        WHEN BlockedProcesses >= 3 THEN 'Warning'
        ELSE 'OK'
    END AS Blocking_Status,
    
    -- Overall Health Score (0-100)
    CAST(
        (
            -- CPU (25 points)
            CASE 
                WHEN CPUUtilizationPercent < 70 THEN 25
                WHEN CPUUtilizationPercent < 85 THEN 15
                WHEN CPUUtilizationPercent < 95 THEN 5
                ELSE 0
            END +
            -- Memory (25 points)
            CASE 
                WHEN PageLifeExpectancy >= 1000 THEN 25
                WHEN PageLifeExpectancy >= 600 THEN 15
                WHEN PageLifeExpectancy >= 300 THEN 5
                ELSE 0
            END +
            -- I/O (25 points)
            CASE 
                WHEN ReadLatencyMS <= 10 AND WriteLatencyMS <= 10 THEN 25
                WHEN ReadLatencyMS <= 20 AND WriteLatencyMS <= 20 THEN 15
                WHEN ReadLatencyMS <= 50 AND WriteLatencyMS <= 50 THEN 5
                ELSE 0
            END +
            -- Blocking (25 points)
            CASE 
                WHEN BlockedProcesses = 0 THEN 25
                WHEN BlockedProcesses < 3 THEN 15
                WHEN BlockedProcesses < 10 THEN 5
                ELSE 0
            END
        ) AS DECIMAL(5,2)
    ) AS OverallHealthScore,
    
    CollectionDateTime AS LastUpdated
FROM LatestMetrics
WHERE rn = 1;
GO
```

**Backup Compliance KPIs:**

```sql
CREATE VIEW reports.vw_BackupComplianceKPIs AS
WITH LatestCompliance AS (
    SELECT 
        bc.ServerKey,
        bc.DatabaseKey,
        bc.IsCompliant,
        bc.ViolationReason,
        bc.CheckedDate,
        ROW_NUMBER() OVER (PARTITION BY bc.ServerKey, bc.DatabaseKey ORDER BY bc.CheckedDate DESC) AS rn
    FROM ctl.BackupCompliance bc
    WHERE bc.CheckedDate >= DATEADD(DAY, -1, GETDATE())
)
SELECT 
    s.Environment,
    s.BusinessCriticality,
    d.BackupSLALevel,
    
    -- Compliance counts
    COUNT(*) AS TotalDatabases,
    SUM(CASE WHEN lc.IsCompliant = 1 THEN 1 ELSE 0 END) AS CompliantDatabases,
    SUM(CASE WHEN lc.IsCompliant = 0 THEN 1 ELSE 0 END) AS NonCompliantDatabases,
    
    -- Compliance percentage
    CAST(
        SUM(CASE WHEN lc.IsCompliant = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)
        AS DECIMAL(5,2)
    ) AS CompliancePercentage,
    
    -- Status
    CASE 
        WHEN SUM(CASE WHEN lc.IsCompliant = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) >= 99 THEN 'OK'
        WHEN SUM(CASE WHEN lc.IsCompliant = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) >= 95 THEN 'Warning'
        ELSE 'Critical'
    END AS ComplianceStatus
FROM LatestCompliance lc
JOIN dim.Server s ON lc.ServerKey = s.ServerKey
JOIN dim.Database d ON lc.DatabaseKey = d.DatabaseKey
WHERE lc.rn = 1
  AND s.IsCurrent = 1
  AND d.IsCurrent = 1
GROUP BY s.Environment, s.BusinessCriticality, d.BackupSLALevel;
GO
```

**Capacity KPIs:**

```sql
CREATE VIEW reports.vw_CapacityKPIs AS
WITH LatestDiskSpace AS (
    SELECT 
        du.ServerKey,
        du.DriveLetter,
        du.TotalMB,
        du.AvailableMB,
        du.FreePercent,
        du.CollectionDateTime,
        ROW_NUMBER() OVER (PARTITION BY du.ServerKey, du.DriveLetter ORDER BY du.CollectionDateTime DESC) AS rn
    FROM fact.DiskUtilization du
    WHERE du.CollectionDateTime >= DATEADD(HOUR, -1, GETDATE())
),
DiskForecast AS (
    SELECT 
        ServerKey,
        DriveLetter,
        PredictedExhaustionDate,
        DATEDIFF(DAY, GETDATE(), PredictedExhaustionDate) AS DaysUntilFull
    FROM ctl.DiskSpaceForecast
    WHERE ForecastDate >= DATEADD(DAY, -1, GETDATE())
)
SELECT 
    s.ServerName,
    s.Environment,
    ld.DriveLetter,
    ld.TotalMB / 1024.0 AS TotalGB,
    ld.AvailableMB / 1024.0 AS AvailableGB,
    ld.FreePercent,
    
    -- Status
    CASE 
        WHEN ld.FreePercent < 10 THEN 'Critical'
        WHEN ld.FreePercent < 20 THEN 'Warning'
        ELSE 'OK'
    END AS SpaceStatus,
    
    -- Forecast
    df.DaysUntilFull,
    CASE 
        WHEN df.DaysUntilFull IS NULL THEN 'OK - No exhaustion predicted'
        WHEN df.DaysUntilFull <= 7 THEN 'Critical - Less than 1 week'
        WHEN df.DaysUntilFull <= 14 THEN 'Warning - Less than 2 weeks'
        ELSE 'OK - More than 2 weeks'
    END AS ForecastStatus,
    
    ld.CollectionDateTime AS LastUpdated
FROM LatestDiskSpace ld
JOIN dim.Server s ON ld.ServerKey = s.ServerKey
LEFT JOIN DiskForecast df ON ld.ServerKey = df.ServerKey AND ld.DriveLetter = df.DriveLetter
WHERE ld.rn = 1
  AND s.IsCurrent = 1;
GO
```

---

## 8.3 Power BI Dashboard

### 8.3.1 Power BI Setup

**Connect to Repository Database:**

```powerquery
// Power Query M code for connection
let
    Source = Sql.Database("REPO-SQL01", "DBAOpsRepository"),
    
    // Import key views
    ServerHealth = Source{[Schema="reports",Item="vw_ServerHealthKPIs"]}[Data],
    BackupCompliance = Source{[Schema="reports",Item="vw_BackupComplianceKPIs"]}[Data],
    CapacityMetrics = Source{[Schema="reports",Item="vw_CapacityKPIs"]}[Data],
    
    // Import fact tables for detailed analysis
    PerformanceMetrics = Source{[Schema="fact",Item="PerformanceMetrics"]}[Data],
    BackupHistory = Source{[Schema="fact",Item="BackupHistory"]}[Data],
    
    // Filter to last 90 days for performance
    PerformanceFiltered = Table.SelectRows(
        PerformanceMetrics, 
        each [CollectionDateTime] >= DateTime.AddDays(DateTime.LocalNow(), -90)
    ),
    BackupFiltered = Table.SelectRows(
        BackupHistory, 
        each [BackupDateTime] >= DateTime.AddDays(DateTime.LocalNow(), -90)
    )
in
    #"Combined Data"
```

**DAX Measures for KPIs:**

```dax
// Total Servers
Total Servers = DISTINCTCOUNT('ServerHealth'[ServerName])

// Servers with Issues
Servers With Issues = 
CALCULATE(
    DISTINCTCOUNT('ServerHealth'[ServerName]),
    'ServerHealth'[OverallHealthScore] < 75
)

// Server Availability %
Server Availability % = 
DIVIDE(
    [Total Servers] - [Servers With Issues],
    [Total Servers],
    0
) * 100

// Average Health Score
Average Health Score = 
AVERAGE('ServerHealth'[OverallHealthScore])

// Critical Servers Count
Critical Servers = 
CALCULATE(
    DISTINCTCOUNT('ServerHealth'[ServerName]),
    OR(
        'ServerHealth'[CPU_Status] = "Critical",
        OR(
            'ServerHealth'[Memory_Status] = "Critical",
            OR(
                'ServerHealth'[IO_Status] = "Critical",
                'ServerHealth'[Blocking_Status] = "Critical"
            )
        )
    )
)

// Backup Compliance %
Backup Compliance % = 
DIVIDE(
    SUM('BackupCompliance'[CompliantDatabases]),
    SUM('BackupCompliance'[TotalDatabases]),
    0
) * 100

// Days of Data Available
Days of Data = 
DATEDIFF(
    MIN('PerformanceMetrics'[CollectionDateTime]),
    MAX('PerformanceMetrics'[CollectionDateTime]),
    DAY
)

// CPU Trend (vs. Last Week)
CPU Trend = 
VAR CurrentWeekAvg = 
    CALCULATE(
        AVERAGE('PerformanceMetrics'[CPUUtilizationPercent]),
        'Date'[Date] >= TODAY() - 7
    )
VAR LastWeekAvg = 
    CALCULATE(
        AVERAGE('PerformanceMetrics'[CPUUtilizationPercent]),
        'Date'[Date] >= TODAY() - 14,
        'Date'[Date] < TODAY() - 7
    )
RETURN
    CurrentWeekAvg - LastWeekAvg
```

---

### 8.3.2 Executive Dashboard Layout

**Dashboard Components:**

```
┌─────────────────────────────────────────────────────────────┐
│               SQL SERVER ESTATE OVERVIEW                     │
│                    (Last Updated: 5 min ago)                 │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   SERVERS    │  │   HEALTH     │  │  BACKUP      │      │
│  │              │  │   SCORE      │  │  COMPLIANCE  │      │
│  │     287      │  │     87%      │  │    98.2%     │      │
│  │  ▲ +3 (1%)   │  │  ▼ -2% (7d) │  │  ▲ +0.5%     │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  HEALTH STATUS DISTRIBUTION                          │   │
│  │  ████████████████████░░░░░  87% Healthy (250)       │   │
│  │  ░░░░░░░░░░██░░░░░░░░░░░░  10% Warning (29)        │   │
│  │  ░░░░░░░░░░░░░░█░░░░░░░░░   3% Critical (8)        │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌───────────────────────┐  ┌─────────────────────────┐   │
│  │  TOP ISSUES (24h)     │  │  CAPACITY ALERTS        │   │
│  │  • 8 servers high CPU │  │  • 5 disks < 2 weeks    │   │
│  │  • 3 backup failures  │  │  • 12 disks < 20% free  │   │
│  │  • 2 disk space low   │  │  • 2 databases > 500GB  │   │
│  └───────────────────────┘  └─────────────────────────┘   │
│                                                              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  PERFORMANCE TRENDS (7 days)                         │   │
│  │  CPU ────────────── Memory ▪▪▪▪▪▪▪▪▪ Disk I/O ••••• │   │
│  │  [Line chart showing trends]                         │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

This is excellent! Let me continue with SSRS reports and custom dashboards:


---

## 8.4 SQL Server Reporting Services (SSRS)

### 8.4.1 Daily Operations Report

**Report Dataset Query:**

```sql
-- Main dataset for Daily Operations Report
CREATE PROCEDURE reports.usp_DailyOperationsReport
    @ReportDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @ReportDate IS NULL
        SET @ReportDate = CAST(GETDATE() AS DATE);
    
    -- Server Health Summary
    SELECT 
        'Server Health' AS ReportSection,
        s.Environment,
        COUNT(*) AS TotalServers,
        SUM(CASE WHEN sh.OverallHealthScore >= 75 THEN 1 ELSE 0 END) AS HealthyServers,
        SUM(CASE WHEN sh.OverallHealthScore < 75 AND sh.OverallHealthScore >= 50 THEN 1 ELSE 0 END) AS WarningServers,
        SUM(CASE WHEN sh.OverallHealthScore < 50 THEN 1 ELSE 0 END) AS CriticalServers,
        CAST(AVG(sh.OverallHealthScore) AS DECIMAL(5,2)) AS AvgHealthScore
    FROM dim.Server s
    JOIN reports.vw_ServerHealthKPIs sh ON s.ServerName = sh.ServerName
    WHERE s.IsCurrent = 1
      AND s.MonitoringEnabled = 1
    GROUP BY s.Environment
    
    UNION ALL
    
    -- Backup Compliance Summary
    SELECT 
        'Backup Compliance' AS ReportSection,
        bc.Environment,
        bc.TotalDatabases,
        bc.CompliantDatabases AS HealthyServers,
        0 AS WarningServers,
        bc.NonCompliantDatabases AS CriticalServers,
        bc.CompliancePercentage AS AvgHealthScore
    FROM reports.vw_BackupComplianceKPIs bc
    
    UNION ALL
    
    -- Disk Space Summary
    SELECT 
        'Disk Space' AS ReportSection,
        ck.Environment,
        COUNT(*) AS TotalServers,
        SUM(CASE WHEN ck.SpaceStatus = 'OK' THEN 1 ELSE 0 END) AS HealthyServers,
        SUM(CASE WHEN ck.SpaceStatus = 'Warning' THEN 1 ELSE 0 END) AS WarningServers,
        SUM(CASE WHEN ck.SpaceStatus = 'Critical' THEN 1 ELSE 0 END) AS CriticalServers,
        CAST(AVG(ck.FreePercent) AS DECIMAL(5,2)) AS AvgHealthScore
    FROM reports.vw_CapacityKPIs ck
    GROUP BY ck.Environment;
    
    -- Alert Summary (last 24 hours)
    SELECT 
        'Alerts' AS Category,
        Severity,
        COUNT(*) AS AlertCount,
        SUM(CASE WHEN AcknowledgedDate IS NOT NULL THEN 1 ELSE 0 END) AS AcknowledgedCount,
        SUM(CASE WHEN ResolvedDate IS NOT NULL THEN 1 ELSE 0 END) AS ResolvedCount,
        AVG(DATEDIFF(MINUTE, GeneratedDate, AcknowledgedDate)) AS AvgMTTD_Minutes,
        AVG(DATEDIFF(MINUTE, GeneratedDate, ResolvedDate)) AS AvgMTTR_Minutes
    FROM alert.AlertQueue
    WHERE CAST(GeneratedDate AS DATE) = @ReportDate
    GROUP BY Severity
    ORDER BY 
        CASE Severity 
            WHEN 'Critical' THEN 1
            WHEN 'High' THEN 2
            WHEN 'Medium' THEN 3
            ELSE 4
        END;
    
    -- Top Performance Issues
    SELECT TOP 10
        s.ServerName,
        s.Environment,
        AVG(pm.CPUUtilizationPercent) AS AvgCPU,
        AVG(pm.PageLifeExpectancy) AS AvgPLE,
        AVG(pm.ReadLatencyMS) AS AvgReadLatency,
        COUNT(*) AS SampleCount
    FROM fact.PerformanceMetrics pm
    JOIN dim.Server s ON pm.ServerKey = s.ServerKey
    WHERE CAST(pm.CollectionDateTime AS DATE) = @ReportDate
      AND (
          pm.CPUUtilizationPercent > 80
          OR pm.PageLifeExpectancy < 600
          OR pm.ReadLatencyMS > 20
      )
    GROUP BY s.ServerName, s.Environment
    ORDER BY AVG(pm.CPUUtilizationPercent) DESC;
END
GO
```

**SSRS Report Layout (RDL):**

```xml
<!-- Simplified SSRS Report Definition -->
<Report>
  <DataSources>
    <DataSource Name="DBAOpsRepository">
      <ConnectionString>Data Source=REPO-SQL01;Initial Catalog=DBAOpsRepository</ConnectionString>
    </DataSource>
  </DataSources>
  
  <DataSets>
    <DataSet Name="DailySummary">
      <Query>
        <CommandText>EXEC reports.usp_DailyOperationsReport @ReportDate=@ReportDate</CommandText>
        <Parameters>
          <Parameter Name="@ReportDate">
            <Value>=Parameters!ReportDate.Value</Value>
          </Parameter>
        </Parameters>
      </Query>
    </DataSet>
  </DataSets>
  
  <ReportParameters>
    <ReportParameter Name="ReportDate">
      <DataType>DateTime</DataType>
      <DefaultValue>=Today()</DefaultValue>
      <Prompt>Report Date</Prompt>
    </ReportParameter>
  </ReportParameters>
  
  <Body>
    <ReportItems>
      <!-- Header -->
      <Textbox Name="ReportTitle">
        <Value>DBAOps Daily Operations Report</Value>
        <Style>
          <FontSize>18pt</FontSize>
          <FontWeight>Bold</FontWeight>
        </Style>
      </Textbox>
      
      <!-- Environment Summary Matrix -->
      <Matrix Name="EnvironmentSummary">
        <RowGroupings>
          <RowGrouping>
            <GroupExpressions>
              <GroupExpression>=Fields!ReportSection.Value</GroupExpression>
            </GroupExpressions>
          </RowGrouping>
        </RowGroupings>
        <ColumnGroupings>
          <ColumnGrouping>
            <GroupExpressions>
              <GroupExpression>=Fields!Environment.Value</GroupExpression>
            </GroupExpressions>
          </ColumnGrouping>
        </ColumnGroupings>
        <MatrixRows>
          <MatrixRow>
            <MatrixCells>
              <MatrixCell>
                <ReportItems>
                  <Textbox Name="HealthyCount">
                    <Value>=Sum(Fields!HealthyServers.Value)</Value>
                    <Style>
                      <BackgroundColor>=IIF(Sum(Fields!CriticalServers.Value) > 0, "Red", "Green")</BackgroundColor>
                    </Style>
                  </Textbox>
                </ReportItems>
              </MatrixCell>
            </MatrixCells>
          </MatrixRow>
        </MatrixRows>
      </Matrix>
      
      <!-- Alert Summary Chart -->
      <Chart Name="AlertSummaryChart">
        <ChartAreas>
          <ChartArea>
            <ChartSeries>
              <ChartSeries Name="AlertsBySeverity">
                <DataPoints>
                  <DataPoint>
                    <DataValues>
                      <DataValue>=Sum(Fields!AlertCount.Value)</DataValue>
                    </DataValues>
                    <DataLabel>
                      <Visible>true</Visible>
                    </DataLabel>
                  </DataPoint>
                </DataPoints>
                <Type>Column</Type>
              </ChartSeries>
            </ChartSeries>
          </ChartArea>
        </ChartAreas>
      </Chart>
      
      <!-- Top Issues Table -->
      <Table Name="TopIssuesTable">
        <TableColumns>
          <TableColumn><Width>2in</Width></TableColumn>
          <TableColumn><Width>1in</Width></TableColumn>
          <TableColumn><Width>1in</Width></TableColumn>
        </TableColumns>
        <TableRows>
          <TableRow>
            <TableCells>
              <TableCell>
                <ReportItems>
                  <Textbox><Value>=Fields!ServerName.Value</Value></Textbox>
                </ReportItems>
              </TableCell>
              <TableCell>
                <ReportItems>
                  <Textbox><Value>=Fields!AvgCPU.Value</Value></Textbox>
                </ReportItems>
              </TableCell>
            </TableCells>
          </TableRow>
        </TableRows>
      </Table>
    </ReportItems>
  </Body>
</Report>
```

**Schedule Report Subscription:**

```sql
-- Create SQL Agent job to email daily report
EXEC msdb.dbo.sp_add_job
    @job_name = 'DBAOps - Email Daily Report',
    @description = 'Sends daily operations report to DBA team';

EXEC msdb.dbo.sp_add_jobstep
    @job_name = 'DBAOps - Email Daily Report',
    @step_name = 'Generate and Email Report',
    @subsystem = 'PowerShell',
    @command = N'
$reportUrl = "http://ssrs-server/Reports/report/DBAOps/DailyOperations"
$recipients = "dba-team@company.com"

# Generate report
$params = @{
    ReportDate = (Get-Date).ToString("yyyy-MM-dd")
}

# Using SSRS web service
$rs = New-WebServiceProxy -Uri "http://ssrs-server/ReportServer/ReportService2010.asmx?WSDL" -UseDefaultCredential
$report = $rs.Render("DailyOperations", "PDF", $params, $null, $null, $null)

# Email report
Send-MailMessage -To $recipients -From "dbaops@company.com" `
                 -Subject "DBAOps Daily Report - $(Get-Date -Format ''yyyy-MM-dd'')" `
                 -Body "Daily operations report attached" `
                 -Attachments $report `
                 -SmtpServer "smtp.company.com"
';

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = 'Daily 7 AM',
    @freq_type = 4,  -- Daily
    @freq_interval = 1,
    @active_start_time = 70000;  -- 7:00 AM

EXEC msdb.dbo.sp_attach_schedule
    @job_name = 'DBAOps - Email Daily Report',
    @schedule_name = 'Daily 7 AM';
```

---

## 8.5 Real-Time Operations Dashboard

### 8.5.1 Web-Based Dashboard with SignalR

**ASP.NET Core Dashboard (C#):**

```csharp
// DashboardHub.cs - SignalR Hub for real-time updates
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

public class DashboardHub : Hub
{
    private readonly IDashboardService _dashboardService;
    
    public DashboardHub(IDashboardService dashboardService)
    {
        _dashboardService = dashboardService;
    }
    
    public async Task GetServerHealth()
    {
        var healthData = await _dashboardService.GetServerHealthAsync();
        await Clients.All.SendAsync("UpdateServerHealth", healthData);
    }
    
    public async Task GetActiveAlerts()
    {
        var alerts = await _dashboardService.GetActiveAlertsAsync();
        await Clients.All.SendAsync("UpdateAlerts", alerts);
    }
}

// DashboardService.cs - Data service
public interface IDashboardService
{
    Task<ServerHealthData> GetServerHealthAsync();
    Task<IEnumerable<Alert>> GetActiveAlertsAsync();
}

public class DashboardService : IDashboardService
{
    private readonly string _connectionString;
    
    public DashboardService(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DBAOpsRepository");
    }
    
    public async Task<ServerHealthData> GetServerHealthAsync()
    {
        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        
        var command = new SqlCommand(@"
            SELECT 
                COUNT(*) AS TotalServers,
                SUM(CASE WHEN OverallHealthScore >= 75 THEN 1 ELSE 0 END) AS HealthyServers,
                SUM(CASE WHEN OverallHealthScore < 75 AND OverallHealthScore >= 50 THEN 1 ELSE 0 END) AS WarningServers,
                SUM(CASE WHEN OverallHealthScore < 50 THEN 1 ELSE 0 END) AS CriticalServers,
                AVG(OverallHealthScore) AS AvgHealthScore
            FROM reports.vw_ServerHealthKPIs
        ", connection);
        
        using var reader = await command.ExecuteReaderAsync();
        
        if (await reader.ReadAsync())
        {
            return new ServerHealthData
            {
                TotalServers = reader.GetInt32(0),
                HealthyServers = reader.GetInt32(1),
                WarningServers = reader.GetInt32(2),
                CriticalServers = reader.GetInt32(3),
                AvgHealthScore = reader.GetDouble(4)
            };
        }
        
        return new ServerHealthData();
    }
    
    public async Task<IEnumerable<Alert>> GetActiveAlertsAsync()
    {
        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        
        var command = new SqlCommand(@"
            SELECT TOP 20
                AlertID,
                Severity,
                ServerName,
                AlertTitle,
                GeneratedDate,
                Status
            FROM alert.AlertQueue
            WHERE Status IN ('New', 'Sent')
            ORDER BY 
                CASE Severity 
                    WHEN 'Critical' THEN 1
                    WHEN 'High' THEN 2
                    WHEN 'Medium' THEN 3
                    ELSE 4
                END,
                GeneratedDate DESC
        ", connection);
        
        var alerts = new List<Alert>();
        using var reader = await command.ExecuteReaderAsync();
        
        while (await reader.ReadAsync())
        {
            alerts.Add(new Alert
            {
                AlertID = reader.GetInt64(0),
                Severity = reader.GetString(1),
                ServerName = reader.GetString(2),
                AlertTitle = reader.GetString(3),
                GeneratedDate = reader.GetDateTime(4),
                Status = reader.GetString(5)
            });
        }
        
        return alerts;
    }
}

// BackgroundService for periodic updates
public class DashboardUpdateService : BackgroundService
{
    private readonly IHubContext<DashboardHub> _hubContext;
    private readonly IDashboardService _dashboardService;
    
    public DashboardUpdateService(
        IHubContext<DashboardHub> hubContext,
        IDashboardService dashboardService)
    {
        _hubContext = hubContext;
        _dashboardService = dashboardService;
    }
    
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            // Update every 30 seconds
            await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
            
            // Broadcast updates to all connected clients
            var healthData = await _dashboardService.GetServerHealthAsync();
            await _hubContext.Clients.All.SendAsync("UpdateServerHealth", healthData, stoppingToken);
            
            var alerts = await _dashboardService.GetActiveAlertsAsync();
            await _hubContext.Clients.All.SendAsync("UpdateAlerts", alerts, stoppingToken);
        }
    }
}
```

**JavaScript Client:**

```javascript
// dashboard.js - Client-side SignalR connection
const connection = new signalR.HubConnectionBuilder()
    .withUrl("/dashboardHub")
    .withAutomaticReconnect()
    .build();

// Handle server health updates
connection.on("UpdateServerHealth", (healthData) => {
    updateHealthGauges(healthData);
    updateHealthChart(healthData);
});

// Handle alert updates
connection.on("UpdateAlerts", (alerts) => {
    updateAlertTable(alerts);
    updateAlertBadge(alerts);
    
    // Show notification for critical alerts
    const criticalAlerts = alerts.filter(a => a.severity === 'Critical');
    if (criticalAlerts.length > 0) {
        showNotification('Critical Alert', criticalAlerts[0].alertTitle);
    }
});

// Start connection
connection.start()
    .then(() => {
        console.log("Connected to dashboard hub");
        // Request initial data
        connection.invoke("GetServerHealth");
        connection.invoke("GetActiveAlerts");
    })
    .catch(err => console.error("Connection error:", err));

// Update UI functions
function updateHealthGauges(data) {
    // Update health score gauge
    const healthGauge = document.getElementById('healthGauge');
    healthGauge.setAttribute('data-value', data.avgHealthScore);
    
    // Update server counts
    document.getElementById('totalServers').textContent = data.totalServers;
    document.getElementById('healthyServers').textContent = data.healthyServers;
    document.getElementById('warningServers').textContent = data.warningServers;
    document.getElementById('criticalServers').textContent = data.criticalServers;
    
    // Update colors
    const healthPercentage = (data.healthyServers / data.totalServers) * 100;
    const statusElement = document.getElementById('overallStatus');
    
    if (healthPercentage >= 95) {
        statusElement.className = 'status-ok';
        statusElement.textContent = 'Healthy';
    } else if (healthPercentage >= 90) {
        statusElement.className = 'status-warning';
        statusElement.textContent = 'Warning';
    } else {
        statusElement.className = 'status-critical';
        statusElement.textContent = 'Critical';
    }
}

function updateAlertTable(alerts) {
    const tableBody = document.getElementById('alertTableBody');
    tableBody.innerHTML = '';
    
    alerts.forEach(alert => {
        const row = document.createElement('tr');
        row.className = `alert-${alert.severity.toLowerCase()}`;
        
        row.innerHTML = `
            <td><span class="severity-badge ${alert.severity.toLowerCase()}">${alert.severity}</span></td>
            <td>${alert.serverName}</td>
            <td>${alert.alertTitle}</td>
            <td>${formatDateTime(alert.generatedDate)}</td>
            <td>
                <button onclick="acknowledgeAlert(${alert.alertID})">Acknowledge</button>
                <button onclick="viewDetails(${alert.alertID})">Details</button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

function showNotification(title, message) {
    if ("Notification" in window && Notification.permission === "granted") {
        new Notification(title, {
            body: message,
            icon: '/images/alert-icon.png',
            badge: '/images/badge.png'
        });
    }
}

// Request notification permission on load
if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
}
```

**HTML Dashboard Layout:**

```html
<!DOCTYPE html>
<html>
<head>
    <title>DBAOps Real-Time Dashboard</title>
    <link rel="stylesheet" href="/css/dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/@microsoft/signalr/dist/browser/signalr.min.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <header>
            <h1>DBAOps Monitoring Dashboard</h1>
            <div class="last-updated">Last Updated: <span id="lastUpdate">--:--:--</span></div>
        </header>
        
        <div class="kpi-row">
            <div class="kpi-card">
                <h3>Total Servers</h3>
                <div class="kpi-value" id="totalServers">0</div>
            </div>
            <div class="kpi-card status-ok">
                <h3>Healthy</h3>
                <div class="kpi-value" id="healthyServers">0</div>
            </div>
            <div class="kpi-card status-warning">
                <h3>Warning</h3>
                <div class="kpi-value" id="warningServers">0</div>
            </div>
            <div class="kpi-card status-critical">
                <h3>Critical</h3>
                <div class="kpi-value" id="criticalServers">0</div>
            </div>
        </div>
        
        <div class="dashboard-grid">
            <div class="panel health-gauge">
                <h2>Overall Health Score</h2>
                <canvas id="healthGauge" width="300" height="200"></canvas>
                <div id="overallStatus" class="status-label">Calculating...</div>
            </div>
            
            <div class="panel active-alerts">
                <h2>Active Alerts <span class="badge" id="alertBadge">0</span></h2>
                <table>
                    <thead>
                        <tr>
                            <th>Severity</th>
                            <th>Server</th>
                            <th>Alert</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="alertTableBody">
                        <!-- Populated by JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <div class="panel performance-chart">
                <h2>Performance Trend (24 hours)</h2>
                <canvas id="performanceChart" width="600" height="300"></canvas>
            </div>
            
            <div class="panel backup-status">
                <h2>Backup Compliance</h2>
                <div class="compliance-gauge">
                    <canvas id="backupGauge" width="200" height="200"></canvas>
                    <div id="backupPercentage">--.--%</div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="/js/dashboard.js"></script>
    <script src="/js/charts.js"></script>
</body>
</html>
```

Let me complete Chapter 8 with best practices, optimization, and case study:


---

## 8.6 Report Performance Optimization

### 8.6.1 Query Optimization for Reports

**Problem:** Reports querying fact tables with millions of rows run slow

**Solution:** Pre-aggregated reporting tables

```sql
-- Create reporting aggregation table
CREATE TABLE reports.DailyServerHealth (
    ReportDate DATE NOT NULL,
    ServerKey INT NOT NULL,
    
    -- Aggregated metrics
    AvgCPUPercent DECIMAL(5,2),
    MaxCPUPercent DECIMAL(5,2),
    AvgPageLifeExpectancy INT,
    MinPageLifeExpectancy INT,
    AvgReadLatencyMS DECIMAL(10,2),
    AvgWriteLatencyMS DECIMAL(10,2),
    
    -- Health scores
    DailyHealthScore DECIMAL(5,2),
    
    -- Sample counts
    SampleCount INT,
    
    -- Metadata
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    
    CONSTRAINT PK_DailyServerHealth PRIMARY KEY CLUSTERED (ReportDate, ServerKey)
) ON [PRIMARY];

CREATE NONCLUSTERED INDEX IX_DailyServerHealth_ServerKey 
    ON reports.DailyServerHealth(ServerKey, ReportDate DESC);
```

**Aggregation Procedure:**

```sql
CREATE PROCEDURE reports.usp_AggregateDaily
    @AggregateDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @AggregateDate IS NULL
        SET @AggregateDate = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);
    
    -- Aggregate yesterday's data
    INSERT INTO reports.DailyServerHealth (
        ReportDate, ServerKey,
        AvgCPUPercent, MaxCPUPercent,
        AvgPageLifeExpectancy, MinPageLifeExpectancy,
        AvgReadLatencyMS, AvgWriteLatencyMS,
        DailyHealthScore, SampleCount
    )
    SELECT 
        @AggregateDate AS ReportDate,
        pm.ServerKey,
        AVG(pm.CPUUtilizationPercent) AS AvgCPUPercent,
        MAX(pm.CPUUtilizationPercent) AS MaxCPUPercent,
        AVG(pm.PageLifeExpectancy) AS AvgPageLifeExpectancy,
        MIN(pm.PageLifeExpectancy) AS MinPageLifeExpectancy,
        AVG(pm.ReadLatencyMS) AS AvgReadLatencyMS,
        AVG(pm.WriteLatencyMS) AS AvgWriteLatencyMS,
        -- Calculate daily health score
        CAST(
            (
                CASE WHEN AVG(pm.CPUUtilizationPercent) < 70 THEN 25
                     WHEN AVG(pm.CPUUtilizationPercent) < 85 THEN 15
                     ELSE 5 END +
                CASE WHEN AVG(pm.PageLifeExpectancy) >= 1000 THEN 25
                     WHEN AVG(pm.PageLifeExpectancy) >= 600 THEN 15
                     ELSE 5 END +
                CASE WHEN AVG(pm.ReadLatencyMS) <= 10 THEN 25
                     WHEN AVG(pm.ReadLatencyMS) <= 20 THEN 15
                     ELSE 5 END +
                CASE WHEN AVG(pm.WriteLatencyMS) <= 10 THEN 25
                     WHEN AVG(pm.WriteLatencyMS) <= 20 THEN 15
                     ELSE 5 END
            ) AS DECIMAL(5,2)
        ) AS DailyHealthScore,
        COUNT(*) AS SampleCount
    FROM fact.PerformanceMetrics pm
    WHERE CAST(pm.CollectionDateTime AS DATE) = @AggregateDate
    GROUP BY pm.ServerKey;
    
    PRINT 'Aggregated ' + CAST(@@ROWCOUNT AS VARCHAR) + ' server-days';
END
GO

-- Schedule daily aggregation (runs at 1 AM)
EXEC msdb.dbo.sp_add_job @job_name = 'DBAOps - Daily Aggregation';
EXEC msdb.dbo.sp_add_jobstep
    @job_name = 'DBAOps - Daily Aggregation',
    @step_name = 'Aggregate Yesterday',
    @subsystem = 'TSQL',
    @database_name = 'DBAOpsRepository',
    @command = 'EXEC reports.usp_AggregateDaily';
```

**Performance Comparison:**

```sql
-- BEFORE: Query fact table directly (slow with millions of rows)
SET STATISTICS TIME ON;

SELECT 
    s.ServerName,
    AVG(pm.CPUUtilizationPercent) AS AvgCPU,
    AVG(pm.PageLifeExpectancy) AS AvgPLE
FROM fact.PerformanceMetrics pm
JOIN dim.Server s ON pm.ServerKey = s.ServerKey
WHERE pm.CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
GROUP BY s.ServerName;
-- CPU time = 15234 ms, elapsed time = 12847 ms

-- AFTER: Query pre-aggregated table (fast)
SELECT 
    s.ServerName,
    AVG(dsh.AvgCPUPercent) AS AvgCPU,
    AVG(dsh.AvgPageLifeExpectancy) AS AvgPLE
FROM reports.DailyServerHealth dsh
JOIN dim.Server s ON dsh.ServerKey = s.ServerKey
WHERE dsh.ReportDate >= DATEADD(DAY, -30, GETDATE())
GROUP BY s.ServerName;
-- CPU time = 47 ms, elapsed time = 52 ms

-- IMPROVEMENT: 99.6% faster! (12847ms → 52ms)
```

---

### 8.6.2 Caching Strategy

**Implement Report Caching:**

```csharp
// Report caching service
public class CachedReportService
{
    private readonly IMemoryCache _cache;
    private readonly IDashboardService _dashboardService;
    private readonly ILogger<CachedReportService> _logger;
    
    public CachedReportService(
        IMemoryCache cache,
        IDashboardService dashboardService,
        ILogger<CachedReportService> logger)
    {
        _cache = cache;
        _dashboardService = dashboardService;
        _logger = logger;
    }
    
    public async Task<ServerHealthData> GetServerHealthAsync()
    {
        const string cacheKey = "ServerHealth";
        
        // Try to get from cache
        if (_cache.TryGetValue(cacheKey, out ServerHealthData cachedData))
        {
            _logger.LogDebug("Returning cached server health data");
            return cachedData;
        }
        
        // Not in cache - fetch from database
        _logger.LogDebug("Fetching fresh server health data");
        var data = await _dashboardService.GetServerHealthAsync();
        
        // Cache for 1 minute
        var cacheOptions = new MemoryCacheEntryOptions()
            .SetAbsoluteExpiration(TimeSpan.FromMinutes(1))
            .SetPriority(CacheItemPriority.High);
        
        _cache.Set(cacheKey, data, cacheOptions);
        
        return data;
    }
    
    public void InvalidateCache(string cacheKey = null)
    {
        if (string.IsNullOrEmpty(cacheKey))
        {
            // Invalidate all cache
            _logger.LogInformation("Invalidating all report cache");
            // Clear all cache entries
        }
        else
        {
            _cache.Remove(cacheKey);
            _logger.LogInformation($"Invalidated cache: {cacheKey}");
        }
    }
}
```

---

## 8.7 Best Practices

### 8.7.1 Dashboard Design Checklist

**Executive Dashboard:**
✅ 5-7 key metrics maximum
✅ Clear visual hierarchy (most important top-left)
✅ Color coding (red/yellow/green)
✅ Trends vs. point-in-time
✅ Actionable (links to details)
✅ Updates every 5-15 minutes
✅ Works on mobile devices

**Operational Dashboard:**
✅ Real-time or near-real-time (30-60 seconds)
✅ Alert prominence (critical alerts highlighted)
✅ Quick actions (acknowledge, resolve)
✅ System status at-a-glance
✅ Color-blind friendly palette
✅ Large display friendly (NOC screens)
✅ Audio alerts for critical issues

**Analytical Dashboard:**
✅ Drill-down capability
✅ Flexible date ranges
✅ Export to Excel/PDF
✅ Saved views/favorites
✅ Comparison views (server vs. server)
✅ Historical trends (30/60/90 days)
✅ Annotations for events

---

### 8.7.2 Report Distribution Strategy

**Table 8.2: Report Distribution Matrix**

| Report Type | Audience | Frequency | Format | Distribution |
|-------------|----------|-----------|--------|--------------|
| **Executive Summary** | C-level | Weekly | PDF | Email Monday 7 AM |
| **Daily Operations** | DBA Team | Daily | HTML/PDF | Email Daily 7 AM |
| **Incident Post-Mortem** | Technical | On-demand | PDF | SharePoint |
| **Compliance Report** | Auditors | Monthly | PDF/Excel | Secure portal |
| **Capacity Planning** | Architects | Quarterly | Excel | Workshop presentation |
| **Performance Analysis** | Developers | On-demand | Interactive | Power BI service |

---

## 8.8 Case Study: Retail Chain Dashboard Implementation

**Background:**

RetailCorp operates 500 stores with local SQL Server instances.

**The Problem (Before Dashboards):**

**Visibility Gaps:**
- No real-time visibility into store database health
- Issues discovered by store managers calling IT
- Manual report generation: 40 hours per week
- Executive leadership requesting quarterly updates
- No trending or capacity planning

**Incident:**
- 47 stores experienced POS database failures over weekend
- Discovered Monday morning when stores opened
- $890K in lost sales
- No early warning system

**The Solution (Dashboard Implementation):**

**Week 1-2: Requirements Gathering**

```
Stakeholder Interviews:
- Executives: High-level KPIs, trends, capacity
- DBA Team: Real-time health, alerts, troubleshooting
- Store Managers: Simple status indicator
- Auditors: Compliance reporting
```

**Week 3-6: Dashboard Development**

**1. Executive Dashboard (Power BI):**
```
- Store database availability %
- Performance trends (30/60/90 days)
- Capacity forecasts
- Top 10 problem stores
- Backup compliance %
- Month-over-month comparisons
```

**2. Operations Dashboard (Web - SignalR):**
```
- Real-time health map (500 stores)
- Active alerts with severity
- Quick acknowledge/resolve
- Performance metrics (last hour)
- Automatic refresh (30 seconds)
```

**3. Store Manager Dashboard (Mobile-friendly):**
```
- Their store only
- Green/Yellow/Red status
- Last backup time
- Contact DBA button
```

**4. Compliance Dashboard (SSRS):**
```
- Backup SLA compliance
- Failed logins
- Security audit events
- Scheduled weekly delivery
```

**Week 7-8: Training and Rollout**

- Executive training: 2-hour session
- DBA training: Full-day workshop
- Store manager webinar: 30 minutes
- Documentation and video tutorials

**Results After 6 Months:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Visibility** ||||
| Time to detect issues | 8+ hours | 3 minutes | **99.4% faster** |
| Stores monitored real-time | 0 | 500 | **∞% improvement** |
| Executive report requests | 12/year | 0 (self-service) | **100% reduction** |
| **Operational** ||||
| Manual reporting hours/week | 40 | 2 | **95% reduction** |
| Average incident duration | 4.2 hours | 35 minutes | **86% faster** |
| Weekend outages | 47 (1 event) | 0 | **100% prevention** |
| **Business Impact** ||||
| Lost sales incidents | $890K (1 event) | $0 | **$890K prevented** |
| DBA productivity gain | - | +38% | +15 hours/week |
| Executive decision latency | Days | Minutes | **Real-time** |

**Financial Impact:**

**Cost Savings:**
- Prevented outages: $890K/year (based on historical)
- DBA productivity: $156K/year (38% × $410K salary × 3 DBAs)
- Reduced executive report generation: $48K/year
**Total Annual Benefit: $1.09M**

**Investment:**
- Dashboard development: 320 hours × $150/hr = $48K
- Power BI Pro licenses: $10/user × 50 users = $500/month
- Training: $15K
**Total Investment: $69K**

**ROI: 1,486%**
**Payback Period: 23 days**

**Stakeholder Testimonials:**

**CIO:**
*"Before, I'd ask for a capacity report and get it 3 days later. Now I can see it in real-time on my iPad. This has fundamentally changed how we make infrastructure decisions."*

**Lead DBA:**
*"The real-time dashboard caught a disk space issue at 3 AM that would have caused an outage at 7 AM when the store opened. It paid for itself the first week."*

**Store Manager:**
*"I used to call IT every time the POS slowed down. Now I can see the database is healthy and know the problem is somewhere else. Saves everyone time."*

**Key Success Factors:**

1. **Stakeholder-Driven Design**: Each audience got relevant dashboard
2. **Mobile-First**: Executives access on tablets
3. **Real-Time Where It Matters**: Ops dashboard updates every 30s
4. **Pre-Aggregation**: Fast performance even with 500 stores
5. **Self-Service**: Reduced report requests to zero
6. **Training**: Ensured adoption
7. **Iterative**: Released v1 quickly, improved based on feedback

**Lessons Learned:**

1. Start simple - v1 had 5 metrics, now has 20+
2. Mobile access is critical for executives
3. Color matters - used colorblind-friendly palette
4. Automatic refresh prevents stale data
5. Alert integration key - dashboard shows active alerts
6. Export to Excel still needed for ad-hoc analysis
7. Documentation and training drive adoption

---

## Chapter 8 Summary

This chapter covered reporting and visualization:

**Key Takeaways:**

1. **Dashboard Hierarchy**: Strategic → Operational → Analytical → Compliance
2. **5-Second Rule**: User should understand within 5 seconds
3. **KPI Design**: Focus on actionable metrics with context
4. **Power BI**: Ideal for executive self-service analytics
5. **SSRS**: Best for scheduled, formatted operational reports
6. **Real-Time Dashboards**: SignalR enables live updates
7. **Performance**: Pre-aggregate data for fast queries (99.6% faster)
8. **Caching**: 1-minute cache reduces database load

**Production Deliverables:**

✅ Complete KPI views (health, backup, capacity)
✅ Power BI dashboard with DAX measures
✅ SSRS daily operations report
✅ Real-time web dashboard with SignalR
✅ Pre-aggregated reporting tables
✅ Scheduled report distribution
✅ Mobile-friendly views

**Best Practices:**

✅ Design for audience (executive vs. operational)
✅ Keep dashboards focused (5-7 metrics)
✅ Use appropriate refresh rates
✅ Pre-aggregate large datasets
✅ Implement caching strategy
✅ Provide drill-down capability
✅ Enable export to Excel/PDF
✅ Test on mobile devices
✅ Use color-blind friendly palettes

**Connection to Next Chapter:**

Chapter 9 covers Security and Compliance, showing how to secure the DBAOps framework itself, implement role-based access control for dashboards and reports, and meet regulatory requirements (SOX, HIPAA, PCI-DSS).

---

## Review Questions

**Multiple Choice:**

1. What is the "5-Second Rule" for dashboards?
   a) Refresh every 5 seconds
   b) User should understand within 5 seconds
   c) Load within 5 seconds
   d) Show last 5 seconds of data

2. What is the recommended cache duration for operational dashboards?
   a) 1 second
   b) 1 minute
   c) 1 hour
   d) 1 day

3. How much faster were queries after pre-aggregation in the example?
   a) 50% faster
   b) 90% faster
   c) 99.6% faster
   d) Same speed

**Short Answer:**

4. Explain the difference between strategic, operational, and analytical dashboards. Provide examples of each.

5. Why is pre-aggregation important for report performance? What are the tradeoffs?

6. Describe three dashboard anti-patterns to avoid and why they're problematic.

**Essay Questions:**

7. Design a comprehensive dashboard strategy for an organization with 1000 SQL Servers. Include:
   - Executive dashboard requirements
   - Operational dashboard requirements
   - Report types and schedules
   - Performance optimization strategy
   - Mobile access approach

8. Analyze the RetailCorp case study. What were the key factors that led to 1,486% ROI? How would you apply these lessons to your organization?

**Hands-On Exercises:**

9. **Exercise 8.1: Build Power BI Dashboard**
   - Connect to repository database
   - Create 5 key DAX measures
   - Build executive dashboard
   - Add drill-through capability
   - Test on mobile device

10. **Exercise 8.2: Create SSRS Report**
    - Design daily operations report
    - Include matrix and charts
    - Add parameters (date range, environment)
    - Schedule email subscription
    - Test PDF output

11. **Exercise 8.3: Implement Pre-Aggregation**
    - Create aggregation table
    - Build aggregation procedure
    - Schedule daily execution
    - Compare query performance
    - Document improvement

12. **Exercise 8.4: Build Real-Time Dashboard**
    - Set up SignalR hub
    - Create dashboard service
    - Build HTML/JavaScript client
    - Implement auto-refresh
    - Add browser notifications

---

*End of Chapter 8*

**Next Chapter:** Chapter 9 - Security and Compliance

