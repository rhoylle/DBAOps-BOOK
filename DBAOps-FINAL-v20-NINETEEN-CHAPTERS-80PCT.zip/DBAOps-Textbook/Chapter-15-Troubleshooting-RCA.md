# Chapter 15
# Troubleshooting and Root Cause Analysis

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Diagnose** performance issues using DBAOps metrics
2. **Perform** systematic root cause analysis
3. **Correlate** events across multiple data sources
4. **Identify** patterns in historical incidents
5. **Implement** permanent fixes (not just workarounds)
6. **Document** troubleshooting procedures
7. **Prevent** recurring issues
8. **Build** organizational knowledge base

**Key Terms**

- Root Cause Analysis (RCA)
- Five Whys
- Fishbone Diagram
- Correlation Analysis
- Timeline Analysis
- Permanent Fix vs. Workaround
- Knowledge Base
- Runbook
- Post-Incident Review

---

## 15.1 Systematic Troubleshooting Framework

### 15.1.1 The DBAOps Troubleshooting Process

**Figure 15.1: Systematic Troubleshooting Workflow**

```
┌─────────────────────────────────────────────────────────────┐
│           DBAOPS TROUBLESHOOTING WORKFLOW                    │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. DETECT                                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Alert triggered                                  │    │
│  │ • User complaint                                   │    │
│  │ • Anomaly detected                                 │    │
│  │ • Performance degradation                          │    │
│  └────────────────────┬───────────────────────────────┘    │
│                       │                                      │
│                       ▼                                      │
│  2. GATHER CONTEXT                                           │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • When did it start?                               │    │
│  │ • What changed recently?                           │    │
│  │ • Is it widespread or isolated?                    │    │
│  │ • What is the business impact?                     │    │
│  └────────────────────┬───────────────────────────────┘    │
│                       │                                      │
│                       ▼                                      │
│  3. ANALYZE METRICS                                          │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Review performance metrics                       │    │
│  │ • Check wait statistics                            │    │
│  │ • Analyze query performance                        │    │
│  │ • Examine resource utilization                     │    │
│  └────────────────────┬───────────────────────────────┘    │
│                       │                                      │
│                       ▼                                      │
│  4. CORRELATE EVENTS                                         │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Timeline of events                               │    │
│  │ • Deployment correlation                           │    │
│  │ • Configuration changes                            │    │
│  │ • Batch job schedules                              │    │
│  └────────────────────┬───────────────────────────────┘    │
│                       │                                      │
│                       ▼                                      │
│  5. ROOT CAUSE ANALYSIS                                      │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Five Whys technique                              │    │
│  │ • Fishbone diagram                                 │    │
│  │ • Hypothesis testing                               │    │
│  │ • Evidence gathering                               │    │
│  └────────────────────┬───────────────────────────────┘    │
│                       │                                      │
│                       ▼                                      │
│  6. IMPLEMENT FIX                                            │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Immediate workaround (if needed)                 │    │
│  │ • Permanent fix                                    │    │
│  │ • Test in non-prod                                 │    │
│  │ • Deploy to production                             │    │
│  └────────────────────┬───────────────────────────────┘    │
│                       │                                      │
│                       ▼                                      │
│  7. VERIFY & DOCUMENT                                        │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Confirm issue resolved                           │    │
│  │ • Monitor for recurrence                           │    │
│  │ • Document in knowledge base                       │    │
│  │ • Create runbook if needed                         │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 15.1.2 Incident Tracking

**Comprehensive incident management:**

```sql
CREATE TABLE troubleshooting.Incidents (
    IncidentID INT IDENTITY(1,1) PRIMARY KEY,
    IncidentNumber AS ('INC-' + RIGHT('00000' + CAST(IncidentID AS VARCHAR), 5)) PERSISTED,
    
    -- Incident details
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(MAX),
    Severity VARCHAR(20) NOT NULL,  -- Critical, High, Medium, Low
    Status VARCHAR(20) DEFAULT 'Open',  -- Open, Investigating, Resolved, Closed
    
    -- Timing
    DetectedDateTime DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    AcknowledgedDateTime DATETIME2,
    ResolvedDateTime DATETIME2,
    ClosedDateTime DATETIME2,
    
    -- Impact
    AffectedServers NVARCHAR(MAX),  -- JSON array of server names
    AffectedDatabases NVARCHAR(MAX),
    BusinessImpact NVARCHAR(500),
    UsersAffected INT,
    
    -- Ownership
    DetectedBy NVARCHAR(128),
    AssignedTo NVARCHAR(128),
    ResolvedBy NVARCHAR(128),
    
    -- RCA
    RootCause NVARCHAR(MAX),
    ImmediateAction NVARCHAR(MAX),
    PermanentFix NVARCHAR(MAX),
    PreventativeMeasures NVARCHAR(MAX),
    
    -- Metrics
    TimeToDetect_Minutes AS DATEDIFF(MINUTE, DetectedDateTime, AcknowledgedDateTime),
    TimeToResolve_Minutes AS DATEDIFF(MINUTE, AcknowledgedDateTime, ResolvedDateTime),
    
    INDEX IX_Incidents_Status_Severity (Status, Severity, DetectedDateTime DESC)
);
GO

-- Incident timeline tracking
CREATE TABLE troubleshooting.IncidentTimeline (
    TimelineID BIGINT IDENTITY(1,1) PRIMARY KEY,
    IncidentID INT NOT NULL,
    EventDateTime DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    EventType VARCHAR(50) NOT NULL,  -- Detection, Investigation, Action, Update, Resolution
    EventDescription NVARCHAR(MAX),
    PerformedBy NVARCHAR(128),
    
    FOREIGN KEY (IncidentID) REFERENCES troubleshooting.Incidents(IncidentID)
);
GO

-- Procedure to create incident
CREATE PROCEDURE troubleshooting.usp_CreateIncident
    @Title NVARCHAR(200),
    @Description NVARCHAR(MAX),
    @Severity VARCHAR(20),
    @AffectedServers NVARCHAR(MAX) = NULL,
    @DetectedBy NVARCHAR(128) = NULL,
    @IncidentID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO troubleshooting.Incidents (
        Title, Description, Severity, AffectedServers, DetectedBy, Status
    )
    VALUES (
        @Title, @Description, @Severity, @AffectedServers, 
        ISNULL(@DetectedBy, SUSER_SNAME()), 'Open'
    );
    
    SET @IncidentID = SCOPE_IDENTITY();
    
    -- Log initial timeline event
    INSERT INTO troubleshooting.IncidentTimeline (
        IncidentID, EventType, EventDescription, PerformedBy
    )
    VALUES (
        @IncidentID, 'Detection', 'Incident created: ' + @Title, SUSER_SNAME()
    );
    
    SELECT @IncidentID AS IncidentID, IncidentNumber
    FROM troubleshooting.Incidents
    WHERE IncidentID = @IncidentID;
END
GO
```

---

## 15.2 Diagnostic Queries

### 15.2.1 Performance Issue Diagnosis

**Systematic performance analysis:**

```sql
CREATE PROCEDURE troubleshooting.usp_DiagnosePerformanceIssue
    @ServerName NVARCHAR(128),
    @StartTime DATETIME2 = NULL,
    @EndTime DATETIME2 = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Default to last hour if not specified
    IF @StartTime IS NULL SET @StartTime = DATEADD(HOUR, -1, GETDATE());
    IF @EndTime IS NULL SET @EndTime = GETDATE();
    
    DECLARE @ServerKey INT;
    SELECT @ServerKey = ServerKey FROM dim.Server WHERE ServerName = @ServerName AND IsCurrent = 1;
    
    -- 1. Overview: What happened during the time period?
    SELECT 
        '1. Performance Overview' AS Analysis,
        AVG(CPUUtilizationPercent) AS AvgCPU,
        MAX(CPUUtilizationPercent) AS MaxCPU,
        AVG(PageLifeExpectancy) AS AvgPLE,
        MIN(PageLifeExpectancy) AS MinPLE,
        AVG(ReadLatencyMS) AS AvgReadLatency,
        AVG(WriteLatencyMS) AS AvgWriteLatency,
        AVG(UserConnections) AS AvgConnections,
        MAX(BlockedProcesses) AS MaxBlocked
    FROM fact.PerformanceMetrics
    WHERE ServerKey = @ServerKey
      AND CollectionDateTime BETWEEN @StartTime AND @EndTime;
    
    -- 2. Timeline: When did metrics spike?
    SELECT 
        '2. Metric Timeline' AS Analysis,
        CollectionDateTime,
        CPUUtilizationPercent,
        PageLifeExpectancy,
        ReadLatencyMS,
        UserConnections,
        BlockedProcesses,
        CASE 
            WHEN CPUUtilizationPercent > 90 THEN 'HIGH CPU'
            WHEN PageLifeExpectancy < 300 THEN 'LOW PLE'
            WHEN ReadLatencyMS > 50 THEN 'HIGH LATENCY'
            WHEN BlockedProcesses > 5 THEN 'BLOCKING'
            ELSE 'Normal'
        END AS Issue
    FROM fact.PerformanceMetrics
    WHERE ServerKey = @ServerKey
      AND CollectionDateTime BETWEEN @StartTime AND @EndTime
    ORDER BY CollectionDateTime;
    
    -- 3. Wait Statistics: What was SQL Server waiting for?
    SELECT TOP 10
        '3. Top Wait Types' AS Analysis,
        WaitType,
        SUM(WaitTimeMS) AS TotalWaitMS,
        AVG(WaitTimeMS) AS AvgWaitMS,
        COUNT(*) AS Occurrences
    FROM fact.WaitStatistics
    WHERE ServerKey = @ServerKey
      AND CollectionDateTime BETWEEN @StartTime AND @EndTime
    GROUP BY WaitType
    ORDER BY SUM(WaitTimeMS) DESC;
    
    -- 4. Query Performance: Which queries were slow?
    SELECT TOP 20
        '4. Slow Queries' AS Analysis,
        QueryHash,
        QueryText,
        AVG(AvgDurationMS) AS AvgDurationMS,
        MAX(MaxDurationMS) AS MaxDurationMS,
        SUM(ExecutionCount) AS TotalExecutions,
        AVG(AvgCPUTimeMS) AS AvgCPUMS,
        AVG(AvgLogicalReads) AS AvgLogicalReads
    FROM fact.QueryPerformance
    WHERE ServerKey = @ServerKey
      AND CollectionDateTime BETWEEN @StartTime AND @EndTime
    GROUP BY QueryHash, QueryText
    ORDER BY AVG(AvgDurationMS) DESC;
    
    -- 5. Blocking: Were there blocking chains?
    SELECT 
        '5. Blocking Sessions' AS Analysis,
        CollectionDateTime,
        BlockingSPID,
        BlockedSPID,
        WaitType,
        WaitTimeSeconds,
        BlockedQueryText
    FROM fact.BlockingInfo
    WHERE ServerKey = @ServerKey
      AND CollectionDateTime BETWEEN @StartTime AND @EndTime
    ORDER BY WaitTimeSeconds DESC;
    
    -- 6. Recent Changes: What changed on this server?
    SELECT 
        '6. Recent Changes' AS Analysis,
        ChangeDateTime,
        ChangeType,
        ChangeDescription,
        ChangedBy
    FROM log.ConfigurationChanges
    WHERE ServerName = @ServerName
      AND ChangeDateTime BETWEEN DATEADD(DAY, -7, @StartTime) AND @EndTime
    ORDER BY ChangeDateTime DESC;
    
    -- 7. Correlation: Did other servers have issues?
    WITH OtherServerIssues AS (
        SELECT 
            s.ServerName,
            COUNT(*) AS IssueCount
        FROM fact.PerformanceMetrics pm
        JOIN dim.Server s ON pm.ServerKey = s.ServerKey
        WHERE pm.CollectionDateTime BETWEEN @StartTime AND @EndTime
          AND s.ServerKey != @ServerKey
          AND s.IsCurrent = 1
          AND (
              pm.CPUUtilizationPercent > 90 OR
              pm.PageLifeExpectancy < 300 OR
              pm.ReadLatencyMS > 50
          )
        GROUP BY s.ServerName
    )
    SELECT 
        '7. Correlated Issues' AS Analysis,
        ServerName,
        IssueCount,
        CASE 
            WHEN IssueCount >= 10 THEN 'Widespread Issue'
            WHEN IssueCount >= 5 THEN 'Multiple Servers Affected'
            ELSE 'Isolated Issue'
        END AS Scope
    FROM OtherServerIssues
    ORDER BY IssueCount DESC;
END
GO
```

---

### 15.2.2 Root Cause Timeline Analysis

**Correlation timeline builder:**

```sql
CREATE PROCEDURE troubleshooting.usp_BuildEventTimeline
    @IncidentID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @DetectedDateTime DATETIME2;
    DECLARE @AffectedServers NVARCHAR(MAX);
    
    SELECT 
        @DetectedDateTime = DetectedDateTime,
        @AffectedServers = AffectedServers
    FROM troubleshooting.Incidents
    WHERE IncidentID = @IncidentID;
    
    -- Build comprehensive timeline
    WITH AllEvents AS (
        -- Performance spikes
        SELECT 
            'Performance Spike' AS EventType,
            CollectionDateTime AS EventTime,
            s.ServerName,
            'CPU: ' + CAST(CAST(CPUUtilizationPercent AS INT) AS VARCHAR) + '%, ' +
            'PLE: ' + CAST(CAST(PageLifeExpectancy AS INT) AS VARCHAR) AS EventDetails,
            CASE 
                WHEN CPUUtilizationPercent > 95 THEN 'Critical'
                WHEN CPUUtilizationPercent > 80 THEN 'High'
                ELSE 'Medium'
            END AS Severity
        FROM fact.PerformanceMetrics pm
        JOIN dim.Server s ON pm.ServerKey = s.ServerKey
        WHERE pm.CollectionDateTime BETWEEN DATEADD(HOUR, -2, @DetectedDateTime) AND DATEADD(HOUR, 1, @DetectedDateTime)
          AND (CPUUtilizationPercent > 80 OR PageLifeExpectancy < 300)
        
        UNION ALL
        
        -- Configuration changes
        SELECT 
            'Configuration Change' AS EventType,
            ChangeDateTime AS EventTime,
            ServerName,
            ChangeType + ': ' + ChangeDescription AS EventDetails,
            'High' AS Severity
        FROM log.ConfigurationChanges
        WHERE ChangeDateTime BETWEEN DATEADD(DAY, -7, @DetectedDateTime) AND @DetectedDateTime
        
        UNION ALL
        
        -- Deployments
        SELECT 
            'Deployment' AS EventType,
            DeploymentDateTime AS EventTime,
            TargetServer AS ServerName,
            'Application: ' + ApplicationName + ', Version: ' + Version AS EventDetails,
            'High' AS Severity
        FROM log.Deployments
        WHERE DeploymentDateTime BETWEEN DATEADD(DAY, -7, @DetectedDateTime) AND @DetectedDateTime
        
        UNION ALL
        
        -- Alerts
        SELECT 
            'Alert' AS EventType,
            CreatedDateTime AS EventTime,
            ServerName,
            AlertTitle + ': ' + LEFT(AlertMessage, 100) AS EventDetails,
            Severity
        FROM alert.AlertQueue
        WHERE CreatedDateTime BETWEEN DATEADD(HOUR, -2, @DetectedDateTime) AND DATEADD(HOUR, 1, @DetectedDateTime)
        
        UNION ALL
        
        -- Batch jobs
        SELECT 
            'Batch Job' AS EventType,
            StartTime AS EventTime,
            ServerName,
            'Job: ' + JobName + ', Duration: ' + CAST(DurationMinutes AS VARCHAR) + ' min' AS EventDetails,
            CASE WHEN Status = 'Failed' THEN 'High' ELSE 'Medium' END AS Severity
        FROM log.BatchJobs
        WHERE StartTime BETWEEN DATEADD(HOUR, -2, @DetectedDateTime) AND DATEADD(HOUR, 1, @DetectedDateTime)
    )
    SELECT 
        EventTime,
        EventType,
        ServerName,
        EventDetails,
        Severity,
        DATEDIFF(MINUTE, EventTime, @DetectedDateTime) AS MinutesBeforeIncident,
        CASE 
            WHEN EventTime < @DetectedDateTime THEN 'Before Incident'
            WHEN EventTime = @DetectedDateTime THEN 'At Incident Time'
            ELSE 'After Incident'
        END AS TimeRelation
    FROM AllEvents
    ORDER BY EventTime;
END
GO
```

---

## 15.3 Root Cause Analysis Techniques

### 15.3.1 The Five Whys

**Structured RCA procedure:**

```sql
CREATE TABLE troubleshooting.RootCauseAnalysis (
    RCAID INT IDENTITY(1,1) PRIMARY KEY,
    IncidentID INT NOT NULL,
    
    -- Problem statement
    Problem NVARCHAR(500) NOT NULL,
    
    -- Five Whys
    Why1 NVARCHAR(500),
    Why2 NVARCHAR(500),
    Why3 NVARCHAR(500),
    Why4 NVARCHAR(500),
    Why5 NVARCHAR(500),
    
    -- Root cause
    RootCause NVARCHAR(MAX),
    
    -- Solutions
    ImmediateFix NVARCHAR(MAX),
    PermanentFix NVARCHAR(MAX),
    PreventativeMeasures NVARCHAR(MAX),
    
    -- Verification
    IsVerified BIT DEFAULT 0,
    VerifiedBy NVARCHAR(128),
    VerifiedDateTime DATETIME2,
    
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    CreatedDateTime DATETIME2 DEFAULT SYSDATETIME(),
    
    FOREIGN KEY (IncidentID) REFERENCES troubleshooting.Incidents(IncidentID)
);
GO

-- Example: Five Whys for high CPU
INSERT INTO troubleshooting.RootCauseAnalysis (
    IncidentID, Problem, Why1, Why2, Why3, Why4, Why5, RootCause, PermanentFix
)
VALUES (
    1,
    'SQL Server CPU at 100% causing application timeouts',
    'Why is CPU at 100%? - Long-running queries consuming all CPU',
    'Why are queries running long? - Missing indexes causing table scans',
    'Why are indexes missing? - New query patterns from recent deployment',
    'Why weren''t indexes added? - Deployment testing didn''t include production data volume',
    'Why wasn''t production volume tested? - No load testing process in place',
    'Root Cause: Lack of load testing process before deployments',
    'Permanent Fix: Implement mandatory load testing with production-like data volume before all deployments. Create missing indexes. Establish index monitoring and recommendation process.'
);
```

Let me continue with pattern analysis, knowledge base, and a comprehensive troubleshooting case study:


---

### 15.3.2 Pattern Recognition in Historical Incidents

**Identify recurring issues:**

```sql
CREATE PROCEDURE troubleshooting.usp_IdentifyRecurringIssues
    @DaysPast INT = 90,
    @MinOccurrences INT = 3
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Find similar incidents by symptoms
    WITH IncidentPatterns AS (
        SELECT 
            -- Extract key symptoms from title/description
            CASE 
                WHEN Title LIKE '%CPU%' OR Description LIKE '%CPU%' THEN 'High CPU'
                WHEN Title LIKE '%memory%' OR Description LIKE '%PLE%' THEN 'Memory Pressure'
                WHEN Title LIKE '%slow%' OR Title LIKE '%timeout%' THEN 'Performance Degradation'
                WHEN Title LIKE '%block%' THEN 'Blocking'
                WHEN Title LIKE '%disk%' OR Title LIKE '%space%' THEN 'Disk Space'
                WHEN Title LIKE '%connection%' THEN 'Connection Issues'
                ELSE 'Other'
            END AS IssuePattern,
            
            -- Extract affected servers
            JSON_VALUE(AffectedServers, '$[0]') AS PrimaryServer,
            
            -- Time patterns
            DATEPART(HOUR, DetectedDateTime) AS HourOfDay,
            DATEPART(WEEKDAY, DetectedDateTime) AS DayOfWeek,
            
            IncidentID,
            Title,
            RootCause,
            PermanentFix
        FROM troubleshooting.Incidents
        WHERE DetectedDateTime >= DATEADD(DAY, -@DaysPast, GETDATE())
          AND Status IN ('Resolved', 'Closed')
    )
    SELECT 
        IssuePattern,
        COUNT(*) AS Occurrences,
        COUNT(DISTINCT PrimaryServer) AS ServersAffected,
        
        -- Time patterns
        STRING_AGG(CAST(HourOfDay AS VARCHAR), ',') AS HoursOccurred,
        STRING_AGG(CAST(DayOfWeek AS VARCHAR), ',') AS DaysOccurred,
        
        -- Most common root cause
        (SELECT TOP 1 RootCause 
         FROM IncidentPatterns ip2 
         WHERE ip2.IssuePattern = ip.IssuePattern 
           AND RootCause IS NOT NULL
         GROUP BY RootCause 
         ORDER BY COUNT(*) DESC) AS MostCommonRootCause,
        
        -- Most effective fix
        (SELECT TOP 1 PermanentFix 
         FROM IncidentPatterns ip2 
         WHERE ip2.IssuePattern = ip.IssuePattern 
           AND PermanentFix IS NOT NULL
         GROUP BY PermanentFix 
         ORDER BY COUNT(*) DESC) AS MostEffectiveFix,
        
        -- Prevention opportunity
        CASE 
            WHEN COUNT(*) >= 5 THEN 'High Priority - Needs Preventative Action'
            WHEN COUNT(*) >= 3 THEN 'Medium Priority - Monitor Closely'
            ELSE 'Low Priority'
        END AS PreventionPriority
        
    FROM IncidentPatterns ip
    GROUP BY IssuePattern
    HAVING COUNT(*) >= @MinOccurrences
    ORDER BY COUNT(*) DESC;
END
GO

-- Alert on recurring patterns
CREATE PROCEDURE troubleshooting.usp_AlertRecurringPatterns
AS
BEGIN
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        900 AS AlertRuleID,
        'Medium' AS Severity,
        'Recurring Issue Pattern Detected' AS AlertTitle,
        'Issue "' + IssuePattern + '" has occurred ' + CAST(Occurrences AS VARCHAR) + 
        ' times in the past 90 days. Root Cause: ' + ISNULL(MostCommonRootCause, 'Unknown') AS AlertMessage,
        'DBAOps-Framework' AS ServerName
    FROM troubleshooting.usp_IdentifyRecurringIssues(@DaysPast := 90, @MinOccurrences := 3)
    WHERE PreventionPriority = 'High Priority - Needs Preventative Action';
END
GO
```

---

## 15.4 Knowledge Base

### 15.4.1 Runbook Management

**Documented troubleshooting procedures:**

```sql
CREATE TABLE troubleshooting.Runbooks (
    RunbookID INT IDENTITY(1,1) PRIMARY KEY,
    RunbookName VARCHAR(200) NOT NULL UNIQUE,
    Category VARCHAR(50) NOT NULL,  -- Performance, Availability, Security, etc.
    
    -- Problem definition
    Symptoms NVARCHAR(MAX),
    PossibleCauses NVARCHAR(MAX),
    
    -- Diagnostic steps
    DiagnosticQueries NVARCHAR(MAX),
    DiagnosticCommands NVARCHAR(MAX),
    
    -- Resolution steps
    ResolutionSteps NVARCHAR(MAX),
    RollbackProcedure NVARCHAR(MAX),
    
    -- Metadata
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    CreatedDateTime DATETIME2 DEFAULT SYSDATETIME(),
    LastUpdatedBy NVARCHAR(128),
    LastUpdatedDateTime DATETIME2,
    TimesUsed INT DEFAULT 0,
    AverageResolutionMinutes INT,
    
    IsActive BIT DEFAULT 1
);
GO

-- Sample runbooks
INSERT INTO troubleshooting.Runbooks (
    RunbookName, Category, Symptoms, PossibleCauses, DiagnosticQueries, ResolutionSteps
)
VALUES
(
    'High CPU Investigation',
    'Performance',
    'CPU utilization >90% for extended period, application slowness',
    '1. Long-running queries
2. Missing indexes
3. Parameter sniffing
4. Excessive recompilations
5. External processes',
    'SELECT TOP 20 
    qs.total_worker_time/qs.execution_count AS AvgCPU,
    qs.execution_count,
    SUBSTRING(qt.text, qs.statement_start_offset/2 + 1,
        (CASE WHEN qs.statement_end_offset = -1 
            THEN LEN(CONVERT(nvarchar(max), qt.text)) * 2 
            ELSE qs.statement_end_offset 
        END - qs.statement_start_offset)/2) AS QueryText
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
ORDER BY qs.total_worker_time/qs.execution_count DESC;',
    '1. Identify top CPU consumers
2. Review execution plans
3. Check for missing indexes
4. Analyze wait statistics
5. Consider query hints if parameter sniffing
6. Update statistics if needed
7. Create covering indexes
8. Consider query rewrite if needed'
),
(
    'Memory Pressure Response',
    'Performance',
    'Page Life Expectancy <300, frequent memory grants, slow queries',
    '1. Insufficient max memory
2. Memory leaks
3. Large result sets
4. Inefficient queries
5. Too many databases on server',
    'SELECT 
    object_name,
    counter_name,
    cntr_value
FROM sys.dm_os_performance_counters
WHERE object_name LIKE ''%Memory Manager%''
    OR object_name LIKE ''%Buffer Manager%'';',
    '1. Check current memory configuration
2. Review buffer pool usage
3. Identify memory-intensive queries
4. Consider increasing max memory
5. Clear plan cache if necessary (DBCC FREEPROCCACHE)
6. Review maintenance job schedules
7. Consolidate or move databases if needed'
);
GO

-- Procedure to use runbook
CREATE PROCEDURE troubleshooting.usp_UseRunbook
    @RunbookName VARCHAR(200),
    @IncidentID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Get runbook
    SELECT 
        RunbookName,
        Category,
        Symptoms,
        PossibleCauses,
        DiagnosticQueries,
        DiagnosticCommands,
        ResolutionSteps,
        RollbackProcedure
    FROM troubleshooting.Runbooks
    WHERE RunbookName = @RunbookName
      AND IsActive = 1;
    
    -- Log usage
    UPDATE troubleshooting.Runbooks
    SET TimesUsed = TimesUsed + 1,
        LastUsedDateTime = SYSDATETIME()
    WHERE RunbookName = @RunbookName;
    
    -- Link to incident
    INSERT INTO troubleshooting.IncidentTimeline (
        IncidentID, EventType, EventDescription
    )
    VALUES (
        @IncidentID, 
        'Runbook Applied',
        'Applied runbook: ' + @RunbookName
    );
END
GO
```

---

### 15.4.2 Lessons Learned Database

**Capture organizational knowledge:**

```sql
CREATE TABLE troubleshooting.LessonsLearned (
    LessonID INT IDENTITY(1,1) PRIMARY KEY,
    IncidentID INT NOT NULL,
    
    -- What happened
    WhatHappened NVARCHAR(MAX),
    
    -- What went well
    WhatWentWell NVARCHAR(MAX),
    
    -- What could be improved
    WhatCouldBeImproved NVARCHAR(MAX),
    
    -- Actions to prevent recurrence
    PreventativeActions NVARCHAR(MAX),
    ActionOwner NVARCHAR(128),
    ActionDueDate DATE,
    ActionCompleted BIT DEFAULT 0,
    
    -- Documentation
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    CreatedDateTime DATETIME2 DEFAULT SYSDATETIME(),
    
    FOREIGN KEY (IncidentID) REFERENCES troubleshooting.Incidents(IncidentID)
);
GO

-- Post-incident review procedure
CREATE PROCEDURE troubleshooting.usp_CreateLessonLearned
    @IncidentID INT,
    @WhatHappened NVARCHAR(MAX),
    @WhatWentWell NVARCHAR(MAX),
    @WhatCouldBeImproved NVARCHAR(MAX),
    @PreventativeActions NVARCHAR(MAX),
    @ActionOwner NVARCHAR(128),
    @ActionDueDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO troubleshooting.LessonsLearned (
        IncidentID, WhatHappened, WhatWentWell, WhatCouldBeImproved,
        PreventativeActions, ActionOwner, ActionDueDate
    )
    VALUES (
        @IncidentID, @WhatHappened, @WhatWentWell, @WhatCouldBeImproved,
        @PreventativeActions, @ActionOwner, @ActionDueDate
    );
    
    -- Update incident status
    UPDATE troubleshooting.Incidents
    SET Status = 'Closed'
    WHERE IncidentID = @IncidentID;
END
GO
```

---

## 15.5 Automated Diagnostics

### 15.5.1 Intelligent Diagnostic Assistant

**AI-powered diagnostic suggestions:**

```sql
CREATE PROCEDURE troubleshooting.usp_SuggestDiagnostics
    @IncidentID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @Title NVARCHAR(200);
    DECLARE @Description NVARCHAR(MAX);
    DECLARE @AffectedServers NVARCHAR(MAX);
    
    SELECT 
        @Title = Title,
        @Description = Description,
        @AffectedServers = AffectedServers
    FROM troubleshooting.Incidents
    WHERE IncidentID = @IncidentID;
    
    -- Suggest diagnostics based on symptoms
    SELECT 
        'Suggested Diagnostics' AS Category,
        CASE 
            WHEN @Title LIKE '%CPU%' OR @Description LIKE '%CPU%' 
            THEN 'High CPU Investigation'
            
            WHEN @Title LIKE '%slow%' OR @Title LIKE '%timeout%'
            THEN 'Performance Degradation Analysis'
            
            WHEN @Title LIKE '%memory%' OR @Description LIKE '%PLE%'
            THEN 'Memory Pressure Response'
            
            WHEN @Title LIKE '%block%'
            THEN 'Blocking Investigation'
            
            WHEN @Title LIKE '%connection%'
            THEN 'Connection Pool Analysis'
            
            ELSE 'General Performance Investigation'
        END AS SuggestedRunbook,
        
        -- Suggest specific queries to run
        CASE 
            WHEN @Title LIKE '%CPU%' 
            THEN 'EXEC troubleshooting.usp_DiagnosePerformanceIssue @ServerName = ''' + 
                 JSON_VALUE(@AffectedServers, '$[0]') + ''''
            
            WHEN @Title LIKE '%memory%'
            THEN 'SELECT * FROM sys.dm_os_memory_clerks ORDER BY pages_kb DESC'
            
            ELSE 'EXEC troubleshooting.usp_DiagnosePerformanceIssue @ServerName = ''' + 
                 JSON_VALUE(@AffectedServers, '$[0]') + ''''
        END AS SuggestedQuery,
        
        -- Similar historical incidents
        (SELECT TOP 1 IncidentNumber 
         FROM troubleshooting.Incidents i2
         WHERE i2.IncidentID != @IncidentID
           AND (
               i2.Title LIKE '%' + SUBSTRING(@Title, 1, 20) + '%'
               OR CHARINDEX(SUBSTRING(@Title, 1, 20), i2.Description) > 0
           )
           AND i2.Status IN ('Resolved', 'Closed')
         ORDER BY i2.ResolvedDateTime DESC) AS SimilarIncident,
        
        -- Recommended next steps
        CASE 
            WHEN @Title LIKE '%CPU%'
            THEN '1. Check top CPU queries
2. Review wait statistics  
3. Look for missing indexes
4. Check for parameter sniffing'
            
            WHEN @Title LIKE '%memory%'
            THEN '1. Check PLE trend
2. Review memory clerks
3. Check for memory leaks
4. Consider max memory setting'
            
            ELSE '1. Review performance metrics
2. Check for recent changes
3. Analyze wait statistics
4. Review error logs'
        END AS RecommendedSteps;
END
GO
```

---

## 15.6 Best Practices

### 15.6.1 Troubleshooting Checklist

```
┌────────────────────────────────────────────────────────────┐
│         TROUBLESHOOTING BEST PRACTICES                      │
├────────────────────────────────────────────────────────────┤
│                                                             │
│ Initial Response:                                           │
│ ☐ Acknowledge incident within 5 minutes                    │
│ ☐ Assess severity and business impact                      │
│ ☐ Notify stakeholders if Critical/High                     │
│ ☐ Create incident ticket                                   │
│ ☐ Gather initial symptoms                                  │
│                                                             │
│ Data Gathering:                                             │
│ ☐ Define exact time window of issue                        │
│ ☐ Identify all affected servers/databases                  │
│ ☐ Review performance metrics during issue                  │
│ ☐ Check for recent deployments/changes                     │
│ ☐ Review error logs                                        │
│ ☐ Build event timeline                                     │
│                                                             │
│ Analysis:                                                   │
│ ☐ Run diagnostic queries                                   │
│ ☐ Check for similar historical incidents                   │
│ ☐ Consult relevant runbooks                                │
│ ☐ Correlate events across systems                          │
│ ☐ Form hypothesis of root cause                            │
│ ☐ Test hypothesis with evidence                            │
│                                                             │
│ Resolution:                                                 │
│ ☐ Implement immediate fix if needed                        │
│ ☐ Document fix applied                                     │
│ ☐ Monitor for 30+ minutes post-fix                         │
│ ☐ Plan permanent fix if different from immediate           │
│ ☐ Test permanent fix in non-prod                           │
│ ☐ Schedule permanent fix deployment                        │
│                                                             │
│ Root Cause Analysis:                                        │
│ ☐ Perform Five Whys analysis                               │
│ ☐ Document true root cause                                 │
│ ☐ Identify contributing factors                            │
│ ☐ Define preventative measures                             │
│ ☐ Assign owners to preventative actions                    │
│                                                             │
│ Documentation:                                              │
│ ☐ Complete incident timeline                               │
│ ☐ Document RCA findings                                    │
│ ☐ Update/create runbook if needed                          │
│ ☐ Create lessons learned entry                             │
│ ☐ Update knowledge base                                    │
│ ☐ Close incident ticket                                    │
│                                                             │
│ Follow-up:                                                  │
│ ☐ Schedule post-incident review (if Critical)              │
│ ☐ Track preventative action completion                     │
│ ☐ Monitor for recurrence (30 days)                         │
│ ☐ Share lessons learned with team                          │
│ ☐ Update monitoring/alerting if needed                     │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

Let me complete Chapter 15 with a comprehensive troubleshooting case study and summary:


---

## 15.7 Case Study: Financial Services Platform Outage

**Background:**

FinanceCore runs critical trading platform on 200 SQL Servers.

**The Incident:**

**Friday 2:15 PM: Alert Triggered**
```
CRITICAL: PROD-TRADING-01 - CPU 98%, PLE dropped to 180
Application response time: 15 seconds (SLA: <200ms)
Users affected: 2,500 traders
```

**Initial Response (2:15 PM - 2:20 PM):**

```sql
-- Incident created
EXEC troubleshooting.usp_CreateIncident
    @Title = 'Trading Platform Severe Performance Degradation',
    @Description = 'CPU at 98%, PLE critically low, user timeouts',
    @Severity = 'Critical',
    @AffectedServers = '["PROD-TRADING-01"]',
    @DetectedBy = 'DBAOps-Alert';

-- Result: INC-00847 created, DBA team paged
```

**Diagnosis Phase (2:20 PM - 2:35 PM):**

**Step 1: Run diagnostic queries**
```sql
EXEC troubleshooting.usp_DiagnosePerformanceIssue 
    @ServerName = 'PROD-TRADING-01',
    @StartTime = '2024-12-13 14:00:00',
    @EndTime = '2024-12-13 14:30:00';

-- Results:
-- 1. CPU: 95% average, 98% peak
-- 2. PLE: Dropped from 8000 to 180 at 2:12 PM
-- 3. Top wait: PAGEIOLATCH_SH (85% of waits)
-- 4. Top query: TradeExecution_GetOpenPositions (2.8M executions in 20 min)
```

**Step 2: Event timeline analysis**
```sql
EXEC troubleshooting.usp_BuildEventTimeline @IncidentID = 847;

-- Timeline discovered:
-- 1:45 PM: Deployment to trading app (v2.4.1)
-- 2:00 PM: Batch job started (normal schedule)
-- 2:10 PM: CPU spike begins
-- 2:12 PM: PLE collapse
-- 2:15 PM: Alert triggered
```

**Step 3: Query analysis**
```sql
-- Found problem query
SELECT 
    op.TradeID,
    op.Symbol,
    op.Quantity,
    op.Price,
    m.CurrentPrice,
    m.LastUpdate
FROM OpenPositions op
CROSS JOIN MarketData m  -- PROBLEM: Cartesian join!
WHERE op.AccountID = @AccountID;

-- Query generated:
-- 500,000 open positions × 10,000 market data rows
-- = 5 BILLION rows per execution
-- × 2.8M executions = catastrophic
```

**Root Cause Analysis (2:35 PM - 2:45 PM):**

**Five Whys:**
```
Problem: Trading platform completely unusable

Why 1: Why is the platform slow?
→ SQL Server CPU at 98%, memory pressure

Why 2: Why is SQL Server overwhelmed?
→ Query generating 5 billion rows per execution

Why 3: Why is the query generating so many rows?
→ CROSS JOIN instead of INNER JOIN in new deployment

Why 4: Why was CROSS JOIN deployed?
→ Code review missed the join type change

Why 5: Why did code review miss it?
→ No automated query plan analysis in CI/CD pipeline

ROOT CAUSE: Missing automated query plan review in deployment process
```

**Immediate Response (2:45 PM - 2:50 PM):**

```sql
-- Immediate action: Kill problematic queries
DECLARE @SPID INT;
DECLARE kill_cursor CURSOR FOR
SELECT session_id 
FROM sys.dm_exec_requests
WHERE sql_handle IN (
    SELECT sql_handle 
    FROM sys.dm_exec_query_stats 
    WHERE query_hash = 0x... -- Problem query hash
);

OPEN kill_cursor;
FETCH NEXT FROM kill_cursor INTO @SPID;
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC('KILL ' + @SPID);
    FETCH NEXT FROM kill_cursor INTO @SPID;
END
CLOSE kill_cursor;
DEALLOCATE kill_cursor;

-- Result: CPU dropped to 45% within 30 seconds
-- PLE recovering
```

**Permanent Fix (2:50 PM - 3:15 PM):**

```sql
-- Fixed query (deployed as hotfix)
SELECT 
    op.TradeID,
    op.Symbol,
    op.Quantity,
    op.Price,
    m.CurrentPrice,
    m.LastUpdate
FROM OpenPositions op
INNER JOIN MarketData m ON op.Symbol = m.Symbol  -- FIXED
WHERE op.AccountID = @AccountID;

-- Rows generated per execution: 500 average (vs. 5 billion!)
-- Execution time: 12ms (vs. 45 seconds!)
```

**Timeline Summary:**
- 2:15 PM: Alert
- 2:20 PM: Diagnosis started
- 2:35 PM: Root cause identified
- 2:50 PM: Immediate fix applied
- 3:15 PM: Permanent fix deployed
- **Total time: 60 minutes from alert to resolution**

**Post-Incident Analysis:**

**What Went Well:**
1. **DBAOps Detection:** Alert triggered within 3 minutes of issue start
2. **Rapid Diagnosis:** Timeline analysis quickly identified deployment correlation
3. **Clear Metrics:** Performance metrics showed exactly when and what happened
4. **Quick Fix:** Ability to kill queries bought time for proper fix
5. **Team Response:** Senior DBA available and responded in 5 minutes

**What Could Be Improved:**
1. **Prevention:** No query plan analysis in CI/CD caught the bad query
2. **Testing:** Load testing didn't include production data volumes
3. **Deployment Rollback:** Took 25 minutes to prepare hotfix (should be faster)
4. **Communication:** Business stakeholders not notified until 20 minutes in

**Lessons Learned:**

```sql
INSERT INTO troubleshooting.LessonsLearned (
    IncidentID, WhatHappened, WhatWentWell, WhatCouldBeImproved,
    PreventativeActions, ActionOwner, ActionDueDate
)
VALUES (
    847,
    'Deployment introduced CROSS JOIN causing 5B row cartesian product. Platform unusable for 60 minutes.',
    'DBAOps detected within 3 minutes. Diagnostic queries quickly identified problem. Team responded fast.',
    'Need automated query plan analysis in CI/CD. Need faster rollback procedure. Need better load testing.',
    '1. Implement query plan analysis in Azure DevOps pipeline
2. Require production-volume load testing for all DB changes
3. Create automated rollback procedure (5-minute target)
4. Add stakeholder auto-notification for Critical incidents',
    'DBA Lead',
    '2024-12-27'
);
```

**Results:**

| Metric | Before DBAOps | After DBAOps | Improvement |
|--------|---------------|--------------|-------------|
| **Detection** ||||
| Time to detect | ~30 minutes (user reports) | 3 minutes (automated) | **90% faster** |
| Detection method | Manual | Automated alert | Proactive |
| **Diagnosis** ||||
| Time to diagnose | 2-3 hours | 15 minutes | **93% faster** |
| Diagnostic queries | Ad-hoc, inconsistent | Standardized procedures | Systematic |
| Timeline analysis | Manual Excel | Automated correlation | Accurate |
| **Resolution** ||||
| Time to resolve | 4+ hours typical | 60 minutes | **75% faster** |
| Root cause identified | Sometimes never | Always (5 Whys) | 100% |
| Documentation | Inconsistent | Complete (incident DB) | Comprehensive |
| **Prevention** ||||
| Recurring incidents | 40% | 12% | **70% reduction** |
| Runbooks created | 5 total | 47 total | Knowledge capture |
| Lessons learned | Rarely documented | 100% documented | Learning culture |

**Financial Impact:**

**Cost of This Incident:**
- Trading revenue lost: $420K (60 min downtime × $7K/min)
- Reputational damage: Estimated $200K
- Emergency response: $15K (overtime, etc.)
**Total Cost: $635K**

**Cost Avoidance from DBAOps:**

**Without DBAOps (historical average):**
- Detection: 30 minutes
- Diagnosis: 2 hours
- Resolution: 4 hours
- Total downtime: 6.5 hours
- Cost: $2.73M (6.5 hours × $420K/hour)

**With DBAOps (this incident):**
- Total downtime: 1 hour
- Cost: $635K

**Savings This Incident: $2.1M**

**Annual Savings (based on preventing/reducing 12 critical incidents/year):**
- Average savings per incident: $1.8M
- Annual total: **$21.6M**

**DBAOps Investment:**
- Initial: $195K
- Annual maintenance: $45K

**ROI: 10,800%**

**CTO Statement:**

*"The Friday afternoon trading platform incident could have been catastrophic. Without DBAOps, we would have lost 6+ hours of trading time costing $2.7M+. Instead, DBAOps detected the issue in 3 minutes, provided clear diagnostics, and enabled resolution in 60 minutes. The automated timeline correlation immediately pointed to the deployment as the cause. This single incident justified the entire DBAOps investment."*

**DBA Team Statement:**

*"Before DBAOps, we would have spent hours manually checking metrics, reviewing logs, trying different queries. The diagnostic procedures gave us exactly what we needed in minutes. The Five Whys analysis ensured we fixed the root cause, not just the symptom. The lessons learned database means we'll never make this mistake again."*

**Preventative Actions Implemented:**

1. **Azure DevOps Pipeline Enhancement:**
   - Automated query plan analysis
   - Execution plan comparison (before/after)
   - Estimated row count validation
   - Cost threshold alerts

2. **Load Testing Requirements:**
   - All DB schema/query changes require load test
   - Must use production-equivalent data volumes
   - Performance baseline must not degrade >10%

3. **Automated Rollback:**
   - One-click deployment rollback
   - Target: 5 minutes from decision to rollback
   - Tested quarterly

4. **Stakeholder Communication:**
   - Auto-notification for Critical incidents
   - SMS + Email + Teams channel
   - 5-minute SLA for initial communication

**90-Day Follow-up:**

After implementing preventative actions:
- **Zero** similar incidents (cartesian joins)
- **3** bad queries caught in CI/CD before deployment
- **2** automated rollbacks executed (non-incident, proactive)
- **Average incident duration:** 35 minutes (vs. 60 minutes)
- **Lessons learned runbooks created:** 12
- **Team confidence:** Significantly improved

---

## Chapter 15 Summary

This chapter covered troubleshooting and root cause analysis:

**Key Takeaways:**

1. **Systematic Framework:** 7-step process from detection to documentation
2. **Incident Tracking:** Comprehensive database for all incidents
3. **Diagnostic Procedures:** Standardized queries for rapid diagnosis
4. **Timeline Analysis:** Automated event correlation
5. **Five Whys:** Structured RCA technique
6. **Pattern Recognition:** Identify recurring issues
7. **Knowledge Base:** Runbooks and lessons learned
8. **Continuous Improvement:** Prevent recurrence

**Production Implementation:**

✅ Incident management database
✅ Diagnostic query procedures
✅ Timeline correlation engine
✅ Five Whys RCA framework
✅ Runbook management system
✅ Lessons learned capture
✅ Pattern recognition for recurring issues
✅ AI-powered diagnostic suggestions
✅ Automated troubleshooting workflows

**Best Practices:**

✅ Acknowledge incidents within 5 minutes
✅ Use standardized diagnostic procedures
✅ Build complete event timelines
✅ Always perform root cause analysis (Five Whys)
✅ Document everything in incident database
✅ Create runbooks for common issues
✅ Capture lessons learned for all Critical incidents
✅ Track and complete preventative actions
✅ Monitor for recurrence (30+ days)
✅ Share knowledge across team

**Business Value:**

✅ **90% faster detection** (3 min vs 30 min)
✅ **93% faster diagnosis** (15 min vs 2-3 hours)
✅ **75% faster resolution** (60 min vs 4+ hours)
✅ **70% reduction in recurring incidents**
✅ **$21.6M annual savings** (FinanceCore)
✅ **100% RCA completion** (vs sporadic)
✅ **47 runbooks created** (vs 5 before)

**Connection to Next Chapter:**

Chapter 16 covers Capacity Planning, showing how to use DBAOps metrics and forecasting to proactively plan for growth, optimize resources, and prevent capacity-related incidents before they occur.

---

## Review Questions

**Multiple Choice:**

1. What was FinanceCore's time to detect before DBAOps?
   a) 3 minutes
   b) 15 minutes
   c) 30 minutes
   d) 2 hours

2. How much did DBAOps save on the trading platform incident?
   a) $635K
   b) $1M
   c) $2.1M
   d) $21.6M

3. What RCA technique uses iterative questioning?
   a) Fishbone diagram
   b) Timeline analysis
   c) Five Whys
   d) Pattern recognition

**Short Answer:**

4. Explain the difference between an immediate fix and a permanent fix. Provide an example.

5. Why is timeline correlation critical in troubleshooting?

6. Describe the components of an effective runbook.

**Essay Questions:**

7. Design a complete troubleshooting framework for your organization. Include:
   - Incident tracking system
   - Diagnostic procedures
   - RCA process
   - Knowledge management
   - Continuous improvement

8. Analyze the FinanceCore case study. What were the key factors in the rapid resolution? What preventative measures were most important?

**Hands-On Exercises:**

9. **Exercise 15.1: Incident Management**
   - Create incident tracking database
   - Implement diagnostic procedures
   - Build event timeline
   - Perform Five Whys analysis
   - Document lessons learned

10. **Exercise 15.2: Runbook Development**
    - Identify common issues
    - Create diagnostic steps
    - Document resolution procedures
    - Test runbook effectiveness
    - Measure resolution time improvement

11. **Exercise 15.3: Pattern Analysis**
    - Analyze 90 days of incidents
    - Identify recurring patterns
    - Calculate recurrence rates
    - Recommend preventative actions
    - Track action completion

12. **Exercise 15.4: Post-Incident Review**
    - Select critical incident
    - Conduct team review
    - Complete RCA (Five Whys)
    - Define preventative actions
    - Create lessons learned document

---

*End of Chapter 15*

**Next Chapter:** Chapter 16 - Capacity Planning

