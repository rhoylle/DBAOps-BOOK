# Chapter 17
# Disaster Recovery Testing

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Design** comprehensive DR test plans
2. **Execute** DR drills without impacting production
3. **Validate** RTO and RPO targets
4. **Document** DR test results
5. **Identify** gaps in DR procedures
6. **Improve** DR readiness continuously
7. **Automate** DR testing workflows
8. **Report** DR test outcomes to stakeholders

**Key Terms**

- DR Drill
- Tabletop Exercise
- Failover Test
- Failback Test
- RTO Validation
- RPO Validation
- Test Scenarios
- DR Scorecard
- Lessons Learned
- Continuous Improvement

---

## 17.1 DR Testing Framework

### 17.1.1 Types of DR Tests

**Figure 17.1: DR Testing Hierarchy**

```
┌─────────────────────────────────────────────────────────────┐
│              DR TESTING MATURITY LEVELS                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Level 1: DOCUMENTATION REVIEW                               │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Review DR procedures                             │    │
│  │ • Verify contact lists current                     │    │
│  │ • Check backup locations accessible                │    │
│  │ • Validate runbook completeness                    │    │
│  │ Frequency: Monthly                                 │    │
│  │ Impact: None (read-only)                           │    │
│  └────────────────────────────────────────────────────┘    │
│                          ↓                                   │
│  Level 2: TABLETOP EXERCISE                                  │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Walk through DR scenario                         │    │
│  │ • Team discusses actions                           │    │
│  │ • Identify gaps in procedures                      │    │
│  │ • No actual system changes                         │    │
│  │ Frequency: Quarterly                               │    │
│  │ Impact: None (discussion only)                     │    │
│  └────────────────────────────────────────────────────┘    │
│                          ↓                                   │
│  Level 3: COMPONENT TEST                                     │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Test individual components                       │    │
│  │ • Restore single database                          │    │
│  │ • Test AG failover                                 │    │
│  │ • Verify backup validity                           │    │
│  │ Frequency: Monthly                                 │    │
│  │ Impact: Low (isolated systems)                     │    │
│  └────────────────────────────────────────────────────┘    │
│                          ↓                                   │
│  Level 4: FULL DR DRILL                                      │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Complete failover to DR site                     │    │
│  │ • All systems tested together                      │    │
│  │ • Applications validated                           │    │
│  │ • Full failback to production                      │    │
│  │ Frequency: Semi-annual                             │    │
│  │ Impact: High (planned outage)                      │    │
│  └────────────────────────────────────────────────────┘    │
│                          ↓                                   │
│  Level 5: UNANNOUNCED TEST                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Surprise DR activation                           │    │
│  │ • Tests team readiness                             │    │
│  │ • Validates muscle memory                          │    │
│  │ • Most realistic scenario                          │    │
│  │ Frequency: Annual                                  │    │
│  │ Impact: Very High (surprise)                       │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 17.1.2 DR Test Planning

**Test plan database:**

```sql
CREATE TABLE dr.TestPlans (
    TestPlanID INT IDENTITY(1,1) PRIMARY KEY,
    TestName VARCHAR(200) NOT NULL,
    TestType VARCHAR(50) NOT NULL,  -- Documentation, Tabletop, Component, Full, Unannounced
    TestLevel INT NOT NULL,  -- 1-5 (corresponds to maturity levels)
    
    -- Scope
    ServersInScope NVARCHAR(MAX),  -- JSON array
    DatabasesInScope NVARCHAR(MAX),
    ApplicationsInScope NVARCHAR(MAX),
    
    -- Objectives
    TestObjectives NVARCHAR(MAX),
    SuccessCriteria NVARCHAR(MAX),
    
    -- Timing
    PlannedDate DATE,
    PlannedDuration_Minutes INT,
    BusinessImpact VARCHAR(500),
    
    -- Approval
    RequiresApproval BIT DEFAULT 1,
    ApprovedBy NVARCHAR(128),
    ApprovedDate DATE,
    
    -- Team
    TestLeader NVARCHAR(128),
    Participants NVARCHAR(MAX),
    
    IsActive BIT DEFAULT 1,
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    CreatedDate DATETIME2 DEFAULT SYSDATETIME()
);
GO

-- Test execution tracking
CREATE TABLE dr.TestExecutions (
    ExecutionID INT IDENTITY(1,1) PRIMARY KEY,
    TestPlanID INT NOT NULL,
    ExecutionNumber INT NOT NULL,
    
    -- Timing
    StartDateTime DATETIME2,
    EndDateTime DATETIME2,
    ActualDuration_Minutes AS DATEDIFF(MINUTE, StartDateTime, EndDateTime),
    
    -- Results
    Status VARCHAR(20),  -- InProgress, Passed, Failed, PartialSuccess
    RTOAchieved_Minutes INT,
    RPOAchieved_Minutes INT,
    RTOTarget_Minutes INT,
    RPOTarget_Minutes INT,
    
    -- Scoring
    OverallScore DECIMAL(5,2),  -- 0-100
    ComponentsPassed INT,
    ComponentsFailed INT,
    
    -- Issues
    IssuesIdentified NVARCHAR(MAX),
    LessonsLearned NVARCHAR(MAX),
    ActionItems NVARCHAR(MAX),
    
    -- Sign-off
    CompletedBy NVARCHAR(128),
    ReviewedBy NVARCHAR(128),
    ReviewedDate DATETIME2,
    
    FOREIGN KEY (TestPlanID) REFERENCES dr.TestPlans(TestPlanID)
);
GO

-- Test checklist items
CREATE TABLE dr.TestChecklistItems (
    ChecklistItemID INT IDENTITY(1,1) PRIMARY KEY,
    TestPlanID INT NOT NULL,
    ItemSequence INT NOT NULL,
    
    Category VARCHAR(50),  -- Preparation, Failover, Validation, Failback
    ItemDescription NVARCHAR(500),
    ExpectedResult NVARCHAR(500),
    
    IsRequired BIT DEFAULT 1,
    EstimatedDuration_Minutes INT,
    
    FOREIGN KEY (TestPlanID) REFERENCES dr.TestPlans(TestPlanID)
);
GO

-- Execution results per checklist item
CREATE TABLE dr.TestChecklistResults (
    ResultID BIGINT IDENTITY(1,1) PRIMARY KEY,
    ExecutionID INT NOT NULL,
    ChecklistItemID INT NOT NULL,
    
    StartTime DATETIME2,
    EndTime DATETIME2,
    ActualDuration_Minutes AS DATEDIFF(MINUTE, StartTime, EndTime),
    
    Status VARCHAR(20),  -- Passed, Failed, Skipped, Blocked
    ActualResult NVARCHAR(500),
    Issues NVARCHAR(MAX),
    
    PerformedBy NVARCHAR(128),
    
    FOREIGN KEY (ExecutionID) REFERENCES dr.TestExecutions(ExecutionID),
    FOREIGN KEY (ChecklistItemID) REFERENCES dr.TestChecklistItems(ChecklistItemID)
);
GO
```

---

## 17.2 Component Testing

### 17.2.1 Backup Restore Validation

**Monthly backup restore tests:**

```powershell
<#
.SYNOPSIS
    Automated backup restore validation

.DESCRIPTION
    Tests backup validity by restoring to test server
#>

function Test-BackupValidity {
    param(
        [Parameter(Mandatory)]
        [string]$SourceServer,
        
        [Parameter(Mandatory)]
        [string]$DatabaseName,
        
        [string]$TestServer = "DR-TEST-SQL01",
        
        [string]$BackupPath = "\\backup-server\SQLBackups"
    )
    
    $testDatabase = "${DatabaseName}_RestoreTest"
    $startTime = Get-Date
    
    Write-Host "Starting backup restore test for $DatabaseName..." -ForegroundColor Cyan
    
    try {
        # Find latest full backup
        $latestBackup = Get-DbaDbBackupHistory -SqlInstance $SourceServer `
                                                -Database $DatabaseName `
                                                -LastFull `
                                                -Raw | 
                        Select-Object -First 1
        
        if (!$latestBackup) {
            throw "No backup found for $DatabaseName"
        }
        
        $backupFile = $latestBackup.Path
        $backupAge = (Get-Date) - $latestBackup.End
        
        Write-Host "  Backup file: $backupFile" -ForegroundColor Gray
        Write-Host "  Backup age: $($backupAge.Hours) hours" -ForegroundColor Gray
        
        # Restore to test server
        Write-Host "  Restoring to test server..." -ForegroundColor Yellow
        
        Restore-DbaDatabase -SqlInstance $TestServer `
                           -Path $backupFile `
                           -DatabaseName $testDatabase `
                           -WithReplace `
                           -EnableException
        
        # Verify database
        $db = Get-DbaDatabase -SqlInstance $TestServer -Database $testDatabase
        
        if (!$db) {
            throw "Database restore failed - database not found"
        }
        
        # Run DBCC CHECKDB
        Write-Host "  Running DBCC CHECKDB..." -ForegroundColor Yellow
        
        $checkResult = Invoke-DbaQuery -SqlInstance $TestServer `
                                       -Database $testDatabase `
                                       -Query "DBCC CHECKDB WITH NO_INFOMSGS"
        
        # Check row counts (basic validation)
        $rowCounts = Invoke-DbaQuery -SqlInstance $TestServer `
                                     -Database $testDatabase `
                                     -Query @"
SELECT 
    s.name + '.' + t.name AS TableName,
    SUM(p.rows) AS RowCount
FROM sys.tables t
JOIN sys.schemas s ON t.schema_id = s.schema_id
JOIN sys.partitions p ON t.object_id = p.object_id
WHERE p.index_id IN (0, 1)
GROUP BY s.name, t.name
ORDER BY RowCount DESC
"@
        
        # Cleanup
        Remove-DbaDatabase -SqlInstance $TestServer `
                          -Database $testDatabase `
                          -Confirm:$false
        
        $endTime = Get-Date
        $duration = ($endTime - $startTime).TotalMinutes
        
        # Log results
        Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO dr.BackupValidationTests (
    ServerName, DatabaseName, BackupFile, BackupAge_Hours,
    RestoreDuration_Minutes, TableCount, TotalRows, Status
)
VALUES (
    '$SourceServer',
    '$DatabaseName',
    '$backupFile',
    $($backupAge.TotalHours),
    $duration,
    $($rowCounts.Count),
    $(($rowCounts | Measure-Object -Property RowCount -Sum).Sum),
    'Passed'
)
"@
        
        Write-Host "✓ Backup restore test PASSED ($([Math]::Round($duration, 2)) minutes)" -ForegroundColor Green
        
        return @{
            Status = 'Passed'
            Duration = $duration
            BackupAge = $backupAge.TotalHours
            TableCount = $rowCounts.Count
        }
    }
    catch {
        Write-Error "Backup restore test FAILED: $_"
        
        # Log failure
        Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO dr.BackupValidationTests (
    ServerName, DatabaseName, Status, ErrorMessage
)
VALUES (
    '$SourceServer',
    '$DatabaseName',
    'Failed',
    '$($_.Exception.Message.Replace("'", "''"))'
)
"@
        
        return @{
            Status = 'Failed'
            Error = $_.Exception.Message
        }
    }
}

# Test all critical databases monthly
$criticalDatabases = Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                                     -Database "DBAOpsRepository" `
                                     -Query @"
SELECT DISTINCT ServerName, DatabaseName
FROM config.DatabaseInventory
WHERE BusinessCriticality = 'Critical'
  AND IsActive = 1
"@

foreach ($db in $criticalDatabases) {
    Test-BackupValidity -SourceServer $db.ServerName `
                        -DatabaseName $db.DatabaseName
    Start-Sleep -Seconds 10
}
```

---

### 17.2.2 Always On AG Failover Testing

**Automated AG failover validation:**

```powershell
function Test-AGFailover {
    param(
        [Parameter(Mandatory)]
        [string]$AvailabilityGroup,
        
        [switch]$ActualFailover,
        [int]$WaitSeconds = 30
    )
    
    Write-Host "Testing Always On AG: $AvailabilityGroup" -ForegroundColor Cyan
    
    $startTime = Get-Date
    $results = @{
        PreFailoverPrimary = $null
        PreFailoverSecondary = $null
        FailoverDuration = $null
        PostFailoverPrimary = $null
        DataLoss = $false
        Success = $false
    }
    
    try {
        # Get current topology
        $agStatus = Get-DbaAgReplica -SqlInstance "DBAOps-Listener" `
                                     -AvailabilityGroup $AvailabilityGroup
        
        $currentPrimary = ($agStatus | Where-Object {$_.Role -eq 'Primary'}).Name
        $currentSecondary = ($agStatus | Where-Object {$_.Role -eq 'Secondary'})[0].Name
        
        $results.PreFailoverPrimary = $currentPrimary
        $results.PreFailoverSecondary = $currentSecondary
        
        Write-Host "  Current Primary: $currentPrimary" -ForegroundColor Gray
        Write-Host "  Current Secondary: $currentSecondary" -ForegroundColor Gray
        
        # Check synchronization state
        $syncState = Invoke-DbaQuery -SqlInstance $currentPrimary -Query @"
SELECT 
    ar.replica_server_name,
    drs.synchronization_state_desc,
    drs.synchronization_health_desc
FROM sys.dm_hadr_database_replica_states drs
JOIN sys.availability_replicas ar ON drs.replica_id = ar.replica_id
WHERE ar.replica_server_name = '$currentSecondary'
"@
        
        if ($syncState.synchronization_state_desc -ne 'SYNCHRONIZED') {
            throw "Secondary not synchronized. Cannot safely failover."
        }
        
        if ($ActualFailover) {
            Write-Host "  Performing actual failover..." -ForegroundColor Yellow
            
            # Failover to secondary
            Invoke-DbaAgFailover -SqlInstance $currentSecondary `
                                -AvailabilityGroup $AvailabilityGroup `
                                -Force `
                                -Confirm:$false
            
            # Wait for failover
            Start-Sleep -Seconds $WaitSeconds
            
            # Verify new primary
            $newTopology = Get-DbaAgReplica -SqlInstance "DBAOps-Listener" `
                                           -AvailabilityGroup $AvailabilityGroup
            
            $newPrimary = ($newTopology | Where-Object {$_.Role -eq 'Primary'}).Name
            $results.PostFailoverPrimary = $newPrimary
            
            if ($newPrimary -eq $currentSecondary) {
                Write-Host "  ✓ Failover successful to $newPrimary" -ForegroundColor Green
                
                # Failback to original primary
                Write-Host "  Failing back to original primary..." -ForegroundColor Yellow
                Start-Sleep -Seconds 10
                
                Invoke-DbaAgFailover -SqlInstance $currentPrimary `
                                    -AvailabilityGroup $AvailabilityGroup `
                                    -Force `
                                    -Confirm:$false
                
                Start-Sleep -Seconds $WaitSeconds
                
                $results.Success = $true
            }
            else {
                throw "Failover did not complete. Primary is still $newPrimary"
            }
        }
        else {
            Write-Host "  Simulation mode - no actual failover performed" -ForegroundColor Yellow
            $results.Success = $true
        }
        
        $endTime = Get-Date
        $results.FailoverDuration = ($endTime - $startTime).TotalMinutes
        
        # Log results
        Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO dr.AGFailoverTests (
    AvailabilityGroup, PreFailoverPrimary, TestType,
    FailoverDuration_Minutes, Status
)
VALUES (
    '$AvailabilityGroup',
    '$currentPrimary',
    '$(if($ActualFailover){'Actual'}else{'Simulation'})',
    $($results.FailoverDuration),
    'Passed'
)
"@
        
        return $results
    }
    catch {
        Write-Error "AG failover test FAILED: $_"
        $results.Success = $false
        
        # Log failure
        Invoke-DbaQuery -SqlInstance "DBAOps-Listener" `
                       -Database "DBAOpsRepository" `
                       -Query @"
INSERT INTO dr.AGFailoverTests (
    AvailabilityGroup, Status, ErrorMessage
)
VALUES (
    '$AvailabilityGroup',
    'Failed',
    '$($_.Exception.Message.Replace("'", "''"))'
)
"@
        
        return $results
    }
}
```

Let me continue with full DR drills, RTO/RPO validation, reporting, and a comprehensive case study:


---

## 17.3 Full DR Drill Execution

### 17.3.1 Complete DR Drill Procedure

```sql
-- DR Drill orchestration
CREATE PROCEDURE dr.usp_ExecuteDRDrill
    @TestPlanID INT,
    @ActualFailover BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @ExecutionID INT;
    DECLARE @StartTime DATETIME2 = SYSDATETIME();
    
    -- Create execution record
    INSERT INTO dr.TestExecutions (
        TestPlanID, ExecutionNumber, StartDateTime, Status,
        RTOTarget_Minutes, RPOTarget_Minutes
    )
    SELECT 
        @TestPlanID,
        ISNULL(MAX(ExecutionNumber), 0) + 1,
        @StartTime,
        'InProgress',
        300,  -- 5 hour RTO target
        0     -- 0 RPO target (AG synchronous)
    FROM dr.TestExecutions
    WHERE TestPlanID = @TestPlanID;
    
    SET @ExecutionID = SCOPE_IDENTITY();
    
    -- Execute checklist items in sequence
    DECLARE @ChecklistItemID INT, @ItemDesc NVARCHAR(500);
    DECLARE @ItemStatus VARCHAR(20), @ItemStart DATETIME2;
    DECLARE @ComponentsPassed INT = 0, @ComponentsFailed INT = 0;
    
    DECLARE checklist_cursor CURSOR FOR
    SELECT ChecklistItemID, ItemDescription
    FROM dr.TestChecklistItems
    WHERE TestPlanID = @TestPlanID
      AND IsRequired = 1
    ORDER BY ItemSequence;
    
    OPEN checklist_cursor;
    FETCH NEXT FROM checklist_cursor INTO @ChecklistItemID, @ItemDesc;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @ItemStart = SYSDATETIME();
        
        PRINT 'Executing: ' + @ItemDesc;
        
        -- Execute item (simplified - actual execution would call specific procedures)
        BEGIN TRY
            -- Placeholder for actual test execution
            WAITFOR DELAY '00:00:02';  -- Simulate execution
            
            SET @ItemStatus = 'Passed';
            SET @ComponentsPassed += 1;
        END TRY
        BEGIN CATCH
            SET @ItemStatus = 'Failed';
            SET @ComponentsFailed += 1;
        END CATCH
        
        -- Log result
        INSERT INTO dr.TestChecklistResults (
            ExecutionID, ChecklistItemID, StartTime, EndTime, Status, PerformedBy
        )
        VALUES (
            @ExecutionID, @ChecklistItemID, @ItemStart, SYSDATETIME(), @ItemStatus, SUSER_SNAME()
        );
        
        FETCH NEXT FROM checklist_cursor INTO @ChecklistItemID, @ItemDesc;
    END
    
    CLOSE checklist_cursor;
    DEALLOCATE checklist_cursor;
    
    -- Calculate results
    DECLARE @EndTime DATETIME2 = SYSDATETIME();
    DECLARE @RTOAchieved INT = DATEDIFF(MINUTE, @StartTime, @EndTime);
    DECLARE @Score DECIMAL(5,2) = (@ComponentsPassed * 100.0) / (@ComponentsPassed + @ComponentsFailed);
    
    -- Update execution
    UPDATE dr.TestExecutions
    SET EndDateTime = @EndTime,
        Status = CASE WHEN @ComponentsFailed = 0 THEN 'Passed' ELSE 'PartialSuccess' END,
        RTOAchieved_Minutes = @RTOAchieved,
        RPOAchieved_Minutes = 0,  -- Synchronous AG = 0 RPO
        OverallScore = @Score,
        ComponentsPassed = @ComponentsPassed,
        ComponentsFailed = @ComponentsFailed
    WHERE ExecutionID = @ExecutionID;
    
    -- Generate summary
    SELECT 
        'DR Drill Summary' AS Report,
        @ExecutionID AS ExecutionID,
        @StartTime AS StartTime,
        @EndTime AS EndTime,
        @RTOAchieved AS RTO_Achieved_Minutes,
        300 AS RTO_Target_Minutes,
        CASE WHEN @RTOAchieved <= 300 THEN 'PASS' ELSE 'FAIL' END AS RTO_Status,
        @ComponentsPassed AS ComponentsPassed,
        @ComponentsFailed AS ComponentsFailed,
        @Score AS OverallScore;
END
GO
```

---

## 17.4 RTO/RPO Validation

### 17.4.1 Measuring Recovery Times

```sql
CREATE VIEW dr.vw_RTOAnalysis AS
WITH ExecutionMetrics AS (
    SELECT 
        te.ExecutionID,
        tp.TestName,
        te.StartDateTime,
        te.EndDateTime,
        te.ActualDuration_Minutes,
        te.RTOTarget_Minutes,
        te.RTOAchieved_Minutes,
        
        -- RTO compliance
        CASE 
            WHEN te.RTOAchieved_Minutes <= te.RTOTarget_Minutes THEN 'Met'
            WHEN te.RTOAchieved_Minutes <= te.RTOTarget_Minutes * 1.2 THEN 'Near Miss'
            ELSE 'Exceeded'
        END AS RTOCompliance,
        
        -- Breakdown by phase
        (SELECT SUM(DATEDIFF(MINUTE, StartTime, EndTime))
         FROM dr.TestChecklistResults tcr
         JOIN dr.TestChecklistItems tci ON tcr.ChecklistItemID = tci.ChecklistItemID
         WHERE tcr.ExecutionID = te.ExecutionID
           AND tci.Category = 'Preparation') AS Preparation_Minutes,
           
        (SELECT SUM(DATEDIFF(MINUTE, StartTime, EndTime))
         FROM dr.TestChecklistResults tcr
         JOIN dr.TestChecklistItems tci ON tcr.ChecklistItemID = tci.ChecklistItemID
         WHERE tcr.ExecutionID = te.ExecutionID
           AND tci.Category = 'Failover') AS Failover_Minutes,
           
        (SELECT SUM(DATEDIFF(MINUTE, StartTime, EndTime))
         FROM dr.TestChecklistResults tcr
         JOIN dr.TestChecklistItems tci ON tcr.ChecklistItemID = tci.ChecklistItemID
         WHERE tcr.ExecutionID = te.ExecutionID
           AND tci.Category = 'Validation') AS Validation_Minutes
    FROM dr.TestExecutions te
    JOIN dr.TestPlans tp ON te.TestPlanID = tp.TestPlanID
)
SELECT 
    TestName,
    StartDateTime,
    RTOTarget_Minutes,
    RTOAchieved_Minutes,
    RTOAchieved_Minutes - RTOTarget_Minutes AS RTO_Variance,
    RTOCompliance,
    Preparation_Minutes,
    Failover_Minutes,
    Validation_Minutes
FROM ExecutionMetrics;
GO
```

---

## 17.5 DR Scorecard

### 17.5.1 Quarterly DR Report

```sql
CREATE PROCEDURE dr.usp_GenerateDRScorecard
    @Quarter INT,
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @StartDate DATE = DATEFROMPARTS(@Year, (@Quarter - 1) * 3 + 1, 1);
    DECLARE @EndDate DATE = EOMONTH(DATEADD(MONTH, 2, @StartDate));
    
    -- Overall DR readiness score
    WITH QuarterlyTests AS (
        SELECT 
            COUNT(*) AS TotalTests,
            SUM(CASE WHEN Status = 'Passed' THEN 1 ELSE 0 END) AS PassedTests,
            AVG(OverallScore) AS AvgScore,
            AVG(RTOAchieved_Minutes) AS AvgRTO,
            MAX(RTOTarget_Minutes) AS TargetRTO
        FROM dr.TestExecutions
        WHERE StartDateTime BETWEEN @StartDate AND @EndDate
    ),
    BackupValidation AS (
        SELECT 
            COUNT(*) AS TotalBackupTests,
            SUM(CASE WHEN Status = 'Passed' THEN 1 ELSE 0 END) AS PassedBackupTests
        FROM dr.BackupValidationTests
        WHERE TestDate BETWEEN @StartDate AND @EndDate
    ),
    AGTests AS (
        SELECT 
            COUNT(*) AS TotalAGTests,
            SUM(CASE WHEN Status = 'Passed' THEN 1 ELSE 0 END) AS PassedAGTests,
            AVG(FailoverDuration_Minutes) AS AvgAGFailoverTime
        FROM dr.AGFailoverTests
        WHERE TestDate BETWEEN @StartDate AND @EndDate
    )
    SELECT 
        'Q' + CAST(@Quarter AS VARCHAR) + ' ' + CAST(@Year AS VARCHAR) AS ReportPeriod,
        
        -- Test execution
        qt.TotalTests,
        qt.PassedTests,
        qt.TotalTests - qt.PassedTests AS FailedTests,
        qt.AvgScore AS AvgTestScore,
        
        -- RTO Performance
        qt.AvgRTO AS AvgRTO_Achieved,
        qt.TargetRTO AS RTO_Target,
        CASE 
            WHEN qt.AvgRTO <= qt.TargetRTO THEN 'PASS'
            ELSE 'FAIL'
        END AS RTO_Status,
        
        -- Component tests
        bv.TotalBackupTests,
        bv.PassedBackupTests,
        CAST(bv.PassedBackupTests * 100.0 / NULLIF(bv.TotalBackupTests, 0) AS DECIMAL(5,2)) AS BackupSuccessRate,
        
        ag.TotalAGTests,
        ag.PassedAGTests,
        ag.AvgAGFailoverTime,
        
        -- Overall DR Readiness Score (0-100)
        (
            (qt.AvgScore * 0.4) +  -- 40% weight on overall test score
            (CASE WHEN qt.AvgRTO <= qt.TargetRTO THEN 100 ELSE 50 END * 0.3) +  -- 30% weight on RTO
            ((bv.PassedBackupTests * 100.0 / NULLIF(bv.TotalBackupTests, 0)) * 0.2) +  -- 20% weight on backups
            ((ag.PassedAGTests * 100.0 / NULLIF(ag.TotalAGTests, 0)) * 0.1)  -- 10% weight on AG
        ) AS OverallDRReadiness,
        
        -- Status
        CASE 
            WHEN (qt.AvgScore * 0.4 + 
                  CASE WHEN qt.AvgRTO <= qt.TargetRTO THEN 100 ELSE 50 END * 0.3 + 
                  (bv.PassedBackupTests * 100.0 / NULLIF(bv.TotalBackupTests, 0)) * 0.2 + 
                  (ag.PassedAGTests * 100.0 / NULLIF(ag.TotalAGTests, 0)) * 0.1) >= 90 
            THEN 'Excellent'
            WHEN (qt.AvgScore * 0.4 + 
                  CASE WHEN qt.AvgRTO <= qt.TargetRTO THEN 100 ELSE 50 END * 0.3 + 
                  (bv.PassedBackupTests * 100.0 / NULLIF(bv.TotalBackupTests, 0)) * 0.2 + 
                  (ag.PassedAGTests * 100.0 / NULLIF(ag.TotalAGTests, 0)) * 0.1) >= 75 
            THEN 'Good'
            WHEN (qt.AvgScore * 0.4 + 
                  CASE WHEN qt.AvgRTO <= qt.TargetRTO THEN 100 ELSE 50 END * 0.3 + 
                  (bv.PassedBackupTests * 100.0 / NULLIF(bv.TotalBackupTests, 0)) * 0.2 + 
                  (ag.PassedAGTests * 100.0 / NULLIF(ag.TotalAGTests, 0)) * 0.1) >= 60 
            THEN 'Needs Improvement'
            ELSE 'Critical - Immediate Action Required'
        END AS DRReadinessStatus
    FROM QuarterlyTests qt
    CROSS JOIN BackupValidation bv
    CROSS JOIN AGTests ag;
END
GO
```

---

## 17.6 Case Study: Financial Institution DR Testing

**Background:** RegionalBank, 80 SQL Servers, strict regulatory requirements for DR testing.

**The Challenge:**
- Required semi-annual DR tests (regulatory)
- Never actually tested full DR (too risky)
- Relied on backup restores only
- No confidence in 4-hour RTO claim
- Auditors flagged DR program as inadequate

**6-Month DR Testing Program:**

**Month 1-2: Foundation**
- Implemented DBAOps DR testing framework
- Created 47 test checklist items
- Established DR scorecard
- Baseline: 0 full DR tests ever

**Month 3: Component Testing**
- 80 backup restore validations (100% success)
- 12 AG failover tests (92% success)
- Identified 8 gaps in procedures

**Month 4: Tabletop Exercise**
- Full team walkthrough
- Updated runbooks based on findings
- Added 12 missing checklist items

**Month 5-6: Full DR Drill**
- Complete failover to DR site
- All 80 servers tested
- Applications validated

**Results:**

| Metric | Before | After 6 Months | Result |
|--------|--------|----------------|--------|
| **Testing** ||||
| Full DR drills | 0/year | 2/year | Compliance |
| Component tests | 0 | 240/year | Validated |
| Backup tests | Manual | 100% automated | Systematic |
| AG failover tests | 0 | 24/year | Routine |
| **Performance** ||||
| RTO claimed | 4 hours | 2.8 hours | **30% better** |
| RTO validated | Never | Yes | Proven |
| RPO | "Near zero" | 0 min validated | Proven |
| Test success rate | N/A | 94% | High confidence |
| **Gaps Identified** ||||
| Procedure gaps | Unknown | 23 found | Addressed |
| Documentation gaps | Unknown | 12 found | Updated |
| Tool/access issues | Unknown | 5 found | Resolved |
| **Compliance** ||||
| Audit findings | 3 critical | 0 | **Clean audit** |
| Regulatory compliance | Questionable | 100% | Documented |
| Board confidence | Low | High | Demonstrated |

**Financial Impact:**
- Avoided regulatory fines: $500K (estimated)
- Audit remediation avoided: $200K
- Prevented potential data loss incident: $3M+
**Total Value: $3.7M**

**Investment:** $85K (DR testing program)
**ROI: 4,253%**

**Audit Committee Chair:**
*"For the first time, we have documented evidence that our DR program works. The quarterly scorecards give the board confidence that we can actually recover within our stated RTO."*

---

## Chapter 17 Summary

**Key Takeaways:**
1. Test DR procedures regularly (quarterly minimum)
2. Use 5-level maturity model
3. Validate RTO/RPO with actual tests
4. Document all test results
5. Track improvements over time
6. Automate component tests monthly
7. Full DR drill semi-annually

**Production Implementation:**
✅ DR test planning framework
✅ Automated backup restore validation
✅ AG failover testing
✅ RTO/RPO measurement
✅ DR scorecard reporting
✅ Compliance documentation

**Business Value:**
✅ 94% test success rate
✅ 30% better RTO than claimed
✅ 100% regulatory compliance
✅ $3.7M value (RegionalBank)
✅ 4,253% ROI
✅ Clean audit results

**Next Chapter:** Chapter 18 - Data Governance

