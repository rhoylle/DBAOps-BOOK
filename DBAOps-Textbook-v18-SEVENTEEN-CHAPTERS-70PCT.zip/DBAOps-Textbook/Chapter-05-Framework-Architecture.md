# Chapter 5
# Framework Architecture Overview

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Understand** the complete DBAOps framework architecture and component interactions
2. **Design** database schema for monitoring, configuration, and logging
3. **Implement** ETL processes for data collection and aggregation
4. **Configure** automated alerting and notification systems
5. **Deploy** the framework across distributed enterprise environments
6. **Optimize** data retention and archival strategies
7. **Secure** the framework with role-based access control
8. **Integrate** with existing enterprise monitoring solutions

**Key Terms**

- Repository Database
- ETL (Extract, Transform, Load)
- Data Warehouse Star Schema
- Fact Tables
- Dimension Tables
- Data Collection Agent
- Alerting Engine
- Configuration Management Database (CMDB)
- Data Retention Policy
- Archive Strategy
- Role-Based Access Control (RBAC)

---

## 5.1 Framework Overview

### 5.1.1 High-Level Architecture

The DBAOps framework is a comprehensive monitoring, compliance, and automation solution built on SQL Server and PowerShell.

**Figure 5.1: Complete Framework Architecture**

```
┌─────────────────────────────────────────────────────────────────────┐
│                        DBAOPS FRAMEWORK                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                    PRESENTATION LAYER                       │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │    │
│  │  │  Power   │  │  SSRS    │  │  Custom  │  │  REST    │  │    │
│  │  │   BI     │  │ Reports  │  │   Web    │  │   API    │  │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │    │
│  └────────────────────────────────────────────────────────────┘    │
│                              ↕                                       │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │              REPOSITORY DATABASE LAYER                      │    │
│  │                                                             │    │
│  │  ┌─────────────────────────────────────────────────────┐  │    │
│  │  │  FACT TABLES (Metrics & Measurements)               │  │    │
│  │  │  • fact.PerformanceMetrics                          │  │    │
│  │  │  • fact.BackupHistory                               │  │    │
│  │  │  • fact.QueryPerformance                            │  │    │
│  │  │  • fact.DiskUtilization                             │  │    │
│  │  └─────────────────────────────────────────────────────┘  │    │
│  │                                                             │    │
│  │  ┌─────────────────────────────────────────────────────┐  │    │
│  │  │  DIMENSION TABLES (Context & Metadata)              │  │    │
│  │  │  • dim.Server                                       │  │    │
│  │  │  • dim.Database                                     │  │    │
│  │  │  • dim.Time                                         │  │    │
│  │  └─────────────────────────────────────────────────────┘  │    │
│  │                                                             │    │
│  │  ┌─────────────────────────────────────────────────────┐  │    │
│  │  │  CONFIGURATION SCHEMA (Settings & Rules)            │  │    │
│  │  │  • config.ServerInventory                           │  │    │
│  │  │  • config.BackupSLARules                            │  │    │
│  │  │  • config.AlertThresholds                           │  │    │
│  │  └─────────────────────────────────────────────────────┘  │    │
│  │                                                             │    │
│  │  ┌─────────────────────────────────────────────────────┐  │    │
│  │  │  CONTROL TABLES (Monitoring & Compliance)           │  │    │
│  │  │  • ctl.BackupCompliance                             │  │    │
│  │  │  • ctl.ReplicationHealth                            │  │    │
│  │  │  • ctl.TransactionLogUsage                          │  │    │
│  │  └─────────────────────────────────────────────────────┘  │    │
│  │                                                             │    │
│  │  ┌─────────────────────────────────────────────────────┐  │    │
│  │  │  LOGGING SCHEMA (Audit Trail)                       │  │    │
│  │  │  • log.CollectionActivity                           │  │    │
│  │  │  • log.FailureLog                                   │  │    │
│  │  │  • log.AlertHistory                                 │  │    │
│  │  └─────────────────────────────────────────────────────┘  │    │
│  │                                                             │    │
│  │  ┌─────────────────────────────────────────────────────┐  │    │
│  │  │  ALERT SCHEMA (Notification Management)             │  │    │
│  │  │  • alert.AlertRules                                 │  │    │
│  │  │  • alert.AlertQueue                                 │  │    │
│  │  │  • alert.EscalationPolicy                           │  │    │
│  │  └─────────────────────────────────────────────────────┘  │    │
│  └────────────────────────────────────────────────────────────┘    │
│                              ↕                                       │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                 DATA COLLECTION LAYER                       │    │
│  │                                                             │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │    │
│  │  │  PowerShell  │  │  SQL Agent   │  │   Extended   │    │    │
│  │  │   Collector  │  │     Jobs     │  │    Events    │    │    │
│  │  │   (Parallel) │  │              │  │              │    │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘    │    │
│  │         ↓                 ↓                  ↓            │    │
│  │  [ETL Processes - Extract, Transform, Load]              │    │
│  └────────────────────────────────────────────────────────────┘    │
│                              ↕                                       │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                 MONITORED SERVERS LAYER                     │    │
│  │                                                             │    │
│  │  [SQL01] [SQL02] [SQL03] ... [SQL150]                     │    │
│  │                                                             │    │
│  │  • Performance DMVs                                        │    │
│  │  • Backup history                                          │    │
│  │  • Query stats                                             │    │
│  │  • Disk space                                              │    │
│  │  • Always On AG status                                     │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

**Key Components:**

1. **Repository Database**: Centralized SQL Server database storing all collected metrics
2. **Data Collection Layer**: PowerShell scripts running on schedule to gather data
3. **ETL Processes**: Transform raw data into analytical format
4. **Alerting Engine**: Monitors thresholds and sends notifications
5. **Presentation Layer**: Reports, dashboards, and APIs for data access

---

### 5.1.2 Design Principles

The framework follows enterprise architecture best practices:

**1. Separation of Concerns**
- Configuration data separate from operational data
- Collection logic separate from storage logic
- Alerting separate from monitoring

**2. Scalability**
- Parallel collection supports 1000+ servers
- Partitioned fact tables for high-volume data
- Archive strategy for historical data

**3. Reliability**
- Comprehensive error handling
- Retry logic for transient failures
- Audit trail for all operations

**4. Security**
- Role-based access control
- Encrypted connections
- Credential management
- Audit logging

**5. Maintainability**
- Modular design
- Clear naming conventions
- Comprehensive documentation
- Version control

**6. Performance**
- Indexed dimension tables
- Columnstore indexes for fact tables
- Query optimization
- Data compression

---

## 5.2 Database Schema Design

### 5.2.1 Schema Organization

The repository database uses multiple schemas for logical organization:

**Table 5.1: Schema Purposes**

| Schema | Purpose | Example Tables | Record Lifetime |
|--------|---------|----------------|-----------------|
| **fact** | Measurement data (high volume) | PerformanceMetrics, BackupHistory | 90 days → Archive |
| **dim** | Dimension/reference data | Server, Database, Time | Permanent |
| **config** | Configuration settings | ServerInventory, SLARules | Permanent |
| **ctl** | Control/compliance checks | BackupCompliance, ReplicationHealth | 30 days |
| **log** | Audit and diagnostic logs | CollectionActivity, FailureLog | 180 days |
| **alert** | Alerting and notifications | AlertRules, AlertQueue | 90 days |
| **security** | Access control | LoginInventory, Permissions | Permanent |
| **meta** | Framework metadata | Version, Configuration | Permanent |

---

### 5.2.2 Dimension Tables (Star Schema)

**Dimension tables** provide context for fact data.

**dim.Server:**

```sql
CREATE TABLE dim.Server (
    ServerKey INT IDENTITY(1,1) PRIMARY KEY,
    ServerName NVARCHAR(128) NOT NULL UNIQUE,
    Environment VARCHAR(20) NOT NULL,  -- Production, QA, Development
    DataCenter VARCHAR(50),
    Cluster VARCHAR(50),
    Edition VARCHAR(50),
    Version VARCHAR(50),
    OSVersion VARCHAR(100),
    TotalMemoryGB INT,
    ProcessorCount INT,
    IsVirtual BIT,
    OwnerTeam VARCHAR(100),
    CostCenter VARCHAR(50),
    ComplianceRequired BIT,
    MonitoringEnabled BIT DEFAULT 1,
    CollectionFrequencyMinutes INT DEFAULT 5,
    ValidFrom DATETIME2 DEFAULT SYSDATETIME(),
    ValidTo DATETIME2,
    IsCurrent BIT DEFAULT 1,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME()
);

CREATE NONCLUSTERED INDEX IX_Server_ServerName 
    ON dim.Server(ServerName) INCLUDE (ServerKey, Environment);

CREATE NONCLUSTERED INDEX IX_Server_Environment 
    ON dim.Server(Environment, MonitoringEnabled) 
    WHERE IsCurrent = 1;
```

**dim.Database:**

```sql
CREATE TABLE dim.Database (
    DatabaseKey INT IDENTITY(1,1) PRIMARY KEY,
    ServerKey INT NOT NULL FOREIGN KEY REFERENCES dim.Server(ServerKey),
    DatabaseName NVARCHAR(128) NOT NULL,
    RecoveryModel VARCHAR(20),
    CompatibilityLevel INT,
    Collation NVARCHAR(128),
    ApplicationName VARCHAR(100),
    BusinessCriticality VARCHAR(20),  -- Critical, High, Medium, Low
    BackupSLALevel VARCHAR(20),  -- Platinum, Gold, Silver, Bronze
    ValidFrom DATETIME2 DEFAULT SYSDATETIME(),
    ValidTo DATETIME2,
    IsCurrent BIT DEFAULT 1,
    CONSTRAINT UQ_Database UNIQUE (ServerKey, DatabaseName, ValidFrom)
);

CREATE NONCLUSTERED INDEX IX_Database_ServerKey 
    ON dim.Database(ServerKey) 
    INCLUDE (DatabaseKey, DatabaseName) 
    WHERE IsCurrent = 1;
```

**dim.Time (Pre-populated):**

```sql
CREATE TABLE dim.Time (
    TimeKey INT PRIMARY KEY,  -- Format: YYYYMMDD
    FullDate DATE NOT NULL,
    Year INT NOT NULL,
    Quarter INT NOT NULL,
    Month INT NOT NULL,
    MonthName VARCHAR(20),
    Week INT NOT NULL,
    DayOfMonth INT NOT NULL,
    DayOfWeek INT NOT NULL,
    DayName VARCHAR(20),
    IsWeekend BIT,
    IsHoliday BIT,
    FiscalYear INT,
    FiscalQuarter INT,
    FiscalMonth INT
);

-- Populate time dimension (10 years)
DECLARE @StartDate DATE = '2020-01-01';
DECLARE @EndDate DATE = '2029-12-31';
DECLARE @CurrentDate DATE = @StartDate;

WHILE @CurrentDate <= @EndDate
BEGIN
    INSERT INTO dim.Time (
        TimeKey, FullDate, Year, Quarter, Month, MonthName,
        Week, DayOfMonth, DayOfWeek, DayName, IsWeekend
    )
    VALUES (
        CAST(FORMAT(@CurrentDate, 'yyyyMMdd') AS INT),
        @CurrentDate,
        YEAR(@CurrentDate),
        DATEPART(QUARTER, @CurrentDate),
        MONTH(@CurrentDate),
        DATENAME(MONTH, @CurrentDate),
        DATEPART(WEEK, @CurrentDate),
        DAY(@CurrentDate),
        DATEPART(WEEKDAY, @CurrentDate),
        DATENAME(WEEKDAY, @CurrentDate),
        CASE WHEN DATEPART(WEEKDAY, @CurrentDate) IN (1, 7) THEN 1 ELSE 0 END
    );
    
    SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate);
END
```

---

### 5.2.3 Fact Tables (Measurements)

**Fact tables** store high-volume measurement data using columnstore indexes.

**fact.PerformanceMetrics:**

```sql
CREATE TABLE fact.PerformanceMetrics (
    MetricKey BIGINT IDENTITY(1,1) NOT NULL,
    ServerKey INT NOT NULL,
    TimeKey INT NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    
    -- CPU Metrics
    CPUUtilizationPercent DECIMAL(5,2),
    SQLProcessCPUPercent DECIMAL(5,2),
    
    -- Memory Metrics
    TotalMemoryMB BIGINT,
    AvailableMemoryMB BIGINT,
    PageLifeExpectancy INT,
    BufferCacheHitRatio DECIMAL(5,2),
    
    -- I/O Metrics
    ReadLatencyMS DECIMAL(10,2),
    WriteLatencyMS DECIMAL(10,2),
    IOStallMS BIGINT,
    
    -- SQL Server Metrics
    BatchRequestsPerSec INT,
    SQLCompilationsPerSec INT,
    UserConnections INT,
    
    -- Wait Statistics
    TopWaitType VARCHAR(100),
    TopWaitTimeMS BIGINT,
    
    -- Performance Score (calculated)
    PerformanceScore DECIMAL(5,2),
    
    INDEX NCCI_PerformanceMetrics CLUSTERED COLUMNSTORE
) ON [PRIMARY];

-- Non-clustered rowstore index for point lookups
CREATE NONCLUSTERED INDEX IX_PerformanceMetrics_ServerTime
    ON fact.PerformanceMetrics(ServerKey, CollectionDateTime)
    INCLUDE (CPUUtilizationPercent, PageLifeExpectancy);

-- Partition by month for efficient archival
CREATE PARTITION FUNCTION PF_Monthly (DATETIME2)
AS RANGE RIGHT FOR VALUES (
    '2024-01-01', '2024-02-01', '2024-03-01', '2024-04-01',
    '2024-05-01', '2024-06-01', '2024-07-01', '2024-08-01',
    '2024-09-01', '2024-10-01', '2024-11-01', '2024-12-01',
    '2025-01-01'  -- Continue adding months
);

CREATE PARTITION SCHEME PS_Monthly
AS PARTITION PF_Monthly
ALL TO ([PRIMARY]);  -- In production, use separate filegroups

-- Apply partitioning
CREATE TABLE fact.PerformanceMetrics_Partitioned (
    MetricKey BIGINT IDENTITY(1,1) NOT NULL,
    ServerKey INT NOT NULL,
    TimeKey INT NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    -- ... (same columns as above)
    INDEX NCCI_PerformanceMetrics CLUSTERED COLUMNSTORE
) ON PS_Monthly(CollectionDateTime);
```

**fact.BackupHistory:**

```sql
CREATE TABLE fact.BackupHistory (
    BackupKey BIGINT IDENTITY(1,1) NOT NULL,
    ServerKey INT NOT NULL,
    DatabaseKey INT NOT NULL,
    TimeKey INT NOT NULL,
    BackupDateTime DATETIME2 NOT NULL,
    
    BackupType VARCHAR(20) NOT NULL,  -- FULL, DIFF, LOG
    BackupSizeMB DECIMAL(18,2),
    CompressedSizeMB DECIMAL(18,2),
    CompressionRatio DECIMAL(5,2),
    DurationSeconds INT,
    BackupSetID INT,
    BackupFile NVARCHAR(500),
    IsEncrypted BIT,
    IsCopyOnly BIT,
    RecoveryModel VARCHAR(20),
    
    -- Verification
    IsVerified BIT,
    VerificationDate DATETIME2,
    
    -- Compliance
    MeetsSLA BIT,
    SLALevel VARCHAR(20),
    
    INDEX NCCI_BackupHistory CLUSTERED COLUMNSTORE
) ON [PRIMARY];

CREATE NONCLUSTERED INDEX IX_BackupHistory_DatabaseTime
    ON fact.BackupHistory(DatabaseKey, BackupDateTime DESC)
    INCLUDE (BackupType, BackupSizeMB, MeetsSLA);
```

**fact.QueryPerformance:**

```sql
CREATE TABLE fact.QueryPerformance (
    QueryKey BIGINT IDENTITY(1,1) NOT NULL,
    ServerKey INT NOT NULL,
    DatabaseKey INT NOT NULL,
    TimeKey INT NOT NULL,
    SnapshotDateTime DATETIME2 NOT NULL,
    
    QueryHash BINARY(8),
    QueryPlanHash BINARY(8),
    QueryTextHash AS CONVERT(BINARY(8), HASHBYTES('SHA1', QueryText)),
    QueryText NVARCHAR(MAX),
    
    ExecutionCount BIGINT,
    TotalElapsedTimeMS BIGINT,
    TotalCPUTimeMS BIGINT,
    TotalLogicalReads BIGINT,
    TotalPhysicalReads BIGINT,
    TotalWrites BIGINT,
    
    -- Calculated metrics
    AvgElapsedTimeMS AS CASE WHEN ExecutionCount > 0 
        THEN TotalElapsedTimeMS / ExecutionCount ELSE 0 END PERSISTED,
    AvgCPUTimeMS AS CASE WHEN ExecutionCount > 0 
        THEN TotalCPUTimeMS / ExecutionCount ELSE 0 END PERSISTED,
    AvgLogicalReads AS CASE WHEN ExecutionCount > 0 
        THEN TotalLogicalReads / ExecutionCount ELSE 0 END PERSISTED,
    
    INDEX NCCI_QueryPerformance CLUSTERED COLUMNSTORE
) ON [PRIMARY];

CREATE NONCLUSTERED INDEX IX_QueryPerformance_TopCPU
    ON fact.QueryPerformance(ServerKey, TotalCPUTimeMS DESC)
    INCLUDE (QueryHash, QueryText, ExecutionCount);
```

---

### 5.2.4 Configuration Tables

**config.ServerInventory:**

```sql
CREATE TABLE config.ServerInventory (
    ServerInventoryID INT IDENTITY(1,1) PRIMARY KEY,
    ServerName NVARCHAR(128) NOT NULL UNIQUE,
    Environment VARCHAR(20) NOT NULL 
        CHECK (Environment IN ('Production', 'QA', 'Development', 'DR')),
    DataCenter VARCHAR(50),
    
    -- Collection settings
    IsActive BIT DEFAULT 1,
    MonitoringEnabled BIT DEFAULT 1,
    CollectionFrequencyMinutes INT DEFAULT 5,
    ParallelCollectionGroup INT DEFAULT 1,  -- For batching
    
    -- Authentication
    UseWindowsAuth BIT DEFAULT 1,
    CredentialName VARCHAR(100),
    
    -- SLA and compliance
    BusinessCriticality VARCHAR(20) DEFAULT 'Medium'
        CHECK (BusinessCriticality IN ('Critical', 'High', 'Medium', 'Low')),
    ComplianceFramework VARCHAR(50),  -- SOX, HIPAA, PCI-DSS, etc.
    RequiresEncryption BIT DEFAULT 0,
    
    -- Contacts
    OwnerTeam VARCHAR(100),
    PrimaryContact VARCHAR(100),
    SecondaryContact VARCHAR(100),
    
    -- Metadata
    Notes NVARCHAR(MAX),
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedBy NVARCHAR(128) DEFAULT SUSER_SNAME()
);

CREATE NONCLUSTERED INDEX IX_ServerInventory_Active
    ON config.ServerInventory(IsActive, MonitoringEnabled)
    INCLUDE (ServerName, CollectionFrequencyMinutes);
```

**config.BackupSLARules:**

```sql
CREATE TABLE config.BackupSLARules (
    SLARuleID INT IDENTITY(1,1) PRIMARY KEY,
    SLALevel VARCHAR(20) NOT NULL UNIQUE
        CHECK (SLALevel IN ('Platinum', 'Gold', 'Silver', 'Bronze')),
    
    -- Full backup requirements
    FullBackupFrequencyHours INT NOT NULL,
    FullBackupMaxAgeHours INT NOT NULL,
    
    -- Differential backup requirements
    DiffBackupFrequencyHours INT,
    DiffBackupMaxAgeHours INT,
    
    -- Log backup requirements (for FULL recovery model)
    LogBackupFrequencyMinutes INT,
    LogBackupMaxAgeMinutes INT,
    
    -- Retention requirements
    RetentionDays INT NOT NULL,
    
    -- Testing requirements
    RequiresRestoreTesting BIT DEFAULT 0,
    RestoreTestFrequencyDays INT,
    
    -- Verification
    RequiresChecksumVerification BIT DEFAULT 1,
    
    -- Compliance
    ComplianceNotes NVARCHAR(500)
);

-- Pre-populate SLA levels
INSERT INTO config.BackupSLARules (
    SLALevel, FullBackupFrequencyHours, FullBackupMaxAgeHours,
    DiffBackupFrequencyHours, DiffBackupMaxAgeHours,
    LogBackupFrequencyMinutes, LogBackupMaxAgeMinutes,
    RetentionDays, RequiresRestoreTesting, RestoreTestFrequencyDays
)
VALUES
    ('Platinum', 24, 24,  6,  6, 15, 30,  30, 1, 7),   -- Mission critical
    ('Gold',     24, 26, 12, 13, 30, 60,  14, 1, 14),  -- Production
    ('Silver',   24, 30, 24, 26, 60, 120,  7, 0, NULL), -- Standard
    ('Bronze',   48, 72, NULL, NULL, NULL, NULL, 7, 0, NULL); -- Non-critical
```

This is excellent progress! Let me continue with the ETL processes and alerting sections:


**config.AlertThresholds:**

```sql
CREATE TABLE config.AlertThresholds (
    AlertThresholdID INT IDENTITY(1,1) PRIMARY KEY,
    MetricName VARCHAR(100) NOT NULL,
    Severity VARCHAR(20) NOT NULL 
        CHECK (Severity IN ('Critical', 'High', 'Medium', 'Low', 'Info')),
    
    -- Threshold definition
    ThresholdType VARCHAR(20) NOT NULL 
        CHECK (ThresholdType IN ('GreaterThan', 'LessThan', 'Equals', 'NotEquals', 'Range')),
    ThresholdValue DECIMAL(18,2),
    ThresholdValueMin DECIMAL(18,2),  -- For range type
    ThresholdValueMax DECIMAL(18,2),  -- For range type
    
    -- Duration (must exceed threshold for this long)
    DurationMinutes INT DEFAULT 5,
    
    -- Suppression (prevent alert spam)
    SuppressionWindowMinutes INT DEFAULT 60,
    
    -- Escalation
    EscalationLevel INT DEFAULT 1,
    EscalationAfterOccurrences INT DEFAULT 3,
    
    -- Notification
    NotificationMethod VARCHAR(50) DEFAULT 'Email' 
        CHECK (NotificationMethod IN ('Email', 'SMS', 'Teams', 'PagerDuty', 'ServiceNow')),
    RecipientList NVARCHAR(500),
    
    -- Enabled/Disabled
    IsActive BIT DEFAULT 1,
    ActiveStartTime TIME,  -- Only alert during these hours
    ActiveEndTime TIME,
    
    CONSTRAINT UQ_AlertThreshold UNIQUE (MetricName, Severity)
);

-- Pre-populate common alert thresholds
INSERT INTO config.AlertThresholds (
    MetricName, Severity, ThresholdType, ThresholdValue, 
    DurationMinutes, NotificationMethod, RecipientList
)
VALUES
    ('CPUUtilizationPercent', 'Critical', 'GreaterThan', 95, 15, 'Email', 'dba-oncall@company.com'),
    ('CPUUtilizationPercent', 'High', 'GreaterThan', 85, 30, 'Email', 'dba-team@company.com'),
    ('PageLifeExpectancy', 'Critical', 'LessThan', 300, 10, 'Email', 'dba-oncall@company.com'),
    ('PageLifeExpectancy', 'High', 'LessThan', 600, 15, 'Email', 'dba-team@company.com'),
    ('DiskFreeSpacePercent', 'Critical', 'LessThan', 10, 5, 'Email', 'dba-oncall@company.com'),
    ('BackupAgeDays', 'Critical', 'GreaterThan', 2, 0, 'Email', 'dba-oncall@company.com');
```

---

### 5.2.5 Control Tables

**ctl.BackupCompliance:**

```sql
CREATE TABLE ctl.BackupCompliance (
    ComplianceCheckID BIGINT IDENTITY(1,1) PRIMARY KEY,
    ServerKey INT NOT NULL,
    DatabaseKey INT NOT NULL,
    CheckedDate DATETIME2 DEFAULT SYSDATETIME(),
    
    SLALevel VARCHAR(20),
    RecoveryModel VARCHAR(20),
    
    -- Full backup compliance
    LastFullBackup DATETIME2,
    FullBackupAgeDays AS DATEDIFF(DAY, LastFullBackup, CheckedDate) PERSISTED,
    FullBackupCompliant BIT,
    FullBackupSLAHours INT,
    
    -- Differential backup compliance
    LastDiffBackup DATETIME2,
    DiffBackupAgeHours AS DATEDIFF(HOUR, LastDiffBackup, CheckedDate) PERSISTED,
    DiffBackupCompliant BIT,
    
    -- Log backup compliance
    LastLogBackup DATETIME2,
    LogBackupAgeMinutes AS DATEDIFF(MINUTE, LastLogBackup, CheckedDate) PERSISTED,
    LogBackupCompliant BIT,
    
    -- Overall compliance
    IsCompliant AS CASE 
        WHEN FullBackupCompliant = 0 THEN 0
        WHEN RecoveryModel = 'FULL' AND (DiffBackupCompliant = 0 OR LogBackupCompliant = 0) THEN 0
        ELSE 1
    END PERSISTED,
    
    -- Violation details
    ViolationReason NVARCHAR(500),
    
    INDEX IX_BackupCompliance_NonCompliant 
        ON ctl.BackupCompliance(CheckedDate, IsCompliant)
        WHERE IsCompliant = 0
);
```

---

## 5.3 ETL Processes

### 5.3.1 Data Collection Architecture

**Collection Flow:**

```
1. SQL Agent Job triggers PowerShell script (every 5 minutes)
2. PowerShell reads server list from config.ServerInventory
3. Parallel collection using ForEach-Object -Parallel
4. Extract data from DMVs on each target server
5. Transform data (calculate metrics, apply business logic)
6. Load data into fact tables
7. Update control tables (compliance checks)
8. Trigger alerts if thresholds exceeded
```

**Master Collection Job:**

```sql
-- SQL Agent Job: DBAOps - Master Collector
-- Schedule: Every 5 minutes
-- Step 1: Execute PowerShell Collection Script

EXEC msdb.dbo.sp_start_job @job_name = 'DBAOps - Performance Collection';
EXEC msdb.dbo.sp_start_job @job_name = 'DBAOps - Backup Validation';
EXEC msdb.dbo.sp_start_job @job_name = 'DBAOps - Disk Space Monitoring';
```

**PowerShell Collection Script:**

```powershell
<#
.SYNOPSIS
    DBAOps Performance Metrics Collector

.DESCRIPTION
    Collects performance metrics from all active servers in parallel
    and loads into repository database
#>

param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository",
    [int]$ThrottleLimit = 20
)

$ErrorActionPreference = 'Continue'
Import-Module dbatools

# Get server list
$servers = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                           -Database $RepositoryDatabase `
                           -Query @"
SELECT ServerName, CollectionFrequencyMinutes
FROM config.ServerInventory
WHERE IsActive = 1 
  AND MonitoringEnabled = 1
  AND DATEDIFF(MINUTE, ISNULL(LastCollectionTime, '1900-01-01'), GETDATE()) 
      >= CollectionFrequencyMinutes
"@ -As PSObject

Write-Host "Collecting metrics from $($servers.Count) servers..."

# Parallel collection
$results = $servers | ForEach-Object -Parallel {
    $server = $_.ServerName
    $repoServer = $using:RepositoryServer
    $repoDB = $using:RepositoryDatabase
    
    Import-Module dbatools
    
    try {
        # Collect performance metrics
        $metrics = Invoke-DbaQuery -SqlInstance $server -Query @"
SELECT 
    @@SERVERNAME AS ServerName,
    GETDATE() AS CollectionDateTime,
    -- CPU
    (SELECT TOP 1 SQLProcessUtilization 
     FROM (
         SELECT record.value('(./Record/@id)[1]', 'int') AS record_id,
                record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS SystemIdle,
                record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS SQLProcessUtilization
         FROM (SELECT CAST(record AS XML) AS record 
               FROM sys.dm_os_ring_buffers 
               WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
               AND record LIKE '%<SystemHealth>%') AS x
     ) AS y
     ORDER BY record_id DESC) AS SQLProcessCPUPercent,
    -- Memory
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Page life expectancy' 
     AND object_name LIKE '%Buffer Manager%') AS PageLifeExpectancy,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Buffer cache hit ratio' 
     AND object_name LIKE '%Buffer Manager%') AS BufferCacheHitRatio,
    -- I/O
    (SELECT AVG(io_stall_read_ms / NULLIF(num_of_reads, 0))
     FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS AvgReadLatencyMS,
    (SELECT AVG(io_stall_write_ms / NULLIF(num_of_writes, 0))
     FROM sys.dm_io_virtual_file_stats(NULL, NULL)) AS AvgWriteLatencyMS,
    -- SQL Server
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'Batch Requests/sec' 
     AND object_name LIKE '%SQL Statistics%') AS BatchRequestsPerSec,
    (SELECT cntr_value FROM sys.dm_os_performance_counters 
     WHERE counter_name = 'SQL Compilations/sec' 
     AND object_name LIKE '%SQL Statistics%') AS SQLCompilationsPerSec,
    (SELECT COUNT(*) FROM sys.dm_exec_sessions 
     WHERE is_user_process = 1) AS UserConnections,
    -- Top wait
    (SELECT TOP 1 wait_type FROM sys.dm_os_wait_stats 
     WHERE wait_type NOT IN (SELECT wait_type FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'SLEEP%')
     ORDER BY wait_time_ms DESC) AS TopWaitType,
    (SELECT TOP 1 wait_time_ms FROM sys.dm_os_wait_stats 
     WHERE wait_type NOT IN (SELECT wait_type FROM sys.dm_os_wait_stats WHERE wait_type LIKE 'SLEEP%')
     ORDER BY wait_time_ms DESC) AS TopWaitTimeMS
"@
        
        # Insert into repository
        $insertQuery = @"
INSERT INTO fact.PerformanceMetrics (
    ServerKey, TimeKey, CollectionDateTime,
    CPUUtilizationPercent, SQLProcessCPUPercent,
    PageLifeExpectancy, BufferCacheHitRatio,
    ReadLatencyMS, WriteLatencyMS,
    BatchRequestsPerSec, SQLCompilationsPerSec,
    UserConnections, TopWaitType, TopWaitTimeMS
)
SELECT 
    s.ServerKey,
    CAST(FORMAT(GETDATE(), 'yyyyMMdd') AS INT) AS TimeKey,
    '$($metrics.CollectionDateTime)',
    NULL,  -- Overall CPU (would need WMI)
    $($metrics.SQLProcessCPUPercent),
    $($metrics.PageLifeExpectancy),
    $($metrics.BufferCacheHitRatio),
    $($metrics.AvgReadLatencyMS),
    $($metrics.AvgWriteLatencyMS),
    $($metrics.BatchRequestsPerSec),
    $($metrics.SQLCompilationsPerSec),
    $($metrics.UserConnections),
    '$($metrics.TopWaitType)',
    $($metrics.TopWaitTimeMS)
FROM dim.Server s
WHERE s.ServerName = '$server'
  AND s.IsCurrent = 1;

-- Update last collection time
UPDATE config.ServerInventory
SET LastCollectionTime = GETDATE()
WHERE ServerName = '$server';
"@
        
        Invoke-DbaQuery -SqlInstance $repoServer `
                       -Database $repoDB `
                       -Query $insertQuery
        
        [PSCustomObject]@{
            ServerName = $server
            Status = 'Success'
            MetricsCollected = $true
        }
    }
    catch {
        [PSCustomObject]@{
            ServerName = $server
            Status = 'Failed'
            Error = $_.Exception.Message
        }
    }
} -ThrottleLimit $ThrottleLimit

# Summary
$successCount = ($results | Where-Object {$_.Status -eq 'Success'}).Count
Write-Host "Collection complete: $successCount of $($servers.Count) successful"
```

---

### 5.3.2 Backup Validation ETL

```powershell
<#
.SYNOPSIS
    DBAOps Backup Compliance Validator

.DESCRIPTION
    Validates backup compliance against SLA rules
#>

param(
    [string]$RepositoryServer = "REPO-SQL01",
    [string]$RepositoryDatabase = "DBAOpsRepository"
)

Import-Module dbatools

# Get all databases that need compliance checking
$databases = Invoke-DbaQuery -SqlInstance $RepositoryServer `
                             -Database $RepositoryDatabase `
                             -Query @"
SELECT 
    s.ServerKey,
    s.ServerName,
    d.DatabaseKey,
    d.DatabaseName,
    d.RecoveryModel,
    d.BackupSLALevel,
    sla.FullBackupMaxAgeHours,
    sla.DiffBackupMaxAgeHours,
    sla.LogBackupMaxAgeMinutes
FROM dim.Server s
JOIN dim.Database d ON s.ServerKey = d.ServerKey
LEFT JOIN config.BackupSLARules sla ON d.BackupSLALevel = sla.SLALevel
WHERE s.MonitoringEnabled = 1
  AND d.IsCurrent = 1
  AND s.IsCurrent = 1
"@ -As PSObject

# Check each database
foreach ($db in $databases) {
    try {
        # Get backup history from target server
        $backupInfo = Invoke-DbaQuery -SqlInstance $db.ServerName `
                                      -Database 'msdb' `
                                      -Query @"
SELECT 
    MAX(CASE WHEN type = 'D' THEN backup_finish_date END) AS LastFullBackup,
    MAX(CASE WHEN type = 'I' THEN backup_finish_date END) AS LastDiffBackup,
    MAX(CASE WHEN type = 'L' THEN backup_finish_date END) AS LastLogBackup
FROM msdb.dbo.backupset
WHERE database_name = '$($db.DatabaseName)'
"@
        
        # Calculate compliance
        $fullAge = if ($backupInfo.LastFullBackup) {
            (New-TimeSpan -Start $backupInfo.LastFullBackup -End (Get-Date)).TotalHours
        } else { 999 }
        
        $fullCompliant = $fullAge -le $db.FullBackupMaxAgeHours
        
        # Insert compliance record
        $insertQuery = @"
INSERT INTO ctl.BackupCompliance (
    ServerKey, DatabaseKey, CheckedDate,
    SLALevel, RecoveryModel,
    LastFullBackup, FullBackupCompliant, FullBackupSLAHours,
    LastDiffBackup, DiffBackupCompliant,
    LastLogBackup, LogBackupCompliant,
    ViolationReason
)
VALUES (
    $($db.ServerKey),
    $($db.DatabaseKey),
    GETDATE(),
    '$($db.BackupSLALevel)',
    '$($db.RecoveryModel)',
    $(if ($backupInfo.LastFullBackup) { "'$($backupInfo.LastFullBackup)'" } else { 'NULL' }),
    $(if ($fullCompliant) { 1 } else { 0 }),
    $($db.FullBackupMaxAgeHours),
    $(if ($backupInfo.LastDiffBackup) { "'$($backupInfo.LastDiffBackup)'" } else { 'NULL' }),
    NULL,  -- Will be calculated by computed column
    $(if ($backupInfo.LastLogBackup) { "'$($backupInfo.LastLogBackup)'" } else { 'NULL' }),
    NULL,
    $(if (!$fullCompliant) { "'Full backup age $([Math]::Round($fullAge, 1)) hours exceeds SLA of $($db.FullBackupMaxAgeHours) hours'" } else { 'NULL' })
);
"@
        
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database $RepositoryDatabase `
                       -Query $insertQuery
    }
    catch {
        Write-Error "Failed to check $($db.ServerName).$($db.DatabaseName): $_"
    }
}
```

---

## 5.4 Alerting System

### 5.4.1 Alert Generation

**alert.AlertRules:**

```sql
CREATE TABLE alert.AlertRules (
    AlertRuleID INT IDENTITY(1,1) PRIMARY KEY,
    RuleName VARCHAR(200) NOT NULL UNIQUE,
    RuleDescription NVARCHAR(MAX),
    
    -- Detection query
    DetectionQuery NVARCHAR(MAX) NOT NULL,
    
    -- Alert details
    Severity VARCHAR(20) NOT NULL,
    Category VARCHAR(50),
    
    -- Frequency
    CheckFrequencyMinutes INT DEFAULT 5,
    
    -- Suppression
    SuppressionWindowMinutes INT DEFAULT 60,
    
    -- Escalation
    EscalationPolicy VARCHAR(100),
    
    -- Notification
    NotificationTemplate NVARCHAR(MAX),
    Recipients NVARCHAR(500),
    
    -- Schedule
    IsEnabled BIT DEFAULT 1,
    ActiveStartTime TIME,
    ActiveEndTime TIME,
    
    -- Metadata
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ModifiedDate DATETIME2 DEFAULT SYSDATETIME()
);

-- Example alert rule: High CPU
INSERT INTO alert.AlertRules (
    RuleName, RuleDescription, DetectionQuery, Severity, Category,
    CheckFrequencyMinutes, NotificationTemplate, Recipients
)
VALUES (
    'High CPU Utilization',
    'Alerts when SQL Server CPU exceeds 85% for 15+ minutes',
    'SELECT s.ServerName, pm.SQLProcessCPUPercent, pm.CollectionDateTime
     FROM fact.PerformanceMetrics pm
     JOIN dim.Server s ON pm.ServerKey = s.ServerKey
     WHERE pm.SQLProcessCPUPercent > 85
       AND pm.CollectionDateTime >= DATEADD(MINUTE, -15, GETDATE())
     GROUP BY s.ServerName, pm.SQLProcessCPUPercent, pm.CollectionDateTime
     HAVING COUNT(*) >= 3',  -- 3 consecutive readings
    'High',
    'Performance',
    5,
    'Server {ServerName} has sustained high CPU: {SQLProcessCPUPercent}%',
    'dba-team@company.com'
);
```

**alert.AlertQueue:**

```sql
CREATE TABLE alert.AlertQueue (
    AlertID BIGINT IDENTITY(1,1) PRIMARY KEY,
    AlertRuleID INT NOT NULL FOREIGN KEY REFERENCES alert.AlertRules(AlertRuleID),
    
    -- Alert details
    Severity VARCHAR(20) NOT NULL,
    AlertTitle NVARCHAR(500),
    AlertMessage NVARCHAR(MAX),
    
    -- Context
    ServerName NVARCHAR(128),
    DatabaseName NVARCHAR(128),
    MetricValue DECIMAL(18,2),
    
    -- Status
    Status VARCHAR(20) DEFAULT 'New'
        CHECK (Status IN ('New', 'Sent', 'Acknowledged', 'Resolved', 'Suppressed')),
    
    -- Timestamps
    GeneratedDate DATETIME2 DEFAULT SYSDATETIME(),
    SentDate DATETIME2,
    AcknowledgedDate DATETIME2,
    AcknowledgedBy NVARCHAR(128),
    ResolvedDate DATETIME2,
    
    -- Notification
    NotificationMethod VARCHAR(50),
    Recipients NVARCHAR(500),
    NotificationAttempts INT DEFAULT 0,
    LastNotificationAttempt DATETIME2,
    
    INDEX IX_AlertQueue_Status 
        ON alert.AlertQueue(Status, GeneratedDate DESC)
        WHERE Status IN ('New', 'Sent')
);
```

**Alert Generation Procedure:**

```sql
CREATE PROCEDURE alert.usp_GenerateAlerts
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @AlertRuleID INT;
    DECLARE @RuleName VARCHAR(200);
    DECLARE @DetectionQuery NVARCHAR(MAX);
    DECLARE @Severity VARCHAR(20);
    DECLARE @NotificationTemplate NVARCHAR(MAX);
    DECLARE @Recipients NVARCHAR(500);
    DECLARE @SuppressionWindowMinutes INT;
    
    -- Cursor through active alert rules
    DECLARE alert_cursor CURSOR FOR
    SELECT AlertRuleID, RuleName, DetectionQuery, Severity, 
           NotificationTemplate, Recipients, SuppressionWindowMinutes
    FROM alert.AlertRules
    WHERE IsEnabled = 1
      AND (ActiveStartTime IS NULL 
           OR CAST(GETDATE() AS TIME) BETWEEN ActiveStartTime AND ActiveEndTime);
    
    OPEN alert_cursor;
    FETCH NEXT FROM alert_cursor INTO @AlertRuleID, @RuleName, @DetectionQuery, 
                                       @Severity, @NotificationTemplate, @Recipients,
                                       @SuppressionWindowMinutes;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Create temp table for detection results
            CREATE TABLE #AlertResults (
                ServerName NVARCHAR(128),
                DatabaseName NVARCHAR(128),
                MetricValue DECIMAL(18,2),
                AdditionalInfo NVARCHAR(MAX)
            );
            
            -- Execute detection query
            INSERT INTO #AlertResults
            EXEC sp_executesql @DetectionQuery;
            
            -- Generate alerts for each result
            INSERT INTO alert.AlertQueue (
                AlertRuleID, Severity, AlertTitle, AlertMessage,
                ServerName, DatabaseName, MetricValue,
                NotificationMethod, Recipients
            )
            SELECT 
                @AlertRuleID,
                @Severity,
                @RuleName + ' - ' + ServerName,
                -- Replace template placeholders
                REPLACE(REPLACE(@NotificationTemplate, '{ServerName}', ServerName),
                        '{MetricValue}', CAST(MetricValue AS VARCHAR)),
                ServerName,
                DatabaseName,
                MetricValue,
                'Email',
                @Recipients
            FROM #AlertResults ar
            WHERE NOT EXISTS (
                -- Suppression: Don't alert if same issue alerted recently
                SELECT 1 
                FROM alert.AlertQueue aq
                WHERE aq.AlertRuleID = @AlertRuleID
                  AND aq.ServerName = ar.ServerName
                  AND ISNULL(aq.DatabaseName, '') = ISNULL(ar.DatabaseName, '')
                  AND aq.GeneratedDate >= DATEADD(MINUTE, -@SuppressionWindowMinutes, GETDATE())
                  AND aq.Status IN ('New', 'Sent')
            );
            
            DROP TABLE #AlertResults;
        END TRY
        BEGIN CATCH
            -- Log error but continue processing other rules
            INSERT INTO log.FailureLog (Component, ErrorMessage, ErrorDetails)
            VALUES ('AlertGeneration', 
                    'Failed to process alert rule: ' + @RuleName,
                    ERROR_MESSAGE());
        END CATCH
        
        FETCH NEXT FROM alert_cursor INTO @AlertRuleID, @RuleName, @DetectionQuery, 
                                           @Severity, @NotificationTemplate, @Recipients,
                                           @SuppressionWindowMinutes;
    END
    
    CLOSE alert_cursor;
    DEALLOCATE alert_cursor;
END
GO
```

---

### 5.4.2 Alert Notification

```sql
CREATE PROCEDURE alert.usp_SendQueuedAlerts
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @AlertID BIGINT;
    DECLARE @AlertTitle NVARCHAR(500);
    DECLARE @AlertMessage NVARCHAR(MAX);
    DECLARE @Recipients NVARCHAR(500);
    DECLARE @Severity VARCHAR(20);
    
    -- Get unsent alerts
    DECLARE alert_cursor CURSOR FOR
    SELECT AlertID, AlertTitle, AlertMessage, Recipients, Severity
    FROM alert.AlertQueue
    WHERE Status = 'New'
      AND NotificationAttempts < 3  -- Max 3 retry attempts
    ORDER BY 
        CASE Severity 
            WHEN 'Critical' THEN 1
            WHEN 'High' THEN 2
            WHEN 'Medium' THEN 3
            ELSE 4
        END,
        GeneratedDate;
    
    OPEN alert_cursor;
    FETCH NEXT FROM alert_cursor INTO @AlertID, @AlertTitle, @AlertMessage, @Recipients, @Severity;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Send email notification
            EXEC msdb.dbo.sp_send_dbmail
                @profile_name = 'DBAOps Alerts',
                @recipients = @Recipients,
                @subject = @AlertTitle,
                @body = @AlertMessage,
                @importance = CASE @Severity 
                    WHEN 'Critical' THEN 'High'
                    WHEN 'High' THEN 'High'
                    ELSE 'Normal'
                END;
            
            -- Update alert status
            UPDATE alert.AlertQueue
            SET Status = 'Sent',
                SentDate = GETDATE(),
                NotificationAttempts = NotificationAttempts + 1,
                LastNotificationAttempt = GETDATE()
            WHERE AlertID = @AlertID;
            
        END TRY
        BEGIN CATCH
            -- Update failure
            UPDATE alert.AlertQueue
            SET NotificationAttempts = NotificationAttempts + 1,
                LastNotificationAttempt = GETDATE()
            WHERE AlertID = @AlertID;
            
            -- Log error
            INSERT INTO log.FailureLog (Component, ErrorMessage, ErrorDetails)
            VALUES ('AlertNotification',
                    'Failed to send alert: ' + @AlertTitle,
                    ERROR_MESSAGE());
        END CATCH
        
        FETCH NEXT FROM alert_cursor INTO @AlertID, @AlertTitle, @AlertMessage, @Recipients, @Severity;
    END
    
    CLOSE alert_cursor;
    DEALLOCATE alert_cursor;
END
GO
```

This is great progress! Let me complete Chapter 5 with deployment, security, and summary:


---

## 5.5 Deployment and Configuration

### 5.5.1 Initial Deployment Steps

**Step-by-Step Deployment:**

```sql
-- Step 1: Create repository database
CREATE DATABASE DBAOpsRepository
ON PRIMARY (
    NAME = 'DBAOpsRepository',
    FILENAME = 'E:\Data\DBAOpsRepository.mdf',
    SIZE = 1GB,
    FILEGROWTH = 512MB
)
LOG ON (
    NAME = 'DBAOpsRepository_log',
    FILENAME = 'L:\Logs\DBAOpsRepository_log.ldf',
    SIZE = 512MB,
    FILEGROWTH = 256MB
);

ALTER DATABASE DBAOpsRepository SET RECOVERY SIMPLE;  -- Repository doesn't need FULL
ALTER DATABASE DBAOpsRepository SET AUTO_CREATE_STATISTICS ON;
ALTER DATABASE DBAOpsRepository SET AUTO_UPDATE_STATISTICS ON;
ALTER DATABASE DBAOpsRepository SET PAGE_VERIFY CHECKSUM;

-- Step 2: Create schemas
USE DBAOpsRepository;
GO

CREATE SCHEMA fact;    -- Fact tables (measurements)
CREATE SCHEMA dim;     -- Dimension tables (context)
CREATE SCHEMA config;  -- Configuration
CREATE SCHEMA ctl;     -- Control/compliance
CREATE SCHEMA log;     -- Logging
CREATE SCHEMA alert;   -- Alerting
CREATE SCHEMA security; -- Security
CREATE SCHEMA meta;    -- Framework metadata
GO

-- Step 3: Create dimension tables (in order of dependencies)
-- (Code from previous sections)

-- Step 4: Create fact tables with columnstore indexes

-- Step 5: Create configuration tables

-- Step 6: Create control tables

-- Step 7: Create alert tables

-- Step 8: Create stored procedures

-- Step 9: Configure SQL Agent jobs
```

**Automated Deployment Script:**

```powershell
<#
.SYNOPSIS
    DBAOps Framework Deployment Script

.DESCRIPTION
    Deploys complete DBAOps framework to a SQL Server instance
#>

param(
    [Parameter(Mandatory)]
    [string]$RepositoryServer,
    
    [string]$DataPath = "E:\Data",
    [string]$LogPath = "L:\Logs",
    
    [switch]$CreateDatabase,
    [switch]$CreateSchemas,
    [switch]$CreateTables,
    [switch]$CreateProcedures,
    [switch]$CreateJobs,
    [switch]$DeployAll
)

Import-Module dbatools

if ($DeployAll) {
    $CreateDatabase = $true
    $CreateSchemas = $true
    $CreateTables = $true
    $CreateProcedures = $true
    $CreateJobs = $true
}

# Step 1: Create database
if ($CreateDatabase) {
    Write-Host "Creating repository database..." -ForegroundColor Cyan
    
    $createDbScript = @"
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'DBAOpsRepository')
BEGIN
    CREATE DATABASE DBAOpsRepository
    ON PRIMARY (
        NAME = 'DBAOpsRepository',
        FILENAME = '$DataPath\DBAOpsRepository.mdf',
        SIZE = 1GB,
        FILEGROWTH = 512MB
    )
    LOG ON (
        NAME = 'DBAOpsRepository_log',
        FILENAME = '$LogPath\DBAOpsRepository_log.ldf',
        SIZE = 512MB,
        FILEGROWTH = 256MB
    );
    
    ALTER DATABASE DBAOpsRepository SET RECOVERY SIMPLE;
    ALTER DATABASE DBAOpsRepository SET AUTO_CREATE_STATISTICS ON;
    ALTER DATABASE DBAOpsRepository SET AUTO_UPDATE_STATISTICS ON;
END
"@
    
    Invoke-DbaQuery -SqlInstance $RepositoryServer -Query $createDbScript
    Write-Host "  ✓ Database created" -ForegroundColor Green
}

# Step 2: Create schemas
if ($CreateSchemas) {
    Write-Host "Creating schemas..." -ForegroundColor Cyan
    
    $schemas = @('fact', 'dim', 'config', 'ctl', 'log', 'alert', 'security', 'meta')
    
    foreach ($schema in $schemas) {
        $schemaScript = @"
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = '$schema')
    EXEC('CREATE SCHEMA $schema');
"@
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database 'DBAOpsRepository' `
                       -Query $schemaScript
        
        Write-Host "  ✓ Schema created: $schema" -ForegroundColor Green
    }
}

# Step 3: Create tables
if ($CreateTables) {
    Write-Host "Creating tables..." -ForegroundColor Cyan
    
    # Read DDL scripts from deployment folder
    $ddlScripts = Get-ChildItem -Path ".\DDL" -Filter "*.sql" | Sort-Object Name
    
    foreach ($script in $ddlScripts) {
        Write-Host "  Executing: $($script.Name)" -ForegroundColor Gray
        
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database 'DBAOpsRepository' `
                       -File $script.FullName
    }
    
    Write-Host "  ✓ All tables created" -ForegroundColor Green
}

# Step 4: Create stored procedures
if ($CreateProcedures) {
    Write-Host "Creating stored procedures..." -ForegroundColor Cyan
    
    $procScripts = Get-ChildItem -Path ".\Procedures" -Filter "*.sql" | Sort-Object Name
    
    foreach ($script in $procScripts) {
        Write-Host "  Creating: $($script.BaseName)" -ForegroundColor Gray
        
        Invoke-DbaQuery -SqlInstance $RepositoryServer `
                       -Database 'DBAOpsRepository' `
                       -File $script.FullName
    }
    
    Write-Host "  ✓ All procedures created" -ForegroundColor Green
}

# Step 5: Create SQL Agent jobs
if ($CreateJobs) {
    Write-Host "Creating SQL Agent jobs..." -ForegroundColor Cyan
    
    # Master collection job
    New-DbaAgentJob -SqlInstance $RepositoryServer `
                    -Job "DBAOps - Master Collector" `
                    -Description "Triggers all collection jobs" `
                    -Owner "sa"
    
    New-DbaAgentJobStep -SqlInstance $RepositoryServer `
                        -Job "DBAOps - Master Collector" `
                        -StepName "Execute Collections" `
                        -Subsystem PowerShell `
                        -Command "& 'C:\DBAOps\Scripts\Collect-PerformanceMetrics.ps1'"
    
    New-DbaAgentSchedule -SqlInstance $RepositoryServer `
                         -Job "DBAOps - Master Collector" `
                         -Schedule "Every 5 Minutes" `
                         -FrequencyType Daily `
                         -FrequencyInterval 1 `
                         -FrequencySubdayType Minute `
                         -FrequencySubdayInterval 5
    
    Write-Host "  ✓ Jobs created and scheduled" -ForegroundColor Green
}

Write-Host ""
Write-Host "Deployment complete!" -ForegroundColor Green
```

---

### 5.5.2 Configuration Management

**Initial Configuration Setup:**

```sql
-- Populate server inventory
INSERT INTO config.ServerInventory (
    ServerName, Environment, DataCenter, BusinessCriticality,
    OwnerTeam, CollectionFrequencyMinutes
)
VALUES
    ('PROD-SQL01', 'Production', 'DC1', 'Critical', 'Platform Team', 5),
    ('PROD-SQL02', 'Production', 'DC1', 'Critical', 'Platform Team', 5),
    ('PROD-SQL03', 'Production', 'DC2', 'Critical', 'Platform Team', 5),
    ('QA-SQL01', 'QA', 'DC1', 'Medium', 'QA Team', 15),
    ('DEV-SQL01', 'Development', 'DC1', 'Low', 'Dev Team', 30);

-- Verify configuration
SELECT * FROM config.ServerInventory WHERE IsActive = 1;

-- Test data collection for one server
EXEC msdb.dbo.sp_start_job @job_name = 'DBAOps - Master Collector';

-- Wait 5 minutes, then verify data collected
SELECT TOP 100 *
FROM fact.PerformanceMetrics
ORDER BY CollectionDateTime DESC;
```

---

## 5.6 Data Retention and Archival

### 5.6.1 Retention Strategy

**Table 5.2: Data Retention Policies**

| Schema | Table Type | Retention | Archive Strategy |
|--------|-----------|-----------|------------------|
| **fact** | High-volume metrics | 90 days | Move to archive DB, compress to daily aggregates |
| **dim** | Dimension data | Permanent | Keep all, use SCD Type 2 for changes |
| **config** | Configuration | Permanent | Version history maintained |
| **ctl** | Compliance checks | 30 days | Summarize to weekly, keep exceptions indefinitely |
| **log** | Operational logs | 180 days | Archive to file system, keep critical errors 1 year |
| **alert** | Alert history | 90 days | Summarize to monthly, keep critical alerts 1 year |

**Automated Retention Procedure:**

```sql
CREATE PROCEDURE meta.usp_ApplyRetentionPolicies
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @RowsDeleted INT;
    DECLARE @StartTime DATETIME2 = SYSDATETIME();
    
    -- Fact tables: 90 days
    DELETE FROM fact.PerformanceMetrics
    WHERE CollectionDateTime < DATEADD(DAY, -90, GETDATE());
    SET @RowsDeleted = @@ROWCOUNT;
    
    INSERT INTO log.RetentionActivity (TableName, RowsDeleted, ExecutionTime)
    VALUES ('fact.PerformanceMetrics', @RowsDeleted, SYSDATETIME());
    
    DELETE FROM fact.BackupHistory
    WHERE BackupDateTime < DATEADD(DAY, -90, GETDATE());
    SET @RowsDeleted = @@ROWCOUNT;
    
    INSERT INTO log.RetentionActivity (TableName, RowsDeleted, ExecutionTime)
    VALUES ('fact.BackupHistory', @RowsDeleted, SYSDATETIME());
    
    -- Control tables: 30 days
    DELETE FROM ctl.BackupCompliance
    WHERE CheckedDate < DATEADD(DAY, -30, GETDATE());
    SET @RowsDeleted = @@ROWCOUNT;
    
    INSERT INTO log.RetentionActivity (TableName, RowsDeleted, ExecutionTime)
    VALUES ('ctl.BackupCompliance', @RowsDeleted, SYSDATETIME());
    
    -- Alert tables: 90 days
    DELETE FROM alert.AlertQueue
    WHERE GeneratedDate < DATEADD(DAY, -90, GETDATE())
      AND Status IN ('Resolved', 'Acknowledged');
    SET @RowsDeleted = @@ROWCOUNT;
    
    INSERT INTO log.RetentionActivity (TableName, RowsDeleted, ExecutionTime)
    VALUES ('alert.AlertQueue', @RowsDeleted, SYSDATETIME());
    
    -- Log tables: 180 days
    DELETE FROM log.CollectionActivity
    WHERE ActivityDate < DATEADD(DAY, -180, GETDATE());
    SET @RowsDeleted = @@ROWCOUNT;
    
    INSERT INTO log.RetentionActivity (TableName, RowsDeleted, ExecutionTime)
    VALUES ('log.CollectionActivity', @RowsDeleted, SYSDATETIME());
    
    -- Rebuild indexes after large deletions
    ALTER INDEX ALL ON fact.PerformanceMetrics REORGANIZE;
    ALTER INDEX ALL ON fact.BackupHistory REORGANIZE;
    
    PRINT 'Retention policies applied in ' + 
          CAST(DATEDIFF(SECOND, @StartTime, SYSDATETIME()) AS VARCHAR) + ' seconds';
END
GO

-- Schedule retention job (weekly on Sunday at 2 AM)
EXEC msdb.dbo.sp_add_job @job_name = 'DBAOps - Apply Retention Policies';

EXEC msdb.dbo.sp_add_jobstep 
    @job_name = 'DBAOps - Apply Retention Policies',
    @step_name = 'Execute Retention',
    @subsystem = 'TSQL',
    @database_name = 'DBAOpsRepository',
    @command = 'EXEC meta.usp_ApplyRetentionPolicies';

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = 'Weekly Sunday 2AM',
    @freq_type = 8,  -- Weekly
    @freq_interval = 1,  -- Sunday
    @active_start_time = 20000;  -- 2:00 AM

EXEC msdb.dbo.sp_attach_schedule
    @job_name = 'DBAOps - Apply Retention Policies',
    @schedule_name = 'Weekly Sunday 2AM';
```

---

### 5.6.2 Archive Strategy

**Create Archive Database:**

```sql
CREATE DATABASE DBAOpsArchive
ON PRIMARY (
    NAME = 'DBAOpsArchive',
    FILENAME = 'E:\Archive\DBAOpsArchive.mdf',
    SIZE = 5GB,
    FILEGROWTH = 1GB
)
LOG ON (
    NAME = 'DBAOpsArchive_log',
    FILENAME = 'L:\Logs\DBAOpsArchive_log.ldf',
    SIZE = 1GB,
    FILEGROWTH = 512MB
);

ALTER DATABASE DBAOpsArchive SET RECOVERY SIMPLE;
GO

USE DBAOpsArchive;
GO

-- Create archive tables (structure similar to fact tables)
CREATE TABLE fact.PerformanceMetrics_Archive (
    ArchiveID BIGINT IDENTITY(1,1) NOT NULL,
    ServerKey INT NOT NULL,
    ArchiveDate DATE NOT NULL,
    
    -- Aggregated metrics (daily averages)
    AvgCPUPercent DECIMAL(5,2),
    MaxCPUPercent DECIMAL(5,2),
    AvgPageLifeExpectancy INT,
    MinPageLifeExpectancy INT,
    AvgReadLatencyMS DECIMAL(10,2),
    AvgWriteLatencyMS DECIMAL(10,2),
    
    DataPoints INT,  -- Number of samples aggregated
    ArchivedDateTime DATETIME2 DEFAULT SYSDATETIME(),
    
    INDEX NCCI_PerformanceMetrics_Archive CLUSTERED COLUMNSTORE
);
```

**Archive Procedure:**

```sql
CREATE PROCEDURE meta.usp_ArchiveOldData
    @ArchiveBeforeDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Archive performance metrics (aggregate to daily)
    INSERT INTO DBAOpsArchive.fact.PerformanceMetrics_Archive (
        ServerKey, ArchiveDate,
        AvgCPUPercent, MaxCPUPercent,
        AvgPageLifeExpectancy, MinPageLifeExpectancy,
        AvgReadLatencyMS, AvgWriteLatencyMS,
        DataPoints
    )
    SELECT 
        ServerKey,
        CAST(CollectionDateTime AS DATE) AS ArchiveDate,
        AVG(CPUUtilizationPercent),
        MAX(CPUUtilizationPercent),
        AVG(PageLifeExpectancy),
        MIN(PageLifeExpectancy),
        AVG(ReadLatencyMS),
        AVG(WriteLatencyMS),
        COUNT(*)
    FROM fact.PerformanceMetrics
    WHERE CollectionDateTime < @ArchiveBeforeDate
    GROUP BY ServerKey, CAST(CollectionDateTime AS DATE);
    
    -- Delete archived data from source
    DELETE FROM fact.PerformanceMetrics
    WHERE CollectionDateTime < @ArchiveBeforeDate;
    
    PRINT 'Archived ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows';
END
GO
```

---

## 5.7 Security and Access Control

### 5.7.1 Role-Based Access Control

```sql
-- Create database roles
CREATE ROLE DBAOps_Admin;
CREATE ROLE DBAOps_Operator;
CREATE ROLE DBAOps_ReadOnly;

-- DBAOps_Admin: Full control
GRANT CONTROL ON DATABASE::DBAOpsRepository TO DBAOps_Admin;

-- DBAOps_Operator: Can execute procedures, insert data
GRANT SELECT, INSERT, UPDATE ON SCHEMA::fact TO DBAOps_Operator;
GRANT SELECT, INSERT, UPDATE ON SCHEMA::ctl TO DBAOps_Operator;
GRANT SELECT, INSERT ON SCHEMA::log TO DBAOps_Operator;
GRANT SELECT, INSERT, UPDATE ON SCHEMA::alert TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::config TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::dim TO DBAOps_Operator;
GRANT EXECUTE ON SCHEMA::alert TO DBAOps_Operator;

-- DBAOps_ReadOnly: Can only view data
GRANT SELECT ON SCHEMA::fact TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::dim TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::config TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::ctl TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::alert TO DBAOps_ReadOnly;

-- Add users to roles
ALTER ROLE DBAOps_Admin ADD MEMBER [DOMAIN\DBA-Team];
ALTER ROLE DBAOps_Operator ADD MEMBER [DOMAIN\SQL-Service-Account];
ALTER ROLE DBAOps_ReadOnly ADD MEMBER [DOMAIN\Developers];
```

---

## Chapter 5 Summary

This chapter provided complete framework architecture:

**Key Takeaways:**

1. **Layered Architecture**: Repository database, ETL processes, alerting engine, presentation layer work together

2. **Star Schema Design**: Dimension tables provide context, fact tables store measurements with columnstore indexes

3. **Schema Organization**: 8 schemas (fact, dim, config, ctl, log, alert, security, meta) organize 50+ tables

4. **Parallel ETL**: PowerShell collectors gather data from 100+ servers simultaneously

5. **Intelligent Alerting**: Rule-based detection with suppression, escalation, and multiple notification methods

6. **Data Lifecycle**: Retention policies and archival strategies manage storage efficiently

7. **Enterprise Security**: Role-based access control protects sensitive operational data

**Framework Components:**

✅ Repository database with optimized schema
✅ Dimension tables (Server, Database, Time)
✅ Fact tables (Performance, Backup, Query metrics)
✅ Configuration management
✅ Parallel data collection
✅ Alert generation and notification
✅ Data retention and archival
✅ Security and RBAC

**Production Procedures Created:**

- Complete database schema (50+ tables)
- ETL collection scripts
- Alert generation engine
- Retention automation
- Deployment automation
- RBAC implementation

**Connection to Next Chapter:**

Chapter 6 dives deep into the data collection implementation, providing complete PowerShell collectors for every metric type and showing how to troubleshoot common collection issues.

---

## Review Questions

**Multiple Choice:**

1. In a star schema, which type of table stores measurement data?
   a) Dimension table
   b) Fact table
   c) Configuration table
   d) Control table

2. What index type is recommended for high-volume fact tables?
   a) Clustered rowstore
   b) Non-clustered rowstore
   c) Clustered columnstore
   d) XML index

3. What is the purpose of suppression windows in alerting?
   a) Delete old alerts
   b) Prevent alert spam for same issue
   c) Encrypt alert messages
   d) Archive alerts to file system

**Short Answer:**

4. Explain the difference between fact tables and dimension tables in the DBAOps framework. Provide examples of each.

5. Describe how parallel processing in PowerShell collectors improves scalability. What throttle limit would you use for 200 servers?

6. Why does the framework use SIMPLE recovery model for the repository database instead of FULL?

**Essay Questions:**

7. Design a complete data retention and archival strategy for an organization with 500 SQL Servers generating 10GB of metrics data per day. Include retention periods, aggregation strategies, and archive database design.

8. Explain how the alerting system prevents alert fatigue while ensuring critical issues are never missed. Discuss suppression windows, escalation policies, and severity levels.

**Hands-On Exercises:**

9. **Exercise 5.1: Deploy Repository Database**
   - Create DBAOpsRepository database
   - Create all schemas
   - Deploy dimension and fact tables
   - Populate dim.Time for 5 years
   - Create indexes

10. **Exercise 5.2: Configure Alert Rules**
    - Create alert rule for high CPU (>90% for 10 minutes)
    - Create alert rule for backup age (>48 hours)
    - Test alert generation
    - Configure email notifications
    - Implement suppression window

---

*End of Chapter 5*

**Next Chapter:** Chapter 6 - Data Collection Implementation

