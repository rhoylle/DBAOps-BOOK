# Chapter 14
# Advanced Analytics and Machine Learning

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Apply** statistical analysis to performance metrics
2. **Implement** predictive capacity forecasting
3. **Detect** anomalies using machine learning
4. **Build** performance baseline models
5. **Predict** query performance degradation
6. **Automate** intelligent remediation
7. **Visualize** trends and patterns
8. **Optimize** resources using ML recommendations

**Key Terms**

- Time Series Analysis
- Linear Regression
- Anomaly Detection
- Clustering
- Random Forest
- Prophet (Facebook)
- ARIMA
- Machine Learning Model
- Training Data
- Feature Engineering

---

## 14.1 Statistical Foundations

### 14.1.1 Time Series Analysis

**Understanding metric trends:**

```sql
-- Create time series analysis functions
CREATE FUNCTION stats.fn_CalculateMovingAverage(
    @ServerKey INT,
    @MetricName VARCHAR(50),
    @WindowDays INT
)
RETURNS TABLE
AS
RETURN
(
    WITH MetricSeries AS (
        SELECT 
            CollectionDateTime,
            CASE @MetricName
                WHEN 'CPU' THEN CPUUtilizationPercent
                WHEN 'PLE' THEN PageLifeExpectancy
                WHEN 'ReadLatency' THEN ReadLatencyMS
                WHEN 'WriteLatency' THEN WriteLatencyMS
            END AS MetricValue
        FROM fact.PerformanceMetrics
        WHERE ServerKey = @ServerKey
          AND CollectionDateTime >= DATEADD(DAY, -@WindowDays, GETDATE())
    )
    SELECT 
        CollectionDateTime,
        MetricValue,
        AVG(MetricValue) OVER (
            ORDER BY CollectionDateTime
            ROWS BETWEEN 11 PRECEDING AND CURRENT ROW
        ) AS MovingAvg_12Points,
        STDEV(MetricValue) OVER (
            ORDER BY CollectionDateTime
            ROWS BETWEEN 11 PRECEDING AND CURRENT ROW
        ) AS StdDev_12Points
    FROM MetricSeries
);
GO

-- Detect trend direction
CREATE FUNCTION stats.fn_DetectTrend(
    @ServerKey INT,
    @MetricName VARCHAR(50),
    @Days INT = 7
)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @Trend VARCHAR(20);
    
    WITH RecentMetrics AS (
        SELECT 
            ROW_NUMBER() OVER (ORDER BY CollectionDateTime) AS TimePoint,
            CASE @MetricName
                WHEN 'CPU' THEN CPUUtilizationPercent
                WHEN 'PLE' THEN PageLifeExpectancy
            END AS MetricValue
        FROM fact.PerformanceMetrics
        WHERE ServerKey = @ServerKey
          AND CollectionDateTime >= DATEADD(DAY, -@Days, GETDATE())
    ),
    Regression AS (
        SELECT 
            (COUNT(*) * SUM(TimePoint * MetricValue) - SUM(TimePoint) * SUM(MetricValue)) /
            (COUNT(*) * SUM(TimePoint * TimePoint) - SUM(TimePoint) * SUM(TimePoint)) AS Slope
        FROM RecentMetrics
    )
    SELECT @Trend = 
        CASE 
            WHEN Slope > 1 THEN 'Increasing'
            WHEN Slope < -1 THEN 'Decreasing'
            ELSE 'Stable'
        END
    FROM Regression;
    
    RETURN @Trend;
END
GO
```

---

### 14.1.2 Correlation Analysis

**Find correlated metrics:**

```sql
CREATE PROCEDURE analytics.usp_CalculateMetricCorrelations
    @ServerKey INT,
    @Days INT = 30
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Calculate Pearson correlation between metrics
    WITH MetricPairs AS (
        SELECT 
            CPUUtilizationPercent,
            PageLifeExpectancy,
            ReadLatencyMS,
            WriteLatencyMS,
            UserConnections,
            BlockedProcesses
        FROM fact.PerformanceMetrics
        WHERE ServerKey = @ServerKey
          AND CollectionDateTime >= DATEADD(DAY, -@Days, GETDATE())
    )
    SELECT 
        'CPU vs PLE' AS MetricPair,
        (COUNT(*) * SUM(CPUUtilizationPercent * PageLifeExpectancy) - 
         SUM(CPUUtilizationPercent) * SUM(PageLifeExpectancy)) /
        (SQRT(COUNT(*) * SUM(CPUUtilizationPercent * CPUUtilizationPercent) - 
              SUM(CPUUtilizationPercent) * SUM(CPUUtilizationPercent)) *
         SQRT(COUNT(*) * SUM(PageLifeExpectancy * PageLifeExpectancy) - 
              SUM(PageLifeExpectancy) * SUM(PageLifeExpectancy))) 
        AS Correlation
    FROM MetricPairs
    
    UNION ALL
    
    SELECT 
        'CPU vs ReadLatency',
        (COUNT(*) * SUM(CPUUtilizationPercent * ReadLatencyMS) - 
         SUM(CPUUtilizationPercent) * SUM(ReadLatencyMS)) /
        (SQRT(COUNT(*) * SUM(CPUUtilizationPercent * CPUUtilizationPercent) - 
              SUM(CPUUtilizationPercent) * SUM(CPUUtilizationPercent)) *
         SQRT(COUNT(*) * SUM(ReadLatencyMS * ReadLatencyMS) - 
              SUM(ReadLatencyMS) * SUM(ReadLatencyMS))) 
    FROM MetricPairs
    
    UNION ALL
    
    SELECT 
        'UserConnections vs BlockedProcesses',
        (COUNT(*) * SUM(UserConnections * BlockedProcesses) - 
         SUM(UserConnections) * SUM(BlockedProcesses)) /
        (SQRT(COUNT(*) * SUM(UserConnections * UserConnections) - 
              SUM(UserConnections) * SUM(UserConnections)) *
         SQRT(COUNT(*) * SUM(BlockedProcesses * BlockedProcesses) - 
              SUM(BlockedProcesses) * SUM(BlockedProcesses))) 
    FROM MetricPairs;
    
    -- Interpretation:
    -- Correlation > 0.7: Strong positive
    -- Correlation < -0.7: Strong negative
    -- -0.3 to 0.3: Weak/no correlation
END
GO
```

---

## 14.2 Predictive Capacity Forecasting

### 14.2.1 Disk Space Forecasting

**Linear regression for capacity planning:**

```sql
CREATE PROCEDURE analytics.usp_ForecastDiskSpace
    @ServerKey INT,
    @ForecastDays INT = 90
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Get historical disk space growth
    WITH DiskHistory AS (
        SELECT 
            CAST(CollectionDateTime AS DATE) AS CollectionDate,
            DatabaseName,
            AVG(DataSizeGB) AS AvgDataSizeGB,
            AVG(LogSizeGB) AS AvgLogSizeGB,
            AVG(FreeSpaceGB) AS AvgFreeSpaceGB
        FROM fact.DiskSpaceMetrics
        WHERE ServerKey = @ServerKey
          AND CollectionDateTime >= DATEADD(DAY, -90, GETDATE())
        GROUP BY CAST(CollectionDateTime AS DATE), DatabaseName
    ),
    TimePoints AS (
        SELECT 
            DatabaseName,
            CollectionDate,
            DATEDIFF(DAY, MIN(CollectionDate) OVER (PARTITION BY DatabaseName), CollectionDate) AS DaysSinceStart,
            AvgDataSizeGB,
            AvgLogSizeGB,
            AvgFreeSpaceGB
        FROM DiskHistory
    ),
    LinearRegression AS (
        SELECT 
            DatabaseName,
            -- Calculate linear regression: y = mx + b
            (COUNT(*) * SUM(DaysSinceStart * AvgDataSizeGB) - 
             SUM(DaysSinceStart) * SUM(AvgDataSizeGB)) /
            NULLIF((COUNT(*) * SUM(DaysSinceStart * DaysSinceStart) - 
                    SUM(DaysSinceStart) * SUM(DaysSinceStart)), 0) AS GrowthRateGB_PerDay,
            
            AVG(AvgDataSizeGB) - 
            ((COUNT(*) * SUM(DaysSinceStart * AvgDataSizeGB) - 
              SUM(DaysSinceStart) * SUM(AvgDataSizeGB)) /
             NULLIF((COUNT(*) * SUM(DaysSinceStart * DaysSinceStart) - 
                     SUM(DaysSinceStart) * SUM(DaysSinceStart)), 0)) * 
            AVG(DaysSinceStart) AS Intercept,
            
            MAX(AvgFreeSpaceGB) AS CurrentFreeSpaceGB,
            MAX(DaysSinceStart) AS CurrentDay
        FROM TimePoints
        GROUP BY DatabaseName
    )
    SELECT 
        DatabaseName,
        GrowthRateGB_PerDay,
        GrowthRateGB_PerDay * 30 AS ProjectedGrowth30Days,
        GrowthRateGB_PerDay * 90 AS ProjectedGrowth90Days,
        CurrentFreeSpaceGB,
        
        -- Forecast when disk will be full
        CASE 
            WHEN GrowthRateGB_PerDay > 0 
            THEN CurrentFreeSpaceGB / GrowthRateGB_PerDay
            ELSE NULL
        END AS DaysUntilFull,
        
        -- Projected size at forecast date
        (GrowthRateGB_PerDay * (CurrentDay + @ForecastDays)) + Intercept AS ProjectedSizeGB,
        
        -- Confidence based on R-squared (simplified)
        CASE 
            WHEN GrowthRateGB_PerDay > 0.1 THEN 'High Confidence'
            WHEN GrowthRateGB_PerDay > 0.01 THEN 'Medium Confidence'
            ELSE 'Low Confidence'
        END AS ForecastConfidence
    FROM LinearRegression
    WHERE GrowthRateGB_PerDay IS NOT NULL
    ORDER BY DaysUntilFull;
END
GO

-- Alert on capacity issues
CREATE PROCEDURE analytics.usp_AlertCapacityIssues
AS
BEGIN
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        800 AS AlertRuleID,
        CASE 
            WHEN DaysUntilFull <= 7 THEN 'Critical'
            WHEN DaysUntilFull <= 30 THEN 'High'
            ELSE 'Medium'
        END AS Severity,
        'Disk Space Forecast Alert' AS AlertTitle,
        'Database ' + DatabaseName + ' projected to run out of space in ' + 
        CAST(CAST(DaysUntilFull AS INT) AS VARCHAR) + ' days. ' +
        'Current growth rate: ' + CAST(CAST(GrowthRateGB_PerDay AS DECIMAL(10,2)) AS VARCHAR) + ' GB/day' AS AlertMessage,
        s.ServerName
    FROM analytics.usp_ForecastDiskSpace(@ServerKey := s.ServerKey, @ForecastDays := 90)
    CROSS APPLY (SELECT ServerName FROM dim.Server WHERE ServerKey = s.ServerKey) s
    WHERE DaysUntilFull <= 60;
END
GO
```

---

### 14.2.2 Performance Trend Forecasting

**Predict future performance issues:**

```python
# Python script for advanced forecasting using Prophet
# Run via SQL Server Machine Learning Services (R/Python)

import pandas as pd
import numpy as np
from prophet import Prophet
import pyodbc

def forecast_cpu_usage(server_name, forecast_days=30):
    """
    Forecast CPU usage using Facebook Prophet
    """
    # Connect to repository
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=DBAOps-Listener;'
        'DATABASE=DBAOpsRepository;'
        'Trusted_Connection=yes'
    )
    
    # Get historical CPU data
    query = f"""
    SELECT 
        CollectionDateTime AS ds,
        CPUUtilizationPercent AS y
    FROM fact.PerformanceMetrics pm
    JOIN dim.Server s ON pm.ServerKey = s.ServerKey
    WHERE s.ServerName = '{server_name}'
      AND pm.CollectionDateTime >= DATEADD(DAY, -90, GETDATE())
    ORDER BY CollectionDateTime
    """
    
    df = pd.read_sql(query, conn)
    
    # Initialize Prophet model
    model = Prophet(
        daily_seasonality=True,
        weekly_seasonality=True,
        yearly_seasonality=False,
        changepoint_prior_scale=0.05  # Adjust for sensitivity
    )
    
    # Fit model
    model.fit(df)
    
    # Make future dataframe
    future = model.make_future_dataframe(periods=forecast_days, freq='H')
    
    # Forecast
    forecast = model.predict(future)
    
    # Identify concerning trends
    future_forecast = forecast.tail(forecast_days * 24)  # Last N days
    
    alerts = []
    if future_forecast['yhat'].max() > 90:
        alerts.append({
            'severity': 'Critical',
            'message': f'CPU forecasted to exceed 90% in next {forecast_days} days',
            'max_predicted': future_forecast['yhat'].max(),
            'when': future_forecast.loc[future_forecast['yhat'].idxmax(), 'ds']
        })
    elif future_forecast['yhat'].max() > 80:
        alerts.append({
            'severity': 'Warning',
            'message': f'CPU forecasted to exceed 80% in next {forecast_days} days',
            'max_predicted': future_forecast['yhat'].max(),
            'when': future_forecast.loc[future_forecast['yhat'].idxmax(), 'ds']
        })
    
    # Save forecast to database
    forecast_to_save = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail(forecast_days * 24)
    forecast_to_save['server_name'] = server_name
    forecast_to_save['metric_name'] = 'CPU'
    
    forecast_to_save.to_sql('analytics.ForecastResults', conn, if_exists='append', index=False)
    
    conn.close()
    
    return {
        'forecast': forecast,
        'alerts': alerts
    }

# Execute for all critical servers
servers = ['PROD-SQL01', 'PROD-SQL02', 'PROD-SQL03']
for server in servers:
    result = forecast_cpu_usage(server, forecast_days=30)
    print(f"{server}: {len(result['alerts'])} alerts generated")
```

**Forecast results table:**

```sql
CREATE TABLE analytics.ForecastResults (
    ForecastID BIGINT IDENTITY(1,1) PRIMARY KEY,
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    ServerName NVARCHAR(128) NOT NULL,
    MetricName VARCHAR(50) NOT NULL,
    
    ForecastDateTime DATETIME2 NOT NULL,
    PredictedValue DECIMAL(10,2),
    LowerBound DECIMAL(10,2),
    UpperBound DECIMAL(10,2),
    
    INDEX IX_ForecastResults_Server_Metric_DateTime 
        (ServerName, MetricName, ForecastDateTime DESC)
);
GO
```

---

## 14.3 Anomaly Detection

### 14.3.1 Statistical Anomaly Detection

**Z-score based anomaly detection:**

```sql
CREATE PROCEDURE analytics.usp_DetectAnomalies
    @ServerKey INT,
    @Threshold DECIMAL(5,2) = 3.0  -- 3 standard deviations
AS
BEGIN
    SET NOCOUNT ON;
    
    WITH BaselineStats AS (
        SELECT 
            AVG(CPUUtilizationPercent) AS AvgCPU,
            STDEV(CPUUtilizationPercent) AS StdDevCPU,
            AVG(PageLifeExpectancy) AS AvgPLE,
            STDEV(PageLifeExpectancy) AS StdDevPLE,
            AVG(ReadLatencyMS) AS AvgReadLatency,
            STDEV(ReadLatencyMS) AS StdDevReadLatency,
            AVG(WriteLatencyMS) AS AvgWriteLatency,
            STDEV(WriteLatencyMS) AS StdDevWriteLatency
        FROM fact.PerformanceMetrics
        WHERE ServerKey = @ServerKey
          AND CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
          AND CollectionDateTime < DATEADD(HOUR, -1, GETDATE())  -- Exclude recent data
    ),
    RecentMetrics AS (
        SELECT 
            MetricKey,
            CollectionDateTime,
            CPUUtilizationPercent,
            PageLifeExpectancy,
            ReadLatencyMS,
            WriteLatencyMS
        FROM fact.PerformanceMetrics
        WHERE ServerKey = @ServerKey
          AND CollectionDateTime >= DATEADD(HOUR, -1, GETDATE())
    )
    SELECT 
        rm.CollectionDateTime,
        
        -- CPU Anomaly
        CASE 
            WHEN ABS(rm.CPUUtilizationPercent - bs.AvgCPU) > (@Threshold * bs.StdDevCPU)
            THEN 'CPU Anomaly'
            ELSE NULL
        END AS CPUAnomaly,
        rm.CPUUtilizationPercent AS CurrentCPU,
        bs.AvgCPU AS BaselineCPU,
        (rm.CPUUtilizationPercent - bs.AvgCPU) / NULLIF(bs.StdDevCPU, 0) AS CPU_ZScore,
        
        -- PLE Anomaly
        CASE 
            WHEN ABS(rm.PageLifeExpectancy - bs.AvgPLE) > (@Threshold * bs.StdDevPLE)
            THEN 'PLE Anomaly'
            ELSE NULL
        END AS PLEAnomaly,
        rm.PageLifeExpectancy AS CurrentPLE,
        bs.AvgPLE AS BaselinePLE,
        (rm.PageLifeExpectancy - bs.AvgPLE) / NULLIF(bs.StdDevPLE, 0) AS PLE_ZScore,
        
        -- Latency Anomaly
        CASE 
            WHEN ABS(rm.ReadLatencyMS - bs.AvgReadLatency) > (@Threshold * bs.StdDevReadLatency)
            THEN 'Read Latency Anomaly'
            ELSE NULL
        END AS ReadLatencyAnomaly,
        rm.ReadLatencyMS AS CurrentReadLatency,
        bs.AvgReadLatency AS BaselineReadLatency,
        (rm.ReadLatencyMS - bs.AvgReadLatency) / NULLIF(bs.StdDevReadLatency, 0) AS ReadLatency_ZScore
        
    FROM RecentMetrics rm
    CROSS JOIN BaselineStats bs
    WHERE (
        ABS(rm.CPUUtilizationPercent - bs.AvgCPU) > (@Threshold * bs.StdDevCPU) OR
        ABS(rm.PageLifeExpectancy - bs.AvgPLE) > (@Threshold * bs.StdDevPLE) OR
        ABS(rm.ReadLatencyMS - bs.AvgReadLatency) > (@Threshold * bs.StdDevReadLatency)
    )
    ORDER BY rm.CollectionDateTime DESC;
END
GO

-- Alert on anomalies
CREATE PROCEDURE analytics.usp_AlertOnAnomalies
AS
BEGIN
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    SELECT 
        801 AS AlertRuleID,
        'High' AS Severity,
        'Performance Anomaly Detected' AS AlertTitle,
        ISNULL(CPUAnomaly, '') + ' ' +
        ISNULL(PLEAnomaly, '') + ' ' +
        ISNULL(ReadLatencyAnomaly, '') + '. ' +
        'Z-Scores: CPU=' + CAST(CAST(CPU_ZScore AS DECIMAL(5,2)) AS VARCHAR) +
        ', PLE=' + CAST(CAST(PLE_ZScore AS DECIMAL(5,2)) AS VARCHAR) AS AlertMessage,
        s.ServerName
    FROM analytics.usp_DetectAnomalies(@ServerKey := s.ServerKey, @Threshold := 3.0)
    CROSS APPLY (SELECT ServerName FROM dim.Server WHERE ServerKey = s.ServerKey) s;
END
GO
```

Let me continue with machine learning models, clustering, intelligent automation, and a comprehensive case study:


---

### 14.3.2 Machine Learning Anomaly Detection

**Isolation Forest for anomaly detection:**

```python
# Advanced ML-based anomaly detection
# SQL Server Machine Learning Services

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import pyodbc

def detect_anomalies_ml(server_name, contamination=0.05):
    """
    Use Isolation Forest to detect anomalies in performance metrics
    """
    # Connect to repository
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=DBAOps-Listener;'
        'DATABASE=DBAOpsRepository;'
        'Trusted_Connection=yes'
    )
    
    # Get training data (30 days)
    query = f"""
    SELECT 
        CollectionDateTime,
        CPUUtilizationPercent,
        PageLifeExpectancy,
        ReadLatencyMS,
        WriteLatencyMS,
        UserConnections,
        BlockedProcesses,
        BatchRequestsPerSec
    FROM fact.PerformanceMetrics pm
    JOIN dim.Server s ON pm.ServerKey = s.ServerKey
    WHERE s.ServerName = '{server_name}'
      AND pm.CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
    ORDER BY CollectionDateTime
    """
    
    df = pd.read_sql(query, conn)
    
    # Feature engineering
    features = ['CPUUtilizationPercent', 'PageLifeExpectancy', 'ReadLatencyMS', 
                'WriteLatencyMS', 'UserConnections', 'BlockedProcesses', 
                'BatchRequestsPerSec']
    
    X = df[features].fillna(df[features].median())
    
    # Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Train Isolation Forest
    model = IsolationForest(
        contamination=contamination,  # Expected % of anomalies
        random_state=42,
        n_estimators=100
    )
    
    # Predict (-1 for anomaly, 1 for normal)
    predictions = model.fit_predict(X_scaled)
    anomaly_scores = model.score_samples(X_scaled)
    
    # Add predictions to dataframe
    df['IsAnomaly'] = predictions == -1
    df['AnomalyScore'] = anomaly_scores
    
    # Get anomalies
    anomalies = df[df['IsAnomaly']]
    
    # Save to database
    if len(anomalies) > 0:
        anomalies_to_save = anomalies[['CollectionDateTime', 'CPUUtilizationPercent', 
                                        'PageLifeExpectancy', 'AnomalyScore']].copy()
        anomalies_to_save['ServerName'] = server_name
        anomalies_to_save['DetectionMethod'] = 'IsolationForest'
        
        anomalies_to_save.to_sql('analytics.DetectedAnomalies', conn, 
                                 if_exists='append', index=False)
    
    conn.close()
    
    return {
        'total_samples': len(df),
        'anomalies_detected': len(anomalies),
        'anomaly_rate': len(anomalies) / len(df),
        'anomalies': anomalies
    }

# Run for all servers
result = detect_anomalies_ml('PROD-SQL01', contamination=0.05)
print(f"Detected {result['anomalies_detected']} anomalies out of {result['total_samples']} samples")
```

**Anomaly tracking table:**

```sql
CREATE TABLE analytics.DetectedAnomalies (
    AnomalyID BIGINT IDENTITY(1,1) PRIMARY KEY,
    DetectedDate DATETIME2 DEFAULT SYSDATETIME(),
    ServerName NVARCHAR(128) NOT NULL,
    CollectionDateTime DATETIME2 NOT NULL,
    
    DetectionMethod VARCHAR(50),  -- ZScore, IsolationForest, etc.
    AnomalyScore DECIMAL(10,6),
    
    -- Metric values at time of anomaly
    CPUUtilizationPercent DECIMAL(5,2),
    PageLifeExpectancy INT,
    ReadLatencyMS DECIMAL(10,2),
    WriteLatencyMS DECIMAL(10,2),
    
    -- Was it a true anomaly? (for feedback loop)
    IsConfirmed BIT,
    RootCause NVARCHAR(500),
    
    INDEX IX_DetectedAnomalies_Server_DateTime 
        (ServerName, CollectionDateTime DESC)
);
GO
```

---

## 14.4 Performance Pattern Recognition

### 14.4.1 Server Clustering

**Group servers by performance characteristics:**

```python
# K-Means clustering for server grouping

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import pyodbc
import matplotlib.pyplot as plt

def cluster_servers(n_clusters=5):
    """
    Cluster servers based on performance characteristics
    """
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=DBAOps-Listener;'
        'DATABASE=DBAOpsRepository;'
        'Trusted_Connection=yes'
    )
    
    # Get aggregated server metrics
    query = """
    SELECT 
        s.ServerName,
        s.Environment,
        AVG(pm.CPUUtilizationPercent) AS AvgCPU,
        STDEV(pm.CPUUtilizationPercent) AS StdDevCPU,
        AVG(pm.PageLifeExpectancy) AS AvgPLE,
        AVG(pm.ReadLatencyMS) AS AvgReadLatency,
        AVG(pm.WriteLatencyMS) AS AvgWriteLatency,
        AVG(pm.UserConnections) AS AvgConnections,
        AVG(pm.BatchRequestsPerSec) AS AvgBatchRequests
    FROM fact.PerformanceMetrics pm
    JOIN dim.Server s ON pm.ServerKey = s.ServerKey
    WHERE pm.CollectionDateTime >= DATEADD(DAY, -30, GETDATE())
      AND s.IsCurrent = 1
    GROUP BY s.ServerName, s.Environment
    HAVING COUNT(*) > 100  -- Sufficient samples
    """
    
    df = pd.read_sql(query, conn)
    
    # Features for clustering
    features = ['AvgCPU', 'StdDevCPU', 'AvgPLE', 'AvgReadLatency', 
                'AvgWriteLatency', 'AvgConnections', 'AvgBatchRequests']
    
    X = df[features].fillna(df[features].median())
    
    # Standardize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # K-Means clustering
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    df['Cluster'] = kmeans.fit_predict(X_scaled)
    
    # Analyze clusters
    cluster_summary = df.groupby('Cluster')[features].mean()
    
    # Assign cluster names based on characteristics
    cluster_names = []
    for cluster_id in range(n_clusters):
        cluster_data = cluster_summary.loc[cluster_id]
        
        if cluster_data['AvgCPU'] > 70:
            name = 'High CPU Utilization'
        elif cluster_data['AvgPLE'] < 500:
            name = 'Memory Constrained'
        elif cluster_data['AvgReadLatency'] > 20:
            name = 'I/O Bound'
        elif cluster_data['AvgBatchRequests'] > 1000:
            name = 'High Transaction Volume'
        else:
            name = 'Balanced Workload'
        
        cluster_names.append(name)
    
    # Map cluster names
    df['ClusterName'] = df['Cluster'].apply(lambda x: cluster_names[x])
    
    # Save to database
    df[['ServerName', 'Cluster', 'ClusterName']].to_sql(
        'analytics.ServerClusters', conn, if_exists='replace', index=False
    )
    
    conn.close()
    
    return {
        'clusters': df,
        'cluster_summary': cluster_summary,
        'cluster_names': cluster_names
    }

# Execute
result = cluster_servers(n_clusters=5)

# Display cluster distribution
print("\nCluster Distribution:")
print(result['clusters']['ClusterName'].value_counts())

print("\nCluster Summary:")
print(result['cluster_summary'])
```

---

## 14.5 Intelligent Automation

### 14.5.1 Auto-Remediation Based on ML

**Automated response to predicted issues:**

```sql
CREATE TABLE analytics.RemediationActions (
    ActionID INT IDENTITY(1,1) PRIMARY KEY,
    ActionName VARCHAR(100) NOT NULL,
    Condition VARCHAR(500) NOT NULL,
    Action NVARCHAR(MAX) NOT NULL,
    AutoExecute BIT DEFAULT 0,
    RequiresApproval BIT DEFAULT 1,
    
    IsEnabled BIT DEFAULT 1
);
GO

-- Define auto-remediation actions
INSERT INTO analytics.RemediationActions (
    ActionName, Condition, Action, AutoExecute, RequiresApproval
)
VALUES
    ('Clear SQL Cache on High Memory Pressure', 
     'PageLifeExpectancy < 300 AND Trending Down',
     'DBCC DROPCLEANBUFFERS; DBCC FREEPROCCACHE;',
     0, 1),  -- Requires approval
     
    ('Rebuild Fragmented Indexes',
     'Index Fragmentation > 30%',
     'EXEC dbo.IndexOptimize @Databases = ''USER_DATABASES'', @FragmentationLevel1 = 30',
     1, 0),  -- Auto-execute
     
    ('Kill Long Running Queries',
     'Query Running > 1 hour AND Blocking Others',
     'KILL <SPID>',
     0, 1),  -- Requires approval
     
    ('Scale Up Azure SQL Database',
     'DTU > 90% for 30 minutes',
     'ALTER DATABASE <DatabaseName> MODIFY (SERVICE_OBJECTIVE = ''S3'')',
     0, 1);  -- Requires approval
GO

-- Procedure to evaluate and execute remediation
CREATE PROCEDURE analytics.usp_EvaluateRemediationActions
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Check each enabled action
    DECLARE @ActionID INT, @ActionName VARCHAR(100), @Condition VARCHAR(500),
            @Action NVARCHAR(MAX), @AutoExecute BIT;
    
    DECLARE action_cursor CURSOR FOR
    SELECT ActionID, ActionName, Condition, Action, AutoExecute
    FROM analytics.RemediationActions
    WHERE IsEnabled = 1;
    
    OPEN action_cursor;
    FETCH NEXT FROM action_cursor INTO @ActionID, @ActionName, @Condition, @Action, @AutoExecute;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Evaluate condition (simplified - in reality, would parse condition dynamically)
        -- For example, check if PLE < 300
        
        IF @AutoExecute = 1
        BEGIN
            -- Log action
            INSERT INTO analytics.RemediationLog (
                ActionID, ActionName, ExecutionTime, Status
            )
            VALUES (@ActionID, @ActionName, SYSDATETIME(), 'Pending');
            
            BEGIN TRY
                -- Execute action
                EXEC sp_executesql @Action;
                
                -- Log success
                UPDATE analytics.RemediationLog
                SET Status = 'Success', CompletedTime = SYSDATETIME()
                WHERE ActionID = @ActionID 
                  AND ExecutionTime = (SELECT MAX(ExecutionTime) FROM analytics.RemediationLog WHERE ActionID = @ActionID);
                
            END TRY
            BEGIN CATCH
                -- Log failure
                UPDATE analytics.RemediationLog
                SET Status = 'Failed', 
                    ErrorMessage = ERROR_MESSAGE(),
                    CompletedTime = SYSDATETIME()
                WHERE ActionID = @ActionID 
                  AND ExecutionTime = (SELECT MAX(ExecutionTime) FROM analytics.RemediationLog WHERE ActionID = @ActionID);
            END CATCH
        END
        ELSE
        BEGIN
            -- Create approval request
            INSERT INTO analytics.RemediationApprovals (
                ActionID, ActionName, RequestedTime, Status
            )
            VALUES (@ActionID, @ActionName, SYSDATETIME(), 'Pending');
        END
        
        FETCH NEXT FROM action_cursor INTO @ActionID, @ActionName, @Condition, @Action, @AutoExecute;
    END
    
    CLOSE action_cursor;
    DEALLOCATE action_cursor;
END
GO
```

---

### 14.5.2 Predictive Index Recommendations

**ML-based index recommendations:**

```sql
CREATE PROCEDURE analytics.usp_RecommendIndexes
    @ServerKey INT,
    @MinImpactPercent DECIMAL(5,2) = 10.0
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Analyze query patterns from Query Store
    WITH QueryStats AS (
        SELECT 
            qsq.query_hash,
            qsqt.query_sql_text,
            SUM(qsrs.count_executions) AS TotalExecutions,
            AVG(qsrs.avg_duration) / 1000.0 AS AvgDurationMS,
            AVG(qsrs.avg_logical_io_reads) AS AvgLogicalReads,
            MAX(qsrs.last_execution_time) AS LastExecutionTime
        FROM sys.query_store_query qsq
        JOIN sys.query_store_query_text qsqt ON qsq.query_text_id = qsqt.query_text_id
        JOIN sys.query_store_plan qsp ON qsq.query_id = qsp.query_id
        JOIN sys.query_store_runtime_stats qsrs ON qsp.plan_id = qsrs.plan_id
        WHERE qsrs.last_execution_time >= DATEADD(DAY, -7, GETDATE())
        GROUP BY qsq.query_hash, qsqt.query_sql_text
        HAVING SUM(qsrs.count_executions) >= 10
    ),
    MissingIndexes AS (
        SELECT 
            mid.statement AS TableName,
            migs.avg_user_impact AS AvgImpactPercent,
            migs.user_seeks + migs.user_scans AS TotalSeeksScans,
            mid.equality_columns AS EqualityColumns,
            mid.inequality_columns AS InequalityColumns,
            mid.included_columns AS IncludedColumns,
            
            'CREATE NONCLUSTERED INDEX IX_' + 
            REPLACE(REPLACE(mid.statement, '[', ''), ']', '') + '_' +
            CAST(NEWID() AS VARCHAR(36)) +
            ' ON ' + mid.statement + 
            ' (' + ISNULL(mid.equality_columns, '') + 
            CASE WHEN mid.inequality_columns IS NOT NULL 
                 THEN ', ' + mid.inequality_columns ELSE '' END + ')' +
            CASE WHEN mid.included_columns IS NOT NULL 
                 THEN ' INCLUDE (' + mid.included_columns + ')' ELSE '' END AS IndexDDL
        FROM sys.dm_db_missing_index_details mid
        JOIN sys.dm_db_missing_index_groups mig ON mid.index_handle = mig.index_handle
        JOIN sys.dm_db_missing_index_group_stats migs ON mig.index_group_handle = migs.group_handle
        WHERE migs.avg_user_impact >= @MinImpactPercent
          AND (migs.user_seeks + migs.user_scans) >= 100
    )
    SELECT 
        TableName,
        AvgImpactPercent,
        TotalSeeksScans,
        EqualityColumns,
        InequalityColumns,
        IncludedColumns,
        IndexDDL,
        
        -- Estimate cost savings
        (AvgImpactPercent / 100.0) * TotalSeeksScans AS EstimatedBenefit
    FROM MissingIndexes
    ORDER BY EstimatedBenefit DESC;
END
GO
```

---

## 14.6 Visualization and Insights

### 14.6.1 Advanced Analytics Dashboard

**Power BI DAX for ML insights:**

```dax
// Measure: Anomaly Detection Flag
AnomalyFlag = 
VAR CurrentCPU = AVERAGE(PerformanceMetrics[CPUUtilizationPercent])
VAR BaselineCPU = CALCULATE(
    AVERAGE(PerformanceMetrics[CPUUtilizationPercent]),
    DATESINPERIOD(
        'Date'[Date],
        LASTDATE('Date'[Date]),
        -30,
        DAY
    )
)
VAR StdDevCPU = CALCULATE(
    STDEV.P(PerformanceMetrics[CPUUtilizationPercent]),
    DATESINPERIOD(
        'Date'[Date],
        LASTDATE('Date'[Date]),
        -30,
        DAY
    )
)
VAR ZScore = DIVIDE(CurrentCPU - BaselineCPU, StdDevCPU, 0)
RETURN
    IF(ABS(ZScore) > 3, "Anomaly", "Normal")

// Measure: Forecast Next 7 Days (Simplified Linear)
CPUForecast7Days = 
VAR RecentData = 
    CALCULATETABLE(
        ADDCOLUMNS(
            SUMMARIZE(
                PerformanceMetrics,
                'Date'[Date],
                "AvgCPU", AVERAGE(PerformanceMetrics[CPUUtilizationPercent])
            ),
            "DayNumber", DATEDIFF(MIN('Date'[Date]), 'Date'[Date], DAY)
        ),
        DATESINPERIOD(
            'Date'[Date],
            LASTDATE('Date'[Date]),
            -30,
            DAY
        )
    )
VAR Slope = 
    DIVIDE(
        SUMX(RecentData, [DayNumber] * [AvgCPU]) * COUNT(RecentData[Date]) - 
        SUM(RecentData[DayNumber]) * SUM(RecentData[AvgCPU]),
        SUMX(RecentData, [DayNumber] * [DayNumber]) * COUNT(RecentData[Date]) - 
        SUM(RecentData[DayNumber]) * SUM(RecentData[DayNumber]),
        0
    )
VAR Intercept = AVERAGE(RecentData[AvgCPU]) - Slope * AVERAGE(RecentData[DayNumber])
VAR FutureDay = MAX(RecentData[DayNumber]) + 7
RETURN
    Slope * FutureDay + Intercept

// Measure: Server Similarity Score (for clustering visualization)
SimilarityScore = 
VAR CurrentServerCPU = AVERAGE(PerformanceMetrics[CPUUtilizationPercent])
VAR CurrentServerPLE = AVERAGE(PerformanceMetrics[PageLifeExpectancy])
VAR SelectedServerCPU = 
    CALCULATE(
        AVERAGE(PerformanceMetrics[CPUUtilizationPercent]),
        ALLEXCEPT(PerformanceMetrics, Server[ServerName])
    )
VAR SelectedServerPLE = 
    CALCULATE(
        AVERAGE(PerformanceMetrics[PageLifeExpectancy]),
        ALLEXCEPT(PerformanceMetrics, Server[ServerName])
    )
RETURN
    1 - SQRT(
        POWER((CurrentServerCPU - SelectedServerCPU) / 100, 2) +
        POWER((CurrentServerPLE - SelectedServerPLE) / 1000, 2)
    )
```

Let me complete Chapter 14 with best practices, implementation guidelines, and a comprehensive ML case study:


---

## 14.7 Best Practices

### 14.7.1 ML Implementation Checklist

**Analytics and ML best practices:**

```
┌────────────────────────────────────────────────────────────┐
│         ADVANCED ANALYTICS BEST PRACTICES                   │
├────────────────────────────────────────────────────────────┤
│                                                             │
│ Data Quality:                                               │
│ ☐ Minimum 30 days of baseline data before predictions      │
│ ☐ Handle missing values (median imputation)                │
│ ☐ Remove outliers (>5 standard deviations)                 │
│ ☐ Feature scaling/normalization applied                    │
│ ☐ Sufficient sample size (1000+ observations minimum)      │
│                                                             │
│ Model Selection:                                            │
│ ☐ Start simple (linear regression) before complex          │
│ ☐ Prophet for time series forecasting                      │
│ ☐ Isolation Forest for anomaly detection                   │
│ ☐ K-Means for server clustering                            │
│ ☐ Random Forest for classification                         │
│                                                             │
│ Validation:                                                 │
│ ☐ Train/test split (80/20)                                 │
│ ☐ Cross-validation for robustness                          │
│ ☐ Track model accuracy over time                           │
│ ☐ Regular model retraining (monthly)                       │
│ ☐ A/B testing for new models                               │
│                                                             │
│ Forecasting:                                                │
│ ☐ Multiple forecast horizons (7, 30, 90 days)              │
│ ☐ Confidence intervals provided                            │
│ ☐ Seasonal patterns accounted for                          │
│ ☐ Alert thresholds based on upper bound                    │
│ ☐ Visual trend indicators                                  │
│                                                             │
│ Anomaly Detection:                                          │
│ ☐ Baseline period: 30+ days                                │
│ ☐ Threshold: 3 standard deviations                         │
│ ☐ Minimum 100 samples for statistics                       │
│ ☐ Feedback loop (confirm/reject anomalies)                 │
│ ☐ Multiple detection methods (ensemble)                    │
│                                                             │
│ Automation:                                                 │
│ ☐ Auto-remediation requires approval                       │
│ ☐ Test in dev environment first                            │
│ ☐ Rollback plan documented                                 │
│ ☐ Audit log of all auto-actions                            │
│ ☐ Human oversight for critical actions                     │
│                                                             │
│ Performance:                                                │
│ ☐ ML models run off-peak hours                             │
│ ☐ Batch predictions (not real-time) for efficiency         │
│ ☐ Cache forecast results                                   │
│ ☐ Incremental training (not full retrain)                  │
│ ☐ Monitor ML infrastructure resource usage                 │
│                                                             │
│ Governance:                                                 │
│ ☐ Model versioning tracked                                 │
│ ☐ Feature importance documented                            │
│ ☐ Predictions explained to stakeholders                    │
│ ☐ Regular accuracy reviews (monthly)                       │
│ ☐ Bias detection and mitigation                            │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

---

## 14.8 Case Study: E-Commerce Platform Predictive Analytics

**Background:**

ShopNow operates 150 SQL Servers supporting global e-commerce platform.

**The Problem:**

**Reactive Operations:**
- Capacity issues discovered when disk full
- Performance degradation detected by users
- No early warning system
- 8 production outages in Q1 (capacity-related)
- $2.3M revenue lost to outages

**No Predictive Capability:**
- Can't forecast when capacity will be exhausted
- Can't predict performance degradation
- Can't identify similar failure patterns
- Manual capacity planning (spreadsheets)
- 40 hours/week on manual analysis

**The Solution (16-Week ML Implementation):**

**Phase 1: Data Foundation (Weeks 1-4)**

```sql
-- Consolidated 6 months of historical metrics
-- 52 million performance samples
-- 150 servers × 288 samples/day × 180 days = 7.8M samples

-- Data quality improvements:
- Removed outliers (>5σ)
- Filled missing values (median imputation)
- Added engineered features:
  * Hour of day
  * Day of week
  * Transaction volume
  * User count
```

**Phase 2: Capacity Forecasting (Weeks 5-8)**

```python
# Implemented Prophet forecasting for 150 servers
# 90-day forecast for disk capacity

Results after implementation:
- Forecast accuracy: 94.2% (within 5% of actual)
- Early warning: Average 28 days before capacity exhaustion
- Prevented 6 potential outages in first month
```

**Phase 3: Anomaly Detection (Weeks 9-12)**

```python
# Isolation Forest for performance anomalies
# Training on 30 days of "normal" data

Configuration:
- Contamination rate: 5% (expected anomaly %)
- Features: 7 performance metrics
- Threshold: Anomaly score < -0.3

Results:
- Detected 87% of incidents before user impact
- 12% false positive rate (acceptable)
- Average detection: 18 minutes before user complaints
```

**Phase 4: Intelligent Automation (Weeks 13-16)**

```sql
-- Auto-remediation rules
1. Clear cache when PLE < 300 (auto-execute)
2. Rebuild fragmented indexes >30% (auto-execute)
3. Kill blocking queries >1 hour (requires approval)
4. Scale database tier when DTU >90% (requires approval)

Results:
- 23 auto-remediations in first month
- 100% success rate
- Average remediation time: 90 seconds (vs. 45 minutes manual)
```

**Results After 6 Months:**

| Metric | Before ML | After ML | Improvement |
|--------|-----------|----------|-------------|
| **Capacity Management** ||||
| Capacity outages | 8/quarter | 0/6 months | **100% elimination** |
| Disk full incidents | 6/quarter | 0/6 months | **100% prevention** |
| Early warning (days) | 0 | 28 average | **28 days notice** |
| Forecast accuracy | N/A | 94.2% | Highly accurate |
| **Performance** ||||
| Anomalies detected early | 0% | 87% | **87% proactive** |
| Detection before user impact | N/A | 18 minutes | Early warning |
| False positive rate | N/A | 12% | Acceptable |
| Mean time to detect | 45 minutes | 3 minutes | **94% faster** |
| **Automation** ||||
| Auto-remediations | 0 | 23/month | Automated |
| Auto-remediation success | N/A | 100% | Perfect |
| Remediation time | 45 minutes | 90 seconds | **97% faster** |
| Manual analysis hours/week | 40 | 5 | **88% reduction** |
| **Business Impact** ||||
| Production outages (Q2) | 8 (baseline) | 1 | **88% reduction** |
| Revenue lost to outages | $2.3M/quarter | $180K/quarter | **92% reduction** |
| Customer complaints | 340/quarter | 45/quarter | **87% reduction** |

**Financial Impact:**

**Cost Avoidance:**
- Prevented outages: $2.12M/quarter × 4 = $8.48M/year
- Reduced manual analysis: 35 hrs/week × $75/hr × 52 = $136.5K/year
- Avoided emergency capacity purchases: $420K/year (proactive planning)
**Total Annual Benefits: $9.04M**

**Investment:**
- SQL Server ML Services: $25K
- Python environment setup: $15K
- ML model development: $120K (consulting)
- Training: $35K
**Total Investment: $195K**

**ROI: 4,536%**
**Payback Period: 8 days**

**CTO Statement:**

*"The ML-powered forecasting has completely changed how we manage capacity. We now know 28 days in advance when we'll need more disk space. We've gone from reactive firefighting to proactive planning. Zero capacity outages in 6 months is unprecedented."*

**Data Science Team Feedback:**

*"The Isolation Forest model was a perfect fit for anomaly detection. It detected 87% of incidents before users noticed, with only 12% false positives. The model improves as we feed it more data and confirm/reject anomalies."*

**DBA Team Feedback:**

*"Auto-remediation was scary at first, but after seeing 23 successful auto-fixes with zero failures, we're believers. It handles the routine issues instantly, freeing us to focus on complex problems. The 90-second average response time is impossible to match manually."*

**Key Success Factors:**

1. **Data Quality**: 6 months of clean baseline data
2. **Right Models**: Prophet for forecasting, Isolation Forest for anomalies
3. **Phased Approach**: Forecasting → Detection → Automation
4. **Validation**: 94.2% forecast accuracy before relying on it
5. **Feedback Loop**: Confirming/rejecting anomalies improves model
6. **Conservative Automation**: Required approval for risky actions
7. **Monitoring**: Track ML model performance continuously

**Lessons Learned:**

1. **More Data Better**: Initially had 3 months; 6 months much better
2. **Feature Engineering Matters**: Hour-of-day pattern critical
3. **False Positives Acceptable**: 12% acceptable vs. missing 87% of incidents
4. **Start Conservative**: Began with 90-day forecasts; expanded to 180 days
5. **Retrain Regularly**: Monthly retraining keeps model accurate
6. **Visualize Results**: Power BI forecast dashboard critical for adoption
7. **Human Oversight**: Auto-remediation requires monitoring first month

**Unexpected Benefits:**

1. **Capacity Planning**: Now plan 6 months ahead vs. reactive
2. **Cost Optimization**: Right-sized 23 over-provisioned servers ($380K/year savings)
3. **Vendor Negotiations**: Forecast enabled bulk storage purchases (15% discount)
4. **Team Morale**: DBAs happier doing strategic work vs. firefighting
5. **Business Confidence**: Sales team can commit to SLAs with confidence

---

## Chapter 14 Summary

This chapter covered advanced analytics and machine learning:

**Key Takeaways:**

1. **Statistical Foundations**: Time series analysis, correlation, regression
2. **Predictive Forecasting**: Prophet for capacity, linear regression for trends
3. **Anomaly Detection**: Z-score (statistical), Isolation Forest (ML)
4. **Pattern Recognition**: K-Means clustering for server grouping
5. **Intelligent Automation**: ML-driven auto-remediation
6. **Visualization**: Power BI DAX for advanced analytics
7. **Best Practices**: Data quality, model validation, feedback loops

**Production Implementation:**

✅ Time series analysis functions
✅ Linear regression forecasting
✅ Prophet integration (Python)
✅ Z-score anomaly detection
✅ Isolation Forest ML model
✅ K-Means server clustering
✅ Auto-remediation framework
✅ Index recommendation engine
✅ Power BI ML visualizations
✅ Model tracking and versioning

**ML Models Implemented:**

✅ **Prophet:** Capacity forecasting (94% accuracy)
✅ **Isolation Forest:** Anomaly detection (87% early detection)
✅ **K-Means:** Server clustering (workload patterns)
✅ **Linear Regression:** Trend analysis
✅ **Random Forest:** (mentioned for classification)

**Best Practices:**

✅ 30+ days baseline before predictions
✅ 80/20 train/test split
✅ Monthly model retraining
✅ Feedback loop for anomalies
✅ Conservative automation (approval required)
✅ Multiple forecast horizons (7, 30, 90 days)
✅ Confidence intervals provided
✅ A/B testing for new models
✅ Model versioning tracked
✅ Regular accuracy reviews

**Business Value:**

✅ **28 days early warning** for capacity
✅ **94% forecast accuracy**
✅ **87% proactive anomaly detection**
✅ **97% faster remediation** (90s vs 45min)
✅ **88% reduction in manual analysis**
✅ **100% capacity outage elimination**
✅ **$9M+ annual value** (ShopNow case)

**Connection to Next Chapter:**

Chapter 15 covers Troubleshooting and Root Cause Analysis, showing how to leverage the DBAOps framework to quickly diagnose issues, perform root cause analysis, and implement permanent fixes based on historical patterns and analytics.

---

## Review Questions

**Multiple Choice:**

1. What forecast accuracy did ShopNow achieve?
   a) 75%
   b) 85%
   c) 94.2%
   d) 99%

2. What is the recommended minimum baseline period for ML models?
   a) 7 days
   b) 14 days
   c) 30 days
   d) 90 days

3. What ML algorithm is recommended for anomaly detection?
   a) Linear Regression
   b) K-Means
   c) Isolation Forest
   d) Prophet

**Short Answer:**

4. Explain the difference between statistical anomaly detection (Z-score) and ML-based anomaly detection (Isolation Forest).

5. Why is a feedback loop important for anomaly detection models?

6. Describe the components of an auto-remediation framework. What safety measures should be in place?

**Essay Questions:**

7. Design a complete ML implementation for an organization with 200 SQL Servers. Include:
   - Data collection and preparation
   - Model selection for forecasting and anomaly detection
   - Validation approach
   - Automation strategy
   - Governance and monitoring

8. Analyze the ShopNow case study. What were the critical success factors? What risks did ML automation introduce? How were they mitigated?

**Hands-On Exercises:**

9. **Exercise 14.1: Implement Capacity Forecasting**
   - Collect 90 days of disk space data
   - Implement linear regression forecast
   - Calculate forecast accuracy
   - Generate capacity alerts
   - Create forecast visualization

10. **Exercise 14.2: Anomaly Detection**
    - Implement Z-score anomaly detection
    - Deploy Isolation Forest ML model
    - Compare detection rates
    - Tune thresholds
    - Create feedback loop

11. **Exercise 14.3: Server Clustering**
    - Collect server performance characteristics
    - Implement K-Means clustering
    - Analyze cluster patterns
    - Assign cluster names
    - Create cluster visualization

12. **Exercise 14.4: Auto-Remediation**
    - Define remediation actions
    - Implement condition evaluation
    - Create approval workflow
    - Test in dev environment
    - Monitor success rate

---

*End of Chapter 14*

**Next Chapter:** Chapter 15 - Troubleshooting and Root Cause Analysis

