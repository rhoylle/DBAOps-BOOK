# Chapter 9
# Security and Compliance

---

**Learning Objectives**

Upon completing this chapter, students will be able to:

1. **Implement** comprehensive security for the DBAOps framework
2. **Configure** role-based access control (RBAC) for dashboards and reports
3. **Secure** credential storage and management
4. **Audit** all framework operations for compliance
5. **Meet** regulatory requirements (SOX, HIPAA, PCI-DSS, GDPR)
6. **Encrypt** data at rest and in transit
7. **Monitor** security events and detect anomalies
8. **Demonstrate** compliance through automated reporting

**Key Terms**

- Role-Based Access Control (RBAC)
- Principle of Least Privilege
- Defense in Depth
- Encryption at Rest
- Encryption in Transit
- Audit Trail
- Compliance Framework
- Data Classification
- Security Baseline
- Threat Modeling

---

## 9.1 Security Architecture

### 9.1.1 Defense in Depth

**Figure 9.1: DBAOps Security Layers**

```
┌─────────────────────────────────────────────────────────────┐
│              DEFENSE IN DEPTH ARCHITECTURE                   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Layer 7: Audit & Monitoring                                │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • All actions logged                                │    │
│  │ • Security event monitoring                         │    │
│  │ • Anomaly detection                                 │    │
│  │ • Compliance reporting                              │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↓                                    │
│  Layer 6: Application Security                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Input validation                                  │    │
│  │ • SQL injection prevention                          │    │
│  │ • XSS protection                                    │    │
│  │ • CSRF tokens                                       │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↓                                    │
│  Layer 5: Data Encryption                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • TDE (Transparent Data Encryption)                 │    │
│  │ • Column-level encryption                           │    │
│  │ • Backup encryption                                 │    │
│  │ • TLS 1.2+ in transit                              │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↓                                    │
│  Layer 4: Access Control                                    │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • RBAC (Role-Based Access Control)                  │    │
│  │ • Least privilege principle                         │    │
│  │ • MFA (Multi-Factor Authentication)                 │    │
│  │ • Password policies                                 │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↓                                    │
│  Layer 3: Network Security                                  │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Firewall rules                                    │    │
│  │ • Network segmentation                              │    │
│  │ • VPN for remote access                            │    │
│  │ • IP whitelisting                                   │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↓                                    │
│  Layer 2: OS Security                                       │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Windows updates                                   │    │
│  │ • Antivirus/EDR                                     │    │
│  │ • Hardened configurations                           │    │
│  │ • Disabled unnecessary services                     │    │
│  └────────────────────────────────────────────────────┘    │
│                         ↓                                    │
│  Layer 1: Physical Security                                 │
│  ┌────────────────────────────────────────────────────┐    │
│  │ • Datacenter access control                         │    │
│  │ • Server rack locks                                 │    │
│  │ • Video surveillance                                │    │
│  │ • Visitor logs                                      │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

### 9.1.2 Threat Model

**STRIDE Analysis for DBAOps:**

| Threat | Example | Mitigation |
|--------|---------|------------|
| **Spoofing** | Attacker impersonates DBA | Windows Auth + MFA, no SQL auth |
| **Tampering** | Modify metrics in repository | TDE, audit trail, checksums |
| **Repudiation** | Deny deleting backup | Comprehensive audit logging |
| **Information Disclosure** | Steal connection strings | Encrypted credentials, no plain text |
| **Denial of Service** | Overload collector | Rate limiting, circuit breakers |
| **Elevation of Privilege** | Gain admin rights | RBAC, least privilege, monitoring |

---

## 9.2 Role-Based Access Control

### 9.2.1 Security Roles

**Table 9.1: DBAOps Security Roles**

| Role | Description | Permissions | Users |
|------|-------------|-------------|-------|
| **DBAOps_Admin** | Full control | All operations | Senior DBAs (2-3) |
| **DBAOps_Operator** | Day-to-day operations | Read/write data, acknowledge alerts | DBA team (10-15) |
| **DBAOps_Developer** | Development/testing | Read-only, limited write | Developers (20-30) |
| **DBAOps_Auditor** | Compliance review | Read-only, export reports | Auditors (3-5) |
| **DBAOps_Executive** | Strategic oversight | Dashboard access, reports | Management (5-10) |
| **DBAOps_ReadOnly** | View only | Read all, no modifications | Everyone else |

**Implementation:**

```sql
-- Create database roles
USE DBAOpsRepository;
GO

-- Admin role: Full control
CREATE ROLE DBAOps_Admin;
GRANT CONTROL ON DATABASE::DBAOpsRepository TO DBAOps_Admin;

-- Operator role: Daily operations
CREATE ROLE DBAOps_Operator;
GRANT SELECT, INSERT, UPDATE ON SCHEMA::fact TO DBAOps_Operator;
GRANT SELECT, INSERT, UPDATE ON SCHEMA::ctl TO DBAOps_Operator;
GRANT SELECT, INSERT ON SCHEMA::log TO DBAOps_Operator;
GRANT SELECT, INSERT, UPDATE ON SCHEMA::alert TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::config TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::dim TO DBAOps_Operator;
GRANT SELECT ON SCHEMA::reports TO DBAOps_Operator;
GRANT EXECUTE ON SCHEMA::alert TO DBAOps_Operator;
GRANT EXECUTE ON SCHEMA::reports TO DBAOps_Operator;

-- Developer role: Read-only with limited write to test schemas
CREATE ROLE DBAOps_Developer;
GRANT SELECT ON SCHEMA::fact TO DBAOps_Developer;
GRANT SELECT ON SCHEMA::dim TO DBAOps_Developer;
GRANT SELECT ON SCHEMA::config TO DBAOps_Developer;
GRANT SELECT ON SCHEMA::ctl TO DBAOps_Developer;
GRANT SELECT ON SCHEMA::reports TO DBAOps_Developer;
-- Can insert to test tables only
GRANT INSERT ON SCHEMA::test TO DBAOps_Developer;

-- Auditor role: Read-only with export
CREATE ROLE DBAOps_Auditor;
GRANT SELECT ON SCHEMA::fact TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::dim TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::config TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::ctl TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::log TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::alert TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::reports TO DBAOps_Auditor;
GRANT SELECT ON SCHEMA::security TO DBAOps_Auditor;

-- Executive role: Reports and dashboards only
CREATE ROLE DBAOps_Executive;
GRANT SELECT ON SCHEMA::reports TO DBAOps_Executive;
GRANT EXECUTE ON SCHEMA::reports TO DBAOps_Executive;

-- Read-only role: View access only
CREATE ROLE DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::fact TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::dim TO DBAOps_ReadOnly;
GRANT SELECT ON SCHEMA::reports TO DBAOps_ReadOnly;

-- Add users to roles
ALTER ROLE DBAOps_Admin ADD MEMBER [DOMAIN\DBA-Senior-Team];
ALTER ROLE DBAOps_Operator ADD MEMBER [DOMAIN\DBA-Team];
ALTER ROLE DBAOps_Operator ADD MEMBER [DBAOps-ServiceAccount];
ALTER ROLE DBAOps_Developer ADD MEMBER [DOMAIN\Developers];
ALTER ROLE DBAOps_Auditor ADD MEMBER [DOMAIN\Auditors];
ALTER ROLE DBAOps_Executive ADD MEMBER [DOMAIN\Management];
ALTER ROLE DBAOps_ReadOnly ADD MEMBER [DOMAIN\AllStaff];
```

---

### 9.2.2 Row-Level Security

**Restrict data access by environment:**

```sql
-- Create security policy for environment-based access
CREATE SCHEMA security;
GO

-- Security predicate function
CREATE FUNCTION security.fn_EnvironmentAccessPredicate(@Environment VARCHAR(20))
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
    SELECT 1 AS AccessAllowed
    WHERE 
        -- Admins see all environments
        IS_MEMBER('DBAOps_Admin') = 1
        OR
        -- Operators see Production and QA
        (IS_MEMBER('DBAOps_Operator') = 1 AND @Environment IN ('Production', 'QA'))
        OR
        -- Developers see only Development
        (IS_MEMBER('DBAOps_Developer') = 1 AND @Environment = 'Development')
        OR
        -- Executives see Production only
        (IS_MEMBER('DBAOps_Executive') = 1 AND @Environment = 'Production');
GO

-- Apply security policy to server dimension
CREATE SECURITY POLICY security.ServerEnvironmentPolicy
ADD FILTER PREDICATE security.fn_EnvironmentAccessPredicate(Environment)
ON dim.Server
WITH (STATE = ON);
GO

-- Now queries automatically filter by environment
SELECT * FROM dim.Server;  -- Each role sees only allowed environments

-- Test as different roles
EXECUTE AS USER = 'DeveloperUser';
SELECT ServerName, Environment FROM dim.Server;  -- Only Development
REVERT;

EXECUTE AS USER = 'ExecutiveUser';
SELECT ServerName, Environment FROM dim.Server;  -- Only Production
REVERT;
```

---

## 9.3 Credential Management

### 9.3.1 Secure Credential Storage

**Never store plain text passwords:**

```sql
-- Create credential vault table
CREATE TABLE security.CredentialVault (
    CredentialID INT IDENTITY(1,1) PRIMARY KEY,
    CredentialName VARCHAR(100) NOT NULL UNIQUE,
    Username VARCHAR(100) NOT NULL,
    
    -- Encrypted password (using symmetric key)
    EncryptedPassword VARBINARY(256) NOT NULL,
    
    -- Purpose and scope
    Purpose VARCHAR(200),
    ServerScope VARCHAR(200),  -- Which servers this applies to
    
    -- Rotation tracking
    CreatedDate DATETIME2 DEFAULT SYSDATETIME(),
    CreatedBy NVARCHAR(128) DEFAULT SUSER_SNAME(),
    LastRotatedDate DATETIME2,
    RotationFrequencyDays INT DEFAULT 90,
    
    -- Audit
    LastAccessedDate DATETIME2,
    AccessCount INT DEFAULT 0,
    
    IsActive BIT DEFAULT 1
);

-- Create master key for encryption
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'VerySecurePassword123!';

-- Create certificate for encrypting credentials
CREATE CERTIFICATE DBAOpsCert
WITH SUBJECT = 'DBAOps Credential Encryption';

-- Create symmetric key
CREATE SYMMETRIC KEY DBAOpsKey
WITH ALGORITHM = AES_256
ENCRYPTION BY CERTIFICATE DBAOpsCert;
GO

-- Procedure to add encrypted credential
CREATE PROCEDURE security.usp_AddCredential
    @CredentialName VARCHAR(100),
    @Username VARCHAR(100),
    @Password VARCHAR(100),
    @Purpose VARCHAR(200),
    @ServerScope VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Open symmetric key
    OPEN SYMMETRIC KEY DBAOpsKey
    DECRYPTION BY CERTIFICATE DBAOpsCert;
    
    -- Insert encrypted password
    INSERT INTO security.CredentialVault (
        CredentialName, Username, EncryptedPassword,
        Purpose, ServerScope
    )
    VALUES (
        @CredentialName,
        @Username,
        ENCRYPTBYKEY(KEY_GUID('DBAOpsKey'), @Password),
        @Purpose,
        @ServerScope
    );
    
    -- Close key
    CLOSE SYMMETRIC KEY DBAOpsKey;
    
    PRINT 'Credential added: ' + @CredentialName;
END
GO

-- Procedure to retrieve credential
CREATE PROCEDURE security.usp_GetCredential
    @CredentialName VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Only DBAOps_Operator and Admin can retrieve credentials
    IF IS_MEMBER('DBAOps_Operator') = 0 AND IS_MEMBER('DBAOps_Admin') = 0
    BEGIN
        RAISERROR('Access denied. Insufficient permissions to retrieve credentials.', 16, 1);
        RETURN;
    END
    
    -- Open symmetric key
    OPEN SYMMETRIC KEY DBAOpsKey
    DECRYPTION BY CERTIFICATE DBAOpsCert;
    
    -- Retrieve and decrypt
    SELECT 
        CredentialName,
        Username,
        CONVERT(VARCHAR(100), DECRYPTBYKEY(EncryptedPassword)) AS Password,
        Purpose,
        ServerScope
    FROM security.CredentialVault
    WHERE CredentialName = @CredentialName
      AND IsActive = 1;
    
    -- Update access tracking
    UPDATE security.CredentialVault
    SET LastAccessedDate = SYSDATETIME(),
        AccessCount = AccessCount + 1
    WHERE CredentialName = @CredentialName;
    
    -- Close key
    CLOSE SYMMETRIC KEY DBAOpsKey;
    
    -- Audit the access
    INSERT INTO security.CredentialAccessLog (
        CredentialName, AccessedBy, AccessDate
    )
    VALUES (@CredentialName, SUSER_SNAME(), SYSDATETIME());
END
GO

-- Usage example
EXEC security.usp_AddCredential 
    @CredentialName = 'SQL-Monitor-Account',
    @Username = 'DOMAIN\svc-sqlmonitor',
    @Password = 'SecurePass123!',
    @Purpose = 'Data collection service account',
    @ServerScope = 'All Production Servers';
```

---

### 9.3.2 Azure Key Vault Integration

**Production-grade credential management:**

```powershell
<#
.SYNOPSIS
    Retrieve credentials from Azure Key Vault

.DESCRIPTION
    Secure credential retrieval for DBAOps collectors
    Uses Managed Identity for authentication
#>

function Get-DBAOpsCredential {
    param(
        [Parameter(Mandatory)]
        [string]$CredentialName,
        
        [string]$KeyVaultName = "dbaops-keyvault"
    )
    
    try {
        # Import Azure modules
        Import-Module Az.KeyVault -ErrorAction Stop
        
        # Connect using Managed Identity (no credentials needed)
        Connect-AzAccount -Identity -ErrorAction Stop
        
        # Retrieve secret
        $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName `
                                       -Name $CredentialName `
                                       -ErrorAction Stop
        
        # Convert to PSCredential
        $username = $secret.Tags["Username"]
        $password = $secret.SecretValue
        
        $credential = New-Object System.Management.Automation.PSCredential(
            $username, $password
        )
        
        # Log access (for audit)
        Write-EventLog -LogName "Application" `
                      -Source "DBAOps" `
                      -EventId 1001 `
                      -Message "Credential retrieved: $CredentialName by $env:USERNAME"
        
        return $credential
    }
    catch {
        Write-Error "Failed to retrieve credential from Key Vault: $_"
        
        # Log failure
        Write-EventLog -LogName "Application" `
                      -Source "DBAOps" `
                      -EventId 9001 `
                      -EntryType Error `
                      -Message "Failed to retrieve credential: $CredentialName. Error: $_"
        
        throw
    }
}

# Usage in collectors
$credential = Get-DBAOpsCredential -CredentialName "SQL-Monitor-Account"

Invoke-DbaQuery -SqlInstance "PROD-SQL01" `
                -Database "master" `
                -Query "SELECT @@VERSION" `
                -SqlCredential $credential
```

Let me continue with encryption, audit logging, and compliance frameworks:


---

## 9.4 Data Encryption

### 9.4.1 Transparent Data Encryption (TDE)

**Encrypt repository database at rest:**

```sql
-- Step 1: Create master key in master database
USE master;
GO

CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'VeryStrongPassword123!@#';
GO

-- Step 2: Create certificate
CREATE CERTIFICATE DBAOpsRepoCert
WITH SUBJECT = 'DBAOps Repository TDE Certificate',
     EXPIRY_DATE = '2027-12-31';
GO

-- CRITICAL: Backup certificate immediately
BACKUP CERTIFICATE DBAOpsRepoCert
TO FILE = 'E:\Backups\Certificates\DBAOpsRepoCert.cer'
WITH PRIVATE KEY (
    FILE = 'E:\Backups\Certificates\DBAOpsRepoCert_PrivateKey.pvk',
    ENCRYPTION BY PASSWORD = 'CertificateBackupPassword456!@#'
);
-- Store these files in secure location (not on SQL Server!)

-- Step 3: Create database encryption key
USE DBAOpsRepository;
GO

CREATE DATABASE ENCRYPTION KEY
WITH ALGORITHM = AES_256
ENCRYPTION BY SERVER CERTIFICATE DBAOpsRepoCert;
GO

-- Step 4: Enable TDE
ALTER DATABASE DBAOpsRepository
SET ENCRYPTION ON;
GO

-- Step 5: Verify encryption status
SELECT 
    db_name(database_id) AS DatabaseName,
    encryption_state,
    CASE encryption_state
        WHEN 0 THEN 'No database encryption key present'
        WHEN 1 THEN 'Unencrypted'
        WHEN 2 THEN 'Encryption in progress'
        WHEN 3 THEN 'Encrypted'
        WHEN 4 THEN 'Key change in progress'
        WHEN 5 THEN 'Decryption in progress'
        WHEN 6 THEN 'Protection change in progress'
    END AS EncryptionState,
    percent_complete,
    encryptor_type,
    CASE encryptor_type
        WHEN 'CERTIFICATE' THEN 'Certificate'
        WHEN 'ASYMMETRIC KEY' THEN 'Asymmetric Key'
    END AS EncryptorType
FROM sys.dm_database_encryption_keys
WHERE db_name(database_id) = 'DBAOpsRepository';

-- Expected result: encryption_state = 3 (Encrypted)
```

---

### 9.4.2 Column-Level Encryption for Sensitive Data

**Encrypt sensitive configuration data:**

```sql
-- Encrypt email addresses and notification lists
USE DBAOpsRepository;
GO

-- Add encrypted columns
ALTER TABLE config.ServerInventory
ADD EncryptedPrimaryContact VARBINARY(256);

ALTER TABLE alert.AlertRules
ADD EncryptedRecipients VARBINARY(512);
GO

-- Procedure to encrypt and store contact info
CREATE PROCEDURE config.usp_UpdateServerContact
    @ServerName NVARCHAR(128),
    @PrimaryContact VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Open symmetric key
    OPEN SYMMETRIC KEY DBAOpsKey
    DECRYPTION BY CERTIFICATE DBAOpsCert;
    
    -- Update with encrypted value
    UPDATE config.ServerInventory
    SET EncryptedPrimaryContact = ENCRYPTBYKEY(KEY_GUID('DBAOpsKey'), @PrimaryContact),
        ModifiedDate = SYSDATETIME(),
        ModifiedBy = SUSER_SNAME()
    WHERE ServerName = @ServerName;
    
    -- Close key
    CLOSE SYMMETRIC KEY DBAOpsKey;
END
GO

-- View to decrypt for authorized users
CREATE VIEW config.vw_ServerContacts
WITH ENCRYPTION  -- Encrypt view definition too
AS
SELECT 
    ServerName,
    Environment,
    -- Decrypt only if user has permission
    CASE 
        WHEN IS_MEMBER('DBAOps_Admin') = 1 OR IS_MEMBER('DBAOps_Operator') = 1
        THEN CONVERT(VARCHAR(100), DECRYPTBYKEY(EncryptedPrimaryContact))
        ELSE '*** REDACTED ***'
    END AS PrimaryContact
FROM config.ServerInventory
WHERE IsActive = 1;
GO
```

---

### 9.4.3 Backup Encryption

**Encrypt all backups:**

```sql
-- Create credential for backup encryption
CREATE CREDENTIAL DBAOpsBackupCredential
WITH IDENTITY = 'DBAOps Backup Encryption',
     SECRET = 'BackupEncryptionPassword789!@#';
GO

-- Backup repository with encryption
BACKUP DATABASE DBAOpsRepository
TO DISK = 'E:\Backups\DBAOpsRepository_Full.bak'
WITH 
    COMPRESSION,
    ENCRYPTION (
        ALGORITHM = AES_256,
        SERVER CERTIFICATE = DBAOpsRepoCert
    ),
    CHECKSUM,
    STATS = 10;
GO

-- Verify backup can be restored (test on DR server)
RESTORE VERIFYONLY
FROM DISK = 'E:\Backups\DBAOpsRepository_Full.bak'
WITH CHECKSUM;
```

---

## 9.5 Comprehensive Audit Logging

### 9.5.1 SQL Server Audit

**Capture all access to sensitive data:**

```sql
-- Create server audit
USE master;
GO

CREATE SERVER AUDIT DBAOps_Audit
TO FILE (
    FILEPATH = 'L:\SQLAudit\',
    MAXSIZE = 100 MB,
    MAX_ROLLOVER_FILES = 20,
    RESERVE_DISK_SPACE = OFF
)
WITH (
    QUEUE_DELAY = 1000,  -- 1 second
    ON_FAILURE = CONTINUE  -- Don't stop SQL Server on audit failure
);
GO

-- Enable audit
ALTER SERVER AUDIT DBAOps_Audit
WITH (STATE = ON);
GO

-- Create database audit specification
USE DBAOpsRepository;
GO

CREATE DATABASE AUDIT SPECIFICATION DBAOps_DatabaseAudit
FOR SERVER AUDIT DBAOps_Audit
ADD (SELECT, INSERT, UPDATE, DELETE ON security.CredentialVault BY public),
ADD (SELECT ON security.vw_ServerContacts BY public),
ADD (EXECUTE ON security.usp_GetCredential BY public),
ADD (SELECT, INSERT, UPDATE, DELETE ON config.ServerInventory BY public),
ADD (SELECT, INSERT, UPDATE, DELETE ON alert.AlertRules BY public)
WITH (STATE = ON);
GO

-- Query audit log
SELECT 
    event_time,
    session_server_principal_name AS LoginName,
    server_principal_name AS UserName,
    database_name,
    schema_name,
    object_name,
    statement,
    succeeded
FROM sys.fn_get_audit_file('L:\SQLAudit\DBAOps_Audit*.sqlaudit', DEFAULT, DEFAULT)
WHERE event_time >= DATEADD(DAY, -7, GETDATE())
ORDER BY event_time DESC;
```

---

### 9.5.2 Application-Level Audit Trail

**Track all framework operations:**

```sql
CREATE TABLE security.AuditLog (
    AuditID BIGINT IDENTITY(1,1) PRIMARY KEY,
    AuditDate DATETIME2 DEFAULT SYSDATETIME(),
    
    -- Who
    Username NVARCHAR(128) DEFAULT SUSER_SNAME(),
    ApplicationName NVARCHAR(128) DEFAULT APP_NAME(),
    HostName NVARCHAR(128) DEFAULT HOST_NAME(),
    IPAddress VARCHAR(45),
    
    -- What
    OperationType VARCHAR(50),  -- SELECT, INSERT, UPDATE, DELETE, EXECUTE
    ObjectType VARCHAR(50),     -- TABLE, PROCEDURE, FUNCTION, VIEW
    ObjectName NVARCHAR(256),
    
    -- Details
    OperationDetails NVARCHAR(MAX),
    RowsAffected INT,
    
    -- Context
    SessionID INT DEFAULT @@SPID,
    TransactionID BIGINT DEFAULT CURRENT_TRANSACTION_ID(),
    
    -- Performance
    DurationMS INT,
    
    -- Result
    Success BIT,
    ErrorMessage NVARCHAR(MAX),
    
    INDEX IX_AuditLog_Date_Operation (AuditDate, OperationType) 
        INCLUDE (Username, ObjectName)
) ON [PRIMARY];

-- Procedure to log operations
CREATE PROCEDURE security.usp_LogOperation
    @OperationType VARCHAR(50),
    @ObjectType VARCHAR(50),
    @ObjectName NVARCHAR(256),
    @OperationDetails NVARCHAR(MAX) = NULL,
    @RowsAffected INT = NULL,
    @DurationMS INT = NULL,
    @Success BIT = 1,
    @ErrorMessage NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO security.AuditLog (
        OperationType, ObjectType, ObjectName,
        OperationDetails, RowsAffected, DurationMS,
        Success, ErrorMessage
    )
    VALUES (
        @OperationType, @ObjectType, @ObjectName,
        @OperationDetails, @RowsAffected, @DurationMS,
        @Success, @ErrorMessage
    );
END
GO

-- Example: Audit alert acknowledgment
CREATE TRIGGER alert.trg_AlertQueue_Acknowledge
ON alert.AlertQueue
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Only audit acknowledgments
    IF UPDATE(AcknowledgedDate)
    BEGIN
        INSERT INTO security.AuditLog (
            OperationType, ObjectType, ObjectName,
            OperationDetails, RowsAffected
        )
        SELECT 
            'UPDATE' AS OperationType,
            'ALERT' AS ObjectType,
            'alert.AlertQueue' AS ObjectName,
            'Alert ' + CAST(i.AlertID AS VARCHAR) + ' acknowledged by ' + 
            ISNULL(i.AcknowledgedBy, SUSER_SNAME()) AS OperationDetails,
            @@ROWCOUNT AS RowsAffected
        FROM inserted i
        WHERE i.AcknowledgedDate IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM deleted d 
              WHERE d.AlertID = i.AlertID 
                AND d.AcknowledgedDate IS NOT NULL
          );
    END
END
GO
```

---

## 9.6 Compliance Frameworks

### 9.6.1 SOX (Sarbanes-Oxley) Compliance

**SOX Requirements for DBAOps:**

**Table 9.2: SOX Control Mapping**

| SOX Control | Requirement | DBAOps Implementation |
|-------------|-------------|----------------------|
| **Access Controls** | Restrict database access to authorized personnel | RBAC with Windows Auth + MFA |
| **Segregation of Duties** | Separate read/write/admin access | 6 distinct roles with least privilege |
| **Audit Trail** | Log all changes to financial data | SQL Server Audit + AuditLog table |
| **Change Management** | Track all configuration changes | Version control, audit logging |
| **Backup & Recovery** | Regular backups with verification | Automated backups + restore testing |
| **Encryption** | Protect sensitive data | TDE + column encryption + backup encryption |

**SOX Compliance Report:**

```sql
CREATE PROCEDURE reports.usp_SOXComplianceReport
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- 1. Access Control Violations
    SELECT 
        'Access Control' AS ControlArea,
        'Unauthorized Access Attempts' AS Finding,
        COUNT(*) AS Violations
    FROM sys.fn_get_audit_file('L:\SQLAudit\*.sqlaudit', DEFAULT, DEFAULT)
    WHERE event_time BETWEEN @StartDate AND @EndDate
      AND succeeded = 0  -- Failed attempts
      AND action_id IN ('LGIS', 'LGIF');  -- Login success/failure
    
    -- 2. Segregation of Duties Compliance
    SELECT 
        'Segregation of Duties' AS ControlArea,
        'Users with Multiple Conflicting Roles' AS Finding,
        COUNT(DISTINCT member_principal_id) AS Violations
    FROM sys.database_role_members
    WHERE role_principal_id IN (
        USER_ID('DBAOps_Admin'),
        USER_ID('DBAOps_Auditor')
    )
    GROUP BY member_principal_id
    HAVING COUNT(DISTINCT role_principal_id) > 1;
    
    -- 3. Audit Trail Completeness
    SELECT 
        'Audit Trail' AS ControlArea,
        'Days with Missing Audit Logs' AS Finding,
        COUNT(*) AS Violations
    FROM (
        SELECT DISTINCT CAST(event_time AS DATE) AS AuditDate
        FROM sys.fn_get_audit_file('L:\SQLAudit\*.sqlaudit', DEFAULT, DEFAULT)
        WHERE event_time BETWEEN @StartDate AND @EndDate
    ) a
    RIGHT JOIN (
        SELECT DATEADD(DAY, number, @StartDate) AS ExpectedDate
        FROM master.dbo.spt_values
        WHERE type = 'P'
          AND DATEADD(DAY, number, @StartDate) <= @EndDate
    ) e ON a.AuditDate = e.ExpectedDate
    WHERE a.AuditDate IS NULL;
    
    -- 4. Configuration Change Tracking
    SELECT 
        'Change Management' AS ControlArea,
        'Configuration Changes' AS Finding,
        COUNT(*) AS TotalChanges,
        SUM(CASE WHEN Success = 0 THEN 1 ELSE 0 END) AS FailedChanges
    FROM security.AuditLog
    WHERE AuditDate BETWEEN @StartDate AND @EndDate
      AND OperationType IN ('INSERT', 'UPDATE', 'DELETE')
      AND ObjectType = 'TABLE'
      AND ObjectName LIKE 'config.%';
    
    -- 5. Backup Verification
    SELECT 
        'Backup & Recovery' AS ControlArea,
        'Databases Without Recent Backup' AS Finding,
        COUNT(*) AS Violations
    FROM ctl.BackupCompliance
    WHERE CheckedDate >= @StartDate
      AND IsCompliant = 0;
    
    -- 6. Encryption Status
    SELECT 
        'Data Protection' AS ControlArea,
        'Databases Without Encryption' AS Finding,
        COUNT(*) AS Violations
    FROM sys.databases d
    LEFT JOIN sys.dm_database_encryption_keys dek 
        ON d.database_id = dek.database_id
    WHERE d.name = 'DBAOpsRepository'
      AND (dek.encryption_state IS NULL OR dek.encryption_state <> 3);
END
GO
```

---

### 9.6.2 HIPAA Compliance

**HIPAA Requirements:**

```sql
-- HIPAA requires tracking access to PHI (Protected Health Information)
CREATE TABLE security.PHIAccessLog (
    AccessID BIGINT IDENTITY(1,1) PRIMARY KEY,
    AccessDate DATETIME2 DEFAULT SYSDATETIME(),
    
    -- Who accessed
    Username NVARCHAR(128),
    HostName NVARCHAR(128),
    ApplicationName NVARCHAR(128),
    
    -- What was accessed
    ServerName NVARCHAR(128),
    DatabaseName NVARCHAR(128),
    TableName NVARCHAR(256),
    
    -- Why (justification)
    AccessPurpose VARCHAR(200),
    
    -- Minimum necessary principle
    RowsAccessed INT,
    ColumnsAccessed NVARCHAR(MAX),
    
    -- Duration
    SessionDurationMinutes INT,
    
    INDEX IX_PHIAccessLog_Date_User (AccessDate, Username)
) ON [PRIMARY];

-- HIPAA Compliance Report
CREATE PROCEDURE reports.usp_HIPAAComplianceReport
    @ReportMonth DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @StartDate DATE = DATEADD(MONTH, DATEDIFF(MONTH, 0, @ReportMonth), 0);
    DECLARE @EndDate DATE = DATEADD(DAY, -1, DATEADD(MONTH, 1, @StartDate));
    
    -- 1. PHI Access Summary
    SELECT 
        'PHI Access Audit' AS ComplianceArea,
        COUNT(DISTINCT Username) AS UniqueUsers,
        COUNT(*) AS TotalAccesses,
        SUM(RowsAccessed) AS TotalRowsAccessed
    FROM security.PHIAccessLog
    WHERE AccessDate BETWEEN @StartDate AND @EndDate;
    
    -- 2. Users without documented access purpose
    SELECT 
        'Access Justification' AS ComplianceArea,
        COUNT(*) AS ViolationCount
    FROM security.PHIAccessLog
    WHERE AccessDate BETWEEN @StartDate AND @EndDate
      AND (AccessPurpose IS NULL OR AccessPurpose = '');
    
    -- 3. Encryption compliance
    SELECT 
        'Encryption' AS ComplianceArea,
        CASE 
            WHEN COUNT(*) = 0 THEN 'Compliant'
            ELSE 'Non-Compliant'
        END AS Status
    FROM sys.databases d
    LEFT JOIN sys.dm_database_encryption_keys dek 
        ON d.database_id = dek.database_id
    WHERE d.name LIKE '%Patient%'
      AND (dek.encryption_state IS NULL OR dek.encryption_state <> 3);
    
    -- 4. Audit log retention (6 years for HIPAA)
    SELECT 
        'Audit Retention' AS ComplianceArea,
        MIN(event_time) AS OldestAuditLog,
        DATEDIFF(YEAR, MIN(event_time), GETDATE()) AS YearsRetained,
        CASE 
            WHEN DATEDIFF(YEAR, MIN(event_time), GETDATE()) >= 6 THEN 'Compliant'
            ELSE 'Non-Compliant'
        END AS Status
    FROM sys.fn_get_audit_file('L:\SQLAudit\*.sqlaudit', DEFAULT, DEFAULT);
END
GO
```

---

### 9.6.3 PCI-DSS Compliance

**PCI-DSS Data Security Standard:**

```sql
-- PCI-DSS Requirement 10: Track and monitor all access to cardholder data
CREATE TABLE security.CardholderDataAccess (
    AccessID BIGINT IDENTITY(1,1) PRIMARY KEY,
    AccessDate DATETIME2 DEFAULT SYSDATETIME(),
    
    -- PCI Requirement 10.2.1: User identification
    Username NVARCHAR(128) NOT NULL,
    
    -- PCI Requirement 10.2.2: Type of event
    EventType VARCHAR(50) NOT NULL,
    
    -- PCI Requirement 10.2.3: Date and time
    -- Already captured in AccessDate
    
    -- PCI Requirement 10.2.4: Success or failure
    Success BIT NOT NULL,
    
    -- PCI Requirement 10.2.5: Origination of event
    HostName NVARCHAR(128),
    IPAddress VARCHAR(45),
    
    -- PCI Requirement 10.2.6: Identity or name of affected data
    AffectedResource NVARCHAR(256),
    
    -- Additional context
    EventDetails NVARCHAR(MAX),
    
    INDEX IX_CardholderDataAccess_Date (AccessDate DESC)
        INCLUDE (Username, EventType, Success)
);

-- PCI-DSS Compliance Dashboard
CREATE PROCEDURE reports.usp_PCIDSSComplianceReport
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Requirement 1: Firewall configuration (manual verification)
    SELECT 'Requirement 1' AS Requirement, 'Firewall Configuration' AS Description, 
           'Manual Verification Required' AS Status;
    
    -- Requirement 2: No default passwords (check service accounts)
    SELECT 'Requirement 2' AS Requirement, 'Default Credentials' AS Description,
           CASE 
               WHEN EXISTS (
                   SELECT 1 FROM security.CredentialVault 
                   WHERE Username LIKE '%admin%' 
                      OR Username LIKE '%sa%'
               )
               THEN 'Review Required'
               ELSE 'Compliant'
           END AS Status;
    
    -- Requirement 3: Protect stored cardholder data (encryption)
    SELECT 'Requirement 3' AS Requirement, 'Data Encryption' AS Description,
           CASE 
               WHEN EXISTS (
                   SELECT 1 FROM sys.dm_database_encryption_keys 
                   WHERE encryption_state = 3
               )
               THEN 'Compliant - TDE Enabled'
               ELSE 'Non-Compliant - TDE Disabled'
           END AS Status;
    
    -- Requirement 4: Encrypt transmission (check for TLS)
    SELECT 'Requirement 4' AS Requirement, 'Encryption in Transit' AS Description,
           'Verify TLS 1.2+ Enforced' AS Status;
    
    -- Requirement 10: Track and monitor access
    SELECT 'Requirement 10' AS Requirement, 'Access Monitoring' AS Description,
           CASE 
               WHEN COUNT(*) > 0 THEN 'Compliant - ' + CAST(COUNT(*) AS VARCHAR) + ' events logged'
               ELSE 'Non-Compliant - No logs found'
           END AS Status
    FROM security.CardholderDataAccess
    WHERE AccessDate >= DATEADD(DAY, -1, GETDATE());
END
GO
```

Let me complete Chapter 9 with security monitoring, best practices, and a comprehensive case study:


---

## 9.7 Security Monitoring

### 9.7.1 Security Event Detection

**Detect suspicious activity:**

```sql
CREATE PROCEDURE security.usp_DetectSecurityAnomalies
AS
BEGIN
    SET NOCOUNT ON;
    
    -- 1. Multiple failed login attempts (brute force)
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage,
        ServerName
    )
    SELECT 
        100 AS AlertRuleID,
        'Critical' AS Severity,
        'Potential Brute Force Attack on ' + server_principal_name AS AlertTitle,
        'User ' + server_principal_name + ' has ' + 
        CAST(COUNT(*) AS VARCHAR) + ' failed login attempts in the last hour' AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM sys.fn_get_audit_file('L:\SQLAudit\*.sqlaudit', DEFAULT, DEFAULT)
    WHERE event_time >= DATEADD(HOUR, -1, GETDATE())
      AND action_id = 'LGIF'  -- Login failed
      AND succeeded = 0
    GROUP BY server_principal_name
    HAVING COUNT(*) >= 5;  -- 5+ failures in an hour
    
    -- 2. After-hours access to sensitive data
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage,
        ServerName
    )
    SELECT 
        101 AS AlertRuleID,
        'High' AS Severity,
        'After-Hours Sensitive Data Access' AS AlertTitle,
        'User ' + Username + ' accessed credential vault at ' + 
        CONVERT(VARCHAR, AccessDate, 120) AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM security.AuditLog
    WHERE AuditDate >= DATEADD(HOUR, -1, GETDATE())
      AND ObjectName = 'security.CredentialVault'
      AND DATEPART(HOUR, AuditDate) NOT BETWEEN 7 AND 18  -- Outside 7 AM - 6 PM
      AND DATEPART(WEEKDAY, AuditDate) NOT IN (1, 7);  -- Not weekends
    
    -- 3. Privilege escalation attempts
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage,
        ServerName
    )
    SELECT 
        102 AS AlertRuleID,
        'Critical' AS Severity,
        'Privilege Escalation Detected' AS AlertTitle,
        'User ' + DP1.name + ' was added to role ' + DP2.name AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM sys.database_role_members rm
    JOIN sys.database_principals DP1 ON rm.member_principal_id = DP1.principal_id
    JOIN sys.database_principals DP2 ON rm.role_principal_id = DP2.principal_id
    WHERE DP2.name IN ('DBAOps_Admin', 'db_owner')
      AND DP1.create_date >= DATEADD(HOUR, -1, GETDATE());
    
    -- 4. Unusual data access patterns
    WITH UserBaseline AS (
        SELECT 
            Username,
            AVG(RowsAffected) AS AvgRows,
            STDEV(RowsAffected) AS StdDevRows
        FROM security.AuditLog
        WHERE AuditDate >= DATEADD(DAY, -30, GETDATE())
          AND AuditDate < DATEADD(HOUR, -1, GETDATE())
          AND OperationType = 'SELECT'
        GROUP BY Username
        HAVING COUNT(*) >= 10  -- Need baseline data
    )
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage,
        ServerName
    )
    SELECT 
        103 AS AlertRuleID,
        'Medium' AS Severity,
        'Unusual Data Access Pattern' AS AlertTitle,
        'User ' + al.Username + ' queried ' + CAST(al.RowsAffected AS VARCHAR) + 
        ' rows (baseline: ' + CAST(CAST(ub.AvgRows AS INT) AS VARCHAR) + 
        ', +' + CAST(CAST((al.RowsAffected - ub.AvgRows) / NULLIF(ub.StdDevRows, 0) AS DECIMAL(5,1)) AS VARCHAR) + 'σ)' AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM security.AuditLog al
    JOIN UserBaseline ub ON al.Username = ub.Username
    WHERE al.AuditDate >= DATEADD(HOUR, -1, GETDATE())
      AND al.OperationType = 'SELECT'
      AND al.RowsAffected > ub.AvgRows + (3 * ub.StdDevRows);  -- More than 3 standard deviations
    
    -- 5. Credential access outside normal pattern
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage,
        ServerName
    )
    SELECT 
        104 AS AlertRuleID,
        'High' AS Severity,
        'Unusual Credential Access' AS AlertTitle,
        'Credential "' + CredentialName + '" accessed from new location: ' + 
        ISNULL(cal.HostName, 'Unknown') AS AlertMessage,
        HOST_NAME() AS ServerName
    FROM security.CredentialAccessLog cal
    WHERE cal.AccessDate >= DATEADD(HOUR, -1, GETDATE())
      AND NOT EXISTS (
          -- Not accessed from this host in past 30 days
          SELECT 1 
          FROM security.CredentialAccessLog cal2
          WHERE cal2.CredentialName = cal.CredentialName
            AND cal2.HostName = cal.HostName
            AND cal2.AccessDate < DATEADD(HOUR, -1, GETDATE())
            AND cal2.AccessDate >= DATEADD(DAY, -30, GETDATE())
      );
END
GO

-- Schedule security anomaly detection (every 15 minutes)
EXEC msdb.dbo.sp_add_job @job_name = 'DBAOps - Security Anomaly Detection';
EXEC msdb.dbo.sp_add_jobstep
    @job_name = 'DBAOps - Security Anomaly Detection',
    @step_name = 'Detect Anomalies',
    @subsystem = 'TSQL',
    @database_name = 'DBAOpsRepository',
    @command = 'EXEC security.usp_DetectSecurityAnomalies';

EXEC msdb.dbo.sp_add_schedule
    @schedule_name = 'Every 15 Minutes',
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 4,
    @freq_subday_interval = 15;
```

---

## 9.8 Best Practices

### 9.8.1 Security Checklist

**Deployment Security Checklist:**

✅ **Authentication**
- Windows Authentication enforced (no SQL logins except sa)
- Multi-factor authentication for admins
- Service accounts use Managed Service Accounts (MSA)
- Password policy enforced (complexity, length, rotation)

✅ **Authorization**
- RBAC implemented with 6 distinct roles
- Least privilege principle applied
- Row-level security for sensitive data
- Regular access reviews (quarterly)

✅ **Encryption**
- TDE enabled on repository database
- Column-level encryption for credentials
- Backup encryption enabled
- TLS 1.2+ for all connections

✅ **Audit & Monitoring**
- SQL Server Audit enabled
- Application audit logging implemented
- Security anomaly detection active
- Audit logs retained per compliance requirements

✅ **Credential Management**
- No plain text passwords
- Azure Key Vault integration
- Credential rotation every 90 days
- Secure backup of encryption certificates

✅ **Network Security**
- Firewall rules limiting SQL Server access
- Network segmentation (DMZ for web tier)
- VPN required for remote access
- IP whitelisting for collectors

✅ **Compliance**
- SOX controls documented and tested
- HIPAA compliance verified
- PCI-DSS requirements met
- Regular compliance audits scheduled

---

### 9.8.2 Incident Response Plan

**Security Incident Response Procedure:**

```sql
CREATE TABLE security.SecurityIncidents (
    IncidentID INT IDENTITY(1,1) PRIMARY KEY,
    IncidentDate DATETIME2 DEFAULT SYSDATETIME(),
    
    -- Classification
    Severity VARCHAR(20),  -- Critical, High, Medium, Low
    IncidentType VARCHAR(50),  -- Unauthorized Access, Data Breach, etc.
    
    -- Details
    Description NVARCHAR(MAX),
    AffectedSystems NVARCHAR(500),
    AffectedData NVARCHAR(500),
    
    -- Response
    DetectedBy NVARCHAR(128),
    DetectionMethod VARCHAR(100),
    ResponseActions NVARCHAR(MAX),
    
    -- Status
    Status VARCHAR(20) DEFAULT 'Open',  -- Open, Investigating, Contained, Resolved
    AssignedTo NVARCHAR(128),
    
    -- Timeline
    ContainmentDate DATETIME2,
    EradicationDate DATETIME2,
    RecoveryDate DATETIME2,
    ResolvedDate DATETIME2,
    
    -- Post-incident
    RootCause NVARCHAR(MAX),
    LessonsLearned NVARCHAR(MAX),
    PreventativeMeasures NVARCHAR(MAX),
    
    INDEX IX_SecurityIncidents_Date_Status (IncidentDate DESC, Status)
);

-- Incident response workflow
CREATE PROCEDURE security.usp_ReportSecurityIncident
    @Severity VARCHAR(20),
    @IncidentType VARCHAR(50),
    @Description NVARCHAR(MAX),
    @AffectedSystems NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @IncidentID INT;
    
    -- Create incident record
    INSERT INTO security.SecurityIncidents (
        Severity, IncidentType, Description, AffectedSystems,
        DetectedBy, DetectionMethod, Status
    )
    VALUES (
        @Severity, @IncidentType, @Description, @AffectedSystems,
        SUSER_SNAME(), 'Manual Report', 'Open'
    );
    
    SET @IncidentID = SCOPE_IDENTITY();
    
    -- Trigger alert to security team
    INSERT INTO alert.AlertQueue (
        AlertRuleID, Severity, AlertTitle, AlertMessage, ServerName
    )
    VALUES (
        200,
        @Severity,
        'SECURITY INCIDENT #' + CAST(@IncidentID AS VARCHAR) + ': ' + @IncidentType,
        @Description + CHAR(13) + CHAR(10) +
        'Affected Systems: ' + @AffectedSystems + CHAR(13) + CHAR(10) +
        'Reported By: ' + SUSER_SNAME(),
        HOST_NAME()
    );
    
    -- If critical, page on-call immediately
    IF @Severity = 'Critical'
    BEGIN
        -- Send to PagerDuty (implementation depends on setup)
        PRINT 'CRITICAL INCIDENT - Paging on-call team';
    END
    
    SELECT @IncidentID AS IncidentID;
END
GO
```

---

## 9.9 Case Study: Financial Services Security Hardening

**Background:**

SecureBank operates 200 SQL Servers storing customer financial data.

**The Problem (Pre-Hardening):**

**Security Posture:**
- Mixed Windows and SQL authentication
- 87 users with sysadmin rights
- No encryption (TDE or column-level)
- Audit logging disabled
- Passwords stored in plain text scripts
- No security monitoring
- Failed SOX audit

**Audit Findings:**
- **23 critical vulnerabilities**
- **67 high-risk issues**
- **$2.5M potential fine** for SOX violations
- **Regulatory remediation required** within 90 days

**The Solution (Security Hardening Project):**

**Phase 1: Authentication & Authorization (Weeks 1-2)**

```sql
-- Disable SQL authentication (except sa for emergencies)
ALTER LOGIN sa WITH CHECK_POLICY = ON, CHECK_EXPIRATION = ON;
ALTER LOGIN sa WITH PASSWORD = '<StrongPassword>' MUST_CHANGE;

-- Implement RBAC
CREATE ROLE SecureBank_Admin;
CREATE ROLE SecureBank_Operator;
CREATE ROLE SecureBank_ReadOnly;
CREATE ROLE SecureBank_Auditor;

-- Remove sysadmin from 87 users
-- Assign to appropriate roles based on job function
-- Result: 5 admins, 15 operators, 67 read-only
```

**Phase 2: Encryption (Weeks 3-4)**

```sql
-- Enable TDE on all 200 databases
-- Certificate backup to secure location
-- Column encryption for SSNs and account numbers
-- Backup encryption enabled
```

**Phase 3: Audit & Monitoring (Weeks 5-6)**

```sql
-- SQL Server Audit enabled on all instances
-- Application audit logging implemented
-- Security anomaly detection deployed
-- SIEM integration (Splunk)
```

**Phase 4: Credential Management (Week 7)**

```powershell
# Migrate all credentials to Azure Key Vault
# Implement Managed Identity
# Credential rotation automation
# Remove all plain text passwords from scripts
```

**Phase 5: Compliance Framework (Weeks 8-12)**

- Implemented SOX compliance reports
- Created PCI-DSS audit procedures
- Established quarterly access reviews
- Developed incident response plan
- Conducted security training for all DBAs

**Results After 90 Days:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Security Posture** ||||
| Sysadmin accounts | 87 | 5 | **94% reduction** |
| Databases with TDE | 0 | 200 | **100% encrypted** |
| Audit logging enabled | 0% | 100% | **Full coverage** |
| Plain text passwords | 156 | 0 | **100% eliminated** |
| **Compliance** ||||
| Critical vulnerabilities | 23 | 0 | **100% remediated** |
| High-risk issues | 67 | 3 | **96% remediated** |
| SOX compliance | Failed | Passed | **Compliant** |
| Audit findings | 90 | 3 | **97% reduction** |
| **Operations** ||||
| Security incidents/month | 12 | 1 | **92% reduction** |
| Incident detection time | 48 hours | 15 minutes | **99.5% faster** |
| Credential rotation | Manual/never | Automated/90 days | **Continuous** |

**Financial Impact:**

**Cost Avoidance:**
- SOX violation fine avoided: $2.5M
- PCI-DSS penalty avoided: $500K
- Potential data breach prevented: $4.2M (industry average)
**Total Avoided Costs: $7.2M**

**Operational Benefits:**
- Reduced incident response time: $180K/year
- Automated compliance reporting: $120K/year
- Reduced audit costs: $75K/year
**Total Annual Benefits: $375K**

**Investment:**
- Security hardening project: $450K
- Azure Key Vault: $12K/year
- Training: $45K
**Total Investment: $507K**

**ROI: 1,323%** (first year)
**Payback Period: 25 days**

**Auditor Feedback:**

*"SecureBank has transformed their security posture in just 90 days. The comprehensive defense-in-depth approach, combined with automated compliance reporting, sets a new standard for the industry. We've changed their rating from 'High Risk' to 'Low Risk.'"*

**CISO Statement:**

*"The DBAOps security framework gave us the tools to meet SOX requirements and avoid a $2.5M fine. More importantly, we've built a sustainable security program that protects our customers' data and our reputation. The automated anomaly detection caught a potential breach that would have cost us millions."*

**Key Success Factors:**

1. **Executive Support**: CISO prioritized project
2. **Phased Approach**: Tackled critical items first
3. **Automation**: Reduced manual compliance work by 95%
4. **Training**: Ensured DBA team understood new processes
5. **Continuous Monitoring**: Detected issues in minutes, not days
6. **Documentation**: Comprehensive audit trail for regulators

---

## Chapter 9 Summary

This chapter covered comprehensive security and compliance:

**Key Takeaways:**

1. **Defense in Depth**: 7 layers of security from physical to audit
2. **RBAC Essential**: 6 roles with least privilege principle
3. **Encryption Everywhere**: TDE + column-level + backup + transit
4. **Comprehensive Audit**: SQL Server Audit + application logging
5. **Compliance Frameworks**: SOX, HIPAA, PCI-DSS automation
6. **Credential Security**: Azure Key Vault + no plain text
7. **Security Monitoring**: Anomaly detection + incident response

**Production Implementation:**

✅ Complete RBAC with 6 security roles
✅ Row-level security for data isolation
✅ Encrypted credential vault
✅ TDE + column encryption + backup encryption
✅ SQL Server Audit configuration
✅ Application audit trail
✅ SOX/HIPAA/PCI-DSS compliance reports
✅ Security anomaly detection
✅ Incident response procedures

**Best Practices:**

✅ Windows Authentication + MFA only
✅ Principle of least privilege
✅ Encrypt data at rest and in transit
✅ Comprehensive audit logging
✅ Automated compliance reporting
✅ Security monitoring with anomaly detection
✅ Regular access reviews (quarterly)
✅ Incident response plan documented and tested
✅ Credential rotation every 90 days
✅ Certificate backups in secure location

**Connection to Next Chapter:**

Chapter 10 covers Installation and Configuration, providing step-by-step deployment procedures for the complete DBAOps framework including all security controls, from initial setup through production cutover.

---

## Review Questions

**Multiple Choice:**

1. How many layers are in the defense-in-depth security model?
   a) 3
   b) 5
   c) 7
   d) 10

2. What is the recommended credential rotation frequency?
   a) 30 days
   b) 60 days
   c) 90 days
   d) 180 days

3. What percentage of databases should have TDE enabled in production?
   a) 50%
   b) 75%
   c) 90%
   d) 100%

**Short Answer:**

4. Explain the principle of least privilege and how it's implemented in the DBAOps RBAC model.

5. Describe the differences between TDE, column-level encryption, and backup encryption. When would you use each?

6. What are the six key requirements for SOX compliance in database systems?

**Essay Questions:**

7. Design a comprehensive security architecture for a healthcare organization with 500 SQL Servers storing patient data. Include:
   - Authentication and authorization strategy
   - Encryption approach
   - Audit logging requirements
   - HIPAA compliance mechanisms
   - Security monitoring
   - Incident response plan

8. Analyze the SecureBank case study. What were the critical security gaps, and how did the solution address each? What lessons apply to your organization?

**Hands-On Exercises:**

9. **Exercise 9.1: Implement RBAC**
   - Create 6 security roles
   - Assign appropriate permissions
   - Implement row-level security
   - Test access restrictions
   - Document role assignments

10. **Exercise 9.2: Enable Encryption**
    - Create master key and certificate
    - Enable TDE on repository
    - Backup certificate securely
    - Implement column encryption
    - Enable backup encryption
    - Verify all encryption active

11. **Exercise 9.3: Configure Auditing**
    - Create SQL Server Audit
    - Configure database audit spec
    - Set up application logging
    - Test audit coverage
    - Query audit logs

12. **Exercise 9.4: SOX Compliance Report**
    - Implement SOX compliance checks
    - Create automated report
    - Schedule monthly generation
    - Test with sample data
    - Present to management

---

*End of Chapter 9*

**Next Chapter:** Chapter 10 - Installation and Configuration

